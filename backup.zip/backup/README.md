# Storm-UI

This is the frontend application of Storm located in a monorepo.

## How to start

Run `npm install` to install the required dependencies.

Run `npm start` for a dev server. Navigate to [http://localhost:8001/](http://localhost:8001/). The app will automatically reload if you change any of the source files.

### Issue: Compile error breaks application

In case of adding new component and renaming existing one can cause compile error while development server keeps serving files.
In this case fixing the error or restarting the development server might not fix the application.

**Solution**  
Run `ng cache clean` and restart development server.

**Details**  
The root cause is partial compilation of the code in development mode. The compilation error messes up the cache with stopping instantly. However, after the fix only the modified code is recompiled. So the already missing parts are still missing. Cache should be rebuilt.

## Code scaffolding

Run `ng generate component component-name` to generate a new component.

You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Linting

Run `npm run lint` to lint start linting.

Run `npm run lint:fix` to fix linting issues.

## Prettier

Prettier is configured with eslint and will check for possible formatting issues.

Run `npx prettier --write "{path-to-file}"` to fix a file. You can also set this to automatically run on save in IntelliJ if you go to "Actions on Save" in settings.

Run `npm run format` to format every file in src.

## Running unit tests

Run `npm run test:watch` to execute the unit tests via [Karma](https://karma-runner.github.io) locally with each test scenario result.

Run `npm run test` to execute tests via [Karma](https://karma-runner.github.io) with a summary of the test results.

Test coverage can be found in the `coverage` folder. Open `index.html` to review.

## Running end-to-end tests

The e2e tests are located in a parent folder `e2e`.

## Hooks

Husky is configured with the following hooks:

- **Before commit**: lints project based on `.lintstagedrc` config file
- **Commit message**: validates commit messages enforcing [coventional commits](https://github.com/conventional-changelog/commitlint/tree/master/%40commitlint/config-conventional).
- **Before push**: runs tests

## Build

Run `npm run build` to build the project locally.

Run `npm run build-prod` to build a production version of the app.

The build artifacts will be stored in the `dist/` directory.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
