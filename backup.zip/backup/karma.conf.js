module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-jasmine-html-reporter'),
      require('karma-chrome-launcher'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    autoWatch: false,
    singleRun: true,
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    browsers: ['ChromeHeadless'],
    client: {
      clearContext: false
    },
    jasmineHtmlReporter: {
      suppressAll: true // removes the duplicated traces
    },
    preprocessors: {
      'src/**/*.ts': 'coverage'
    },
    reporters: ['progress', 'kjhtml', 'coverage'],
    coverageReporter: {
      dir: './coverage/',
      subdir: '.',
      reporters: [{ type: 'html' }, { type: 'text-summary' }],
      check: {
        global: {
          statements: 40,
          branches: 30,
          functions: 40,
          lines: 40
        }
      }
    }
  });
};
