import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorPageComponent } from './errors/error-page/error-page.component';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: () => import('./module/dashboard/dashboard.module').then((m) => m.DashboardModule)
  },
  {
    path: 'error/:code',
    pathMatch: 'full',
    component: ErrorPageComponent
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'error/404'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      enableTracing: false,
      scrollPositionRestoration: 'top',
      relativeLinkResolution: 'legacy',
      useHash: true
    })
  ],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {}
