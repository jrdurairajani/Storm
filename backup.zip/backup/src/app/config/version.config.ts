import { InjectionToken } from '@angular/core';

export const APP_VERSION = new InjectionToken<string>('app.version');
