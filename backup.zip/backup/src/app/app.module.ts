import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, ErrorHandler, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FstMaterialModule } from './fst-material/fst-material.module';
import { PagesModule } from './pages/pages.module';
import { APP_VERSION } from './config/version.config';
import { CoreModule } from './core/core.module';
import { routerReducer, StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { RootState } from './model/root-state.model';
import { Store, StoreModule } from '@ngrx/store';
import { tap } from 'rxjs/operators';
import { InitService } from './core/services/init.service';
import { EffectsModule } from '@ngrx/effects';
import { appInitFinishedEvent } from './state/root.actions';
import { currentSessionReducer, uiStateReducer } from './state/root.reducers';
import { STORM_UI_VERSION_INFO } from '../environments/version';
import { EntityDataModule } from '@ngrx/data';
import { SharedModule } from './module/shared/shared.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ErrorHandlerInterceptor } from './errors/interceptor/error-handler.interceptor';
import { MatSelectModule } from '@angular/material/select';
import { ErrorDialogComponent } from './module/search/components/dialog-windows/error-dialog/error-dialog.component';
import { ErrorBoundaryComponent } from './errors/error-boundary/error-boundary.component';
import { CustomErrorHandler } from './errors/error-boundary/custom-error-handler';

export function initClient(initService: InitService, store: Store<RootState>) {
  return function () {
    return initService
      .getCurrentUser()
      .pipe(
        tap((currentUser) => {
          store.dispatch(appInitFinishedEvent({ currentUser }));
        })
      )
      .toPromise();
  };
}

@NgModule({
  declarations: [AppComponent, ErrorDialogComponent, ErrorBoundaryComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot({
      router: routerReducer,
      currentSession: currentSessionReducer,
      uiState: uiStateReducer
    }),
    EffectsModule.forRoot([]),
    FstMaterialModule,
    CoreModule,
    SharedModule,
    MatSelectModule,
    AppRoutingModule,
    PagesModule,
    StoreRouterConnectingModule.forRoot(),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      logOnly: environment.production,
      name: 'one-crew'
    }),
    EntityDataModule.forRoot({})
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ErrorHandlerInterceptor, multi: true },
    {
      provide: APP_INITIALIZER,
      multi: true,
      deps: [InitService, Store],
      useFactory: initClient
    },
    {
      provide: APP_VERSION,
      useValue: STORM_UI_VERSION_INFO.version
    }
    //{ provide: ErrorHandler, useClass: CustomErrorHandler }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
