import { CoreState } from '../core/model/core-state.model';
import { UiState } from './ui-state.model';
import { Session } from './session.model';
import { SearchState } from '../module/search/state/reducers';
import { StationDetails } from '../module/station-details/state/reducers';

export interface RootState {
  core: CoreState;
  uiState: UiState;
  currentSession: Session;
  search: SearchState;
  stationDetails: StationDetails;
}
