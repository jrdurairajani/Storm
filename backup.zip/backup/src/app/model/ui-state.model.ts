import { NavigationItem } from './navigation-item.model';
import { SideNavItem } from '../fst-material/model/side-nav-item';
import { ViewTypeModel } from './view-type.model';

export class UiState {
  topNavigation: NavigationItem[] = [];
  sideNavItems: SideNavItem[] = [];
  pageTitle = '';
  isViewTypeEnabled = true;
  viewType: ViewTypeModel = ViewTypeModel.MAP;
}
