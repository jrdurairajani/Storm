export class NavigationItem {
  constructor(
    readonly itemId: string,
    readonly enabled: boolean = true
  ) {
    this.itemId = itemId;
    this.enabled = enabled;
  }
}
