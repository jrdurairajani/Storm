import { User } from '../core/model/user.model';

export interface Session {
  currentUser?: User;
}
