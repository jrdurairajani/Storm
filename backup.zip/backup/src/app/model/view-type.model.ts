export enum ViewTypeModel {
  MAP = 'MAP',
  SEARCH = 'SEARCH'
}
