import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'strm-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss']
})
export class ErrorPageComponent implements OnInit {
  statusCode: string;
  info: string;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.statusCode = params.get('code');
      this.selectInfo(this.statusCode);
    });
  }

  private selectInfo(code: string): void {
    if (code === '403') {
      this.info = "You·don't·have·access·to·this·resource";
    } else if (code === '404') {
      this.info = 'The page you requested could not be found';
    } else if (code === '500') {
      this.info = 'Unexpected error';
    } else {
      this.statusCode = '404';
      this.info = 'The page you requested could not be found';
    }
  }
}
