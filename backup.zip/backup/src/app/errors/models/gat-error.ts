export interface GatError {
  key: string;
  messageCode: string;
  messageText: string;
  messageType: string;
  feAction: FeAction;
  useCase: string;
}

export enum FeAction {
  popup = 'POP-UP',
  text = 'SHOW-TEXT'
}
