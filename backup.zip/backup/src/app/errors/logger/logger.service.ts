import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  constructor(private http: HttpClient) {}

  sendLogs(body: unknown): Observable<unknown> {
    return this.http.post<unknown>('/api/utility-controller/log', body);
  }
}
