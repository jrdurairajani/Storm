import { Component, ErrorHandler } from '@angular/core';

@Component({
  selector: 'strm-error-boundary',
  templateUrl: 'eror-boundary.component.html',
  styleUrls: ['error-boundary.component.scss']
})
export class ErrorBoundaryComponent {
  public hasError = false;
  public errorMessage = '';

  constructor(private errorHandler: ErrorHandler) {}

  public handleError(error: { message: string }): void {
    this.hasError = true;
    this.errorMessage = error.message || 'Something went wrong.';
    // You can log the error or perform any necessary actions here
    console.error(error);
  }
}
