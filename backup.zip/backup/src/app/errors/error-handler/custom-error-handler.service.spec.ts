import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastrModule } from 'ngx-toastr';
import { of } from 'rxjs';
import { LoggerService } from '../logger/logger.service';
import { CustomErrorHandlerService } from './custom-error-handler.service';

describe('CustomErrorHandlerService', () => {
  let customErrorService: CustomErrorHandlerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ToastrModule.forRoot(),
        RouterTestingModule.withRoutes([]),
        HttpClientTestingModule
      ],
      providers: [CustomErrorHandlerService, LoggerService]
    });
    customErrorService = TestBed.inject(CustomErrorHandlerService);
  });

  it('should be created', () => {
    const errorHandler: CustomErrorHandlerService = TestBed.inject(CustomErrorHandlerService);
    expect(errorHandler).toBeTruthy();
  });

  it('handleError method should call logger service if input is not type of http error  ', () => {
    const loggerService = TestBed.inject(LoggerService);
    const spy = spyOn(loggerService, 'sendLogs').and.returnValue(of(true));
    customErrorService.handleError(new Error('testing error'));
    expect(spy).toHaveBeenCalled();
  });

  it('handleError method should not call logger service if input is  type of http error  ', () => {
    const loggerService = TestBed.inject(LoggerService);
    const spy = spyOn(loggerService, 'sendLogs').and.returnValue(of(true));
    customErrorService.handleError(new HttpErrorResponse({ error: 'test', status: 404 }));
    expect(spy).not.toHaveBeenCalled();
  });
});
