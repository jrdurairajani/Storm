import { HttpErrorResponse } from '@angular/common/http';
import { ErrorHandler, Injectable } from '@angular/core';
import { LoggerService } from '../logger/logger.service';

@Injectable({
  providedIn: 'root'
})
export class CustomErrorHandlerService extends ErrorHandler {
  constructor(private logger: LoggerService) {
    super();
  }

  handleError(error: Error): void {
    if (!(error instanceof HttpErrorResponse)) {
      const logJson = {
        message: error.stack,
        loggingLevel: 'error'
      };
      this.logger.sendLogs(logJson).subscribe();
    }
    super.handleError(error);
  }
}
