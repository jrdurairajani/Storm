export const COLOR_CODES = 'User not authorised to get COLOR Codes Details';
export const GATEWAY_TIMEOUT = 'Gateway Timeout';
export const ErrorCodes = ['00002'];
