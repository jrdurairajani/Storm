import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { catchError } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { COLOR_CODES, ErrorCodes, GATEWAY_TIMEOUT } from './error-message';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ErrorDialogComponent } from 'src/app/module/search/components/dialog-windows/error-dialog/error-dialog.component';
import { FeAction, GatError } from '../models/gat-error';

@Injectable()
export class ErrorHandlerInterceptor implements HttpInterceptor {
  timeOut = 5000;

  constructor(
    private toast: ToastrService,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((error) => {
        if (error) {
          const gatError: GatError = error?.error;
          if (!(ErrorCodes.includes(gatError.messageCode) || error.error === COLOR_CODES)) {
            switch (
              error.status // these cases are to be implemented ex. route to not found page or show some specific message
            ) {
              case 400:
                this.toast.error(error.error, error.status, { timeOut: this.timeOut });
                break;
              case 401:
                this.toast.error(error.error, error.status, { timeOut: this.timeOut });
                break;
              case 403:
                if (gatError.feAction === FeAction.popup) {
                  this.openDialog(gatError.messageText);
                }
                break;
              case 404:
                this.router.navigate(['/error', 404]).then();
                break;
              case 500:
                this.router.navigate(['/error', 500]).then();
                break;
              case 504:
                if (error.statusText === GATEWAY_TIMEOUT) {
                  this.toast.error('Session timeout', 'Error', { timeOut: this.timeOut });
                }
                break;
              default:
                this.toast.error(error.error, error.status, { timeOut: this.timeOut });
                break;
            }
          }
        }
        return throwError(error);
      })
    );
  }

  openDialog(text: string): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      text
    };

    dialogConfig.autoFocus = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '300px';
    dialogConfig.panelClass = 'app-full-bleed-dialog';
    this.dialog.open(ErrorDialogComponent, dialogConfig);
  }
}
