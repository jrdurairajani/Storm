import { NgModule } from '@angular/core';
import { environment } from '../../environments/environment';
import { USER_SERVICE_TOKEN } from './services/user.service';
import { Action, StoreModule } from '@ngrx/store';
import { coreState, CoreState } from './model/core-state.model';
import { EffectsModule } from '@ngrx/effects';
import { CoreEffects } from './state/core.effects';
import { coreStateReducers } from './state/core.reducers';

@NgModule({
  imports: [
    StoreModule.forFeature<CoreState, Action>(coreState, coreStateReducers),
    EffectsModule.forFeature([CoreEffects])
  ],
  providers: [
    {
      provide: USER_SERVICE_TOKEN,
      useClass: environment.services.userService
    }
  ]
})
export class CoreModule {}
