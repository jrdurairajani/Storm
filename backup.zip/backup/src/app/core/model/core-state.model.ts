export const coreState = 'core';

/* eslint-disable */
export interface CoreState {}
/* eslint-enable */
