import { Role } from './role.model';

export interface User {
  username: string; // to be checked for Type
  lastname: string;
  firstname: string;
  roles: Role[];
}
