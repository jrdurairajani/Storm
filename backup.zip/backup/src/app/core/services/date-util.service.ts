import { Injectable } from '@angular/core';
import { DateTime } from 'luxon';

export const DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
export const DISPLAY_DATE_FORMAT = 'dd-MM-yyyy';

@Injectable({
  providedIn: 'root'
})
export class DateUtilService {
  private static parsers: ((dateString: string) => DateTime | null)[] = [
    DateUtilService.parseAsDefaultDisplayFormat,
    DateUtilService.parseAsISO,
    DateUtilService.parseAsHttp,
    DateUtilService.parseAsSQL,
    DateUtilService.parseAsRFC2822
  ];

  public static formatDate(dateString: string | null, format = DATE_FORMAT): string | null {
    if (!dateString) {
      return null;
    }
    for (const parser of this.parsers) {
      const parsedDate = parser(dateString);
      if (parsedDate?.isValid) {
        return parsedDate.toFormat(format);
      }
    }
    console.error('Invalid date format. The date should be in ISO, DD-MM-YYYY or HTTP format.');
    return null;
  }

  private static parseAsHttp(dateString: string): DateTime | null {
    try {
      return DateTime.fromHTTP(dateString);
    } catch (e) {
      return null;
    }
  }

  private static parseAsISO(dateString: string): DateTime | null {
    try {
      return DateTime.fromISO(dateString);
    } catch (e) {
      return null;
    }
  }

  private static parseAsDefaultDisplayFormat(dateString: string): DateTime | null {
    try {
      return DateTime.fromFormat(dateString, DISPLAY_DATE_FORMAT);
    } catch (e) {
      return null;
    }
  }

  private static parseAsSQL(dateString: string): DateTime | null {
    try {
      return DateTime.fromSQL(dateString);
    } catch (e) {
      return null;
    }
  }

  private static parseAsRFC2822(dateString: string): DateTime | null {
    try {
      return DateTime.fromRFC2822(dateString);
    } catch (e) {
      return null;
    }
  }
}
