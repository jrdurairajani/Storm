import { UserService } from './user.service';
import { Observable } from 'rxjs';
import { User } from '../model/user.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserServiceImpl implements UserService {
  constructor(private httpClient: HttpClient) {}
  getCurrentUser(): Observable<User> {
    return this.httpClient.get<User>('api/me');
  }
}
