import { UserService } from './user.service';
import { Observable, of } from 'rxjs';
import { User } from '../model/user.model';
import { Injectable } from '@angular/core';
import { Role } from '../model/role.model';

@Injectable()
export class MockedUserService implements UserService {
  getCurrentUser(): Observable<User> {
    return of({
      username: '1',
      firstname: 'Sponge',
      lastname: 'Bob',
      roles: [Role.SECURITY_EMPLOYEE]
    });
  }
}
