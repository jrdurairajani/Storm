import { Inject, Injectable } from '@angular/core';
import { USER_SERVICE_TOKEN, UserService } from './user.service';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InitService {
  displayBack = false;
  constructor(@Inject(USER_SERVICE_TOKEN) private userService: UserService) {}

  getCurrentUser(): Observable<User> {
    return this.userService.getCurrentUser();
  }
}
