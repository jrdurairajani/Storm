import { Observable } from 'rxjs';
import { User } from '../model/user.model';

export const USER_SERVICE_TOKEN = 'userService';

export interface UserService {
  getCurrentUser(): Observable<User>;
}
