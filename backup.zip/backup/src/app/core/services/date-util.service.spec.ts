import { TestBed } from '@angular/core/testing';

import { DATE_FORMAT, DateUtilService, DISPLAY_DATE_FORMAT } from './date-util.service';
import { DateTime } from 'luxon';

describe('DateUtilService', () => {
  let service: DateUtilService;
  const date = DateTime.now();

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DateUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('formatDate', () => {
    it('should return null if dateString is null', () => {
      expect(DateUtilService.formatDate(null)).toBeNull();
    });

    it('should return formatted date if dateString is valid', () => {
      const inputString = date.toFormat(DATE_FORMAT);
      const expected = DateTime.fromFormat(inputString, DATE_FORMAT).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return formatted date in specified format', () => {
      const inputString = date.toFormat(DATE_FORMAT);
      const expected = DateTime.fromFormat(inputString, DATE_FORMAT).toFormat(DISPLAY_DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString, DISPLAY_DATE_FORMAT)).toEqual(expected);
    });

    it('should return formatted date if dateString is in display date format', () => {
      const inputString = date.toFormat(DISPLAY_DATE_FORMAT);
      const expected = DateTime.fromFormat(inputString, DISPLAY_DATE_FORMAT).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return formatted date if dateString is in ISO date format', () => {
      const inputString = date.toISO();
      const expected = DateTime.fromISO(inputString).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return formatted date if dateString is in Http date format', () => {
      const inputString = date.toHTTP();
      const expected = DateTime.fromHTTP(inputString).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return formatted date if dateString is in SQL date format', () => {
      const inputString = date.toSQL();
      const expected = DateTime.fromSQL(inputString).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return formatted date if dateString is in RFC2822 date format', () => {
      const inputString = date.toRFC2822();
      const expected = DateTime.fromRFC2822(inputString).toFormat(DATE_FORMAT);
      expect(DateUtilService.formatDate(inputString)).toEqual(expected);
    });

    it('should return null if dateString is invalid', () => {
      expect(DateUtilService.formatDate('invalid date')).toBeNull();
    });
  });
});
