// export const selectCore = createFeatureSelector<RootState, CoreState>(coreState);
//
// export const selectCurrentUser = createSelector(selectCore,
//   (state: CoreState) => state.currentSession.currentUser);
