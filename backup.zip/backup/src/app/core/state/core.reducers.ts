import { ActionReducerMap } from '@ngrx/store';
import { CoreState } from '../model/core-state.model';

export const coreStateReducers: ActionReducerMap<CoreState> = {
  // currentSession: currentSessionReducer,
  // uiState: uiStateReducer
};
