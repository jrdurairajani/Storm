export interface SecurityEventOverview {
  items?: SecurityEventRecord[];
  size?: number;
  totalElements?: number;
  totalPages?: number;
}

export interface SourceFilter {
  id: string;
  name: string;
  code: string;
}

export interface SecurityEventRecord {
  id: string;
  eventSourceId: string;
  modifiedDate: string;
  description: string;
  countryName: string;
  status: string;
  source: string;
  modified: boolean;
}
