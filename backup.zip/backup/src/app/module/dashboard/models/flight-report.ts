export interface FlightsResponse {
  items?: FlightReportSophi[];
  size?: number;
  totalElements?: number;
  totalPages?: number;
}

export interface FlightReportSophi {
  id?: string;
  actualDepartureTimestamp?: string;
  airlineCode: string;
  airlineType: string;
  arrivalStation: ArrivalStation;
  cabinStaffEmployer: string;
  cockpitStaffEmployer: string;
  aircraftType: string;
  departureDelays: DepartureDelays[];
  departureStation: DepartureStation;
  flightNumber: string;
  plusDays: number;
  actualDeparturePlusDays: number;
  flightStatus: string;
  stationManagerReportStatus: string;
  securityEmployeeReportStatus?: string;
  iauditorNumber: string;
  infantTotal: number;
  assignedToUserId: string;
  messages: boolean;
  incidentReported: boolean;
  operationalConfiguration: string;
  operationalSuffix: any;
  passengerTotal: number;
  physicalPaxConfiguration: string;
  registration: string;
  scheduledArrivalTimestamp: string;
  scheduledDepartureTimestamp: string;
  serviceType: any;
  serviceTypeName: string;
  staffDutyTotal: number;
  staffRebateTotal: number;
  staffTotal: number;
  specialPassengers: Special;
}

export interface Special {
  wheelchair: Passenger[];
  unaccompaniedMinors: Passenger[];
  weapon: Passenger[];
  inadDepaDepu: Passenger[];
}

export interface Remarks {
  ssrCode: string;
  remark: string;
}

export interface Passenger {
  firstName: string;
  lastName: string;
  remarks?: Remarks[];
  gender?: string;
  title?: string;
  additionalInformation?: string;
}

export interface ArrivalStation {
  name: string;
  iataCode: string;
  icaoCode: string;
  stationType: string;
}

export interface DepartureStation {
  name: string;
  iataCode: string;
  icaoCode: string;
  stationType: string;
}

export interface DepartureDelays {
  delayCode: string;
  delayReason: string;
}
