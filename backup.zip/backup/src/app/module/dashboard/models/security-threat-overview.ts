export interface SecurityThreatOverview {
  items?: SecurityThreatRecord[];
  size?: number;
  totalElements?: number;
  totalPages?: number;
}

export interface SecurityThreatRecord {
  id: string;
  referenceNumber: string;
  createdBy: string;
  title: string;
  countryName: string;
  countryCode: string;
  date: string;
  time: string;
  kfssb: boolean;
}
