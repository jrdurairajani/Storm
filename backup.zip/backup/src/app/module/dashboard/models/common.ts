export interface PagedResponse<T> {
  items: Array<T>;
  totalPages: number;
  totalElements: number;
  size: number;
}

export interface SecurityDashboard {
  securityEventCount: number;
  securityThreatCount: number;
}

export interface Country {
  code: string;
  name: string;
}
