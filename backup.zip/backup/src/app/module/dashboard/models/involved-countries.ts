export interface CityCountries {
  name: string;
  code: string;
}
