export interface AirportDetails {
  id: string;
  iataCode: string;
  icaoCode: string;
  airportName: string;
  cityIataCode: string;
  city: string;
  country: string;
  airportLocation?: string;
}
