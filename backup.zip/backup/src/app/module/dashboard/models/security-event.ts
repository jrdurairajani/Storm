import { POI } from './map';
import {
  AddSource,
  Country,
  Details,
  Impact as ThreatImpact,
  SecurityThreatHeader,
  ThreatIncidentLevel,
  SecurityThreatLocation
} from './security-threat';

export interface SecurityEvent {
  id: string;
  region: Region;
  summary: Summary;
  report: Report;
  impact: Impact;
  status: string;
  rootObject?: RootObject;
  source?: string;
  assessment?: Assessment[];
}

export interface NextSecurityEvent {
  nextSecurityEventId: string;
}

export interface Region {
  flag: string;
  securityRegion?: string;
  regionNameProvider: string;
  continent: Continent;
  country: Country;
  state: string;
  city: string;
  location: string;
  station: string;
  latitude: number;
  longitude: number;
}

export interface Continent {
  id: string;
  code: string;
  name: string;
  latitude: string;
  longitude: string;
}

export interface Summary {
  eventDate: string;
  eventLastModifiedDate: string;
  title?: string;
  description: string;
}

export interface Report {
  category: string;
  attackType?: string;
  perpetrators?: string;
  sector?: string;
  locationPrecision?: string;
  station?: string;
  assetTypes?: string;
  primaryAsset?: string;
  secondaryCountries?: string;
  perpetratorFreeText?: string;
  exactLocation?: string;
  service?: string;
  eventStart?: string;
  eventEnd?: string;
}

export interface Impact {
  totalFatalities: number;
  totalInjuries?: number;
  severityScore?: string;
}

export interface RootObject {
  id: string;
  sourceIncidentId: number;
  source: string;
  createdAt: Date;
  region: Region;
  summary: Summary;
  report: Report;
  impact: Impact;
  modified: boolean;
}

export interface SecurityEventDTO {
  summary: SummaryDTO;
  source: AddSource[];
  eventImpact: ImpactDTO;
  incidentEventLevel: IncidentLevel;
  details: Details;
  poi: POI;
  location: LocationDTO;
}

export interface Assessment {
  header: string;
  description: string;
}

export interface SummaryDTO {
  title: string;
  relevantForKfssb: boolean;
  eventReceivedDate: string;
  eventReceivedTime: string;
  eventStartDate: string;
  eventStartTime: string;
  eventEndDate: string;
  eventEndTime: string;
  description: string;
  isError?: boolean;
}

export type EventHeader = SecurityThreatHeader;
export type ImpactDTO = ThreatImpact;
export type IncidentLevel = ThreatIncidentLevel;
export type LocationDTO = SecurityThreatLocation;
