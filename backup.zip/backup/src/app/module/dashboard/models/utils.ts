export interface NextPrevSettings {
  pageIndex: number;
  pageCount: number;
  prevBtnDisable: boolean;
  endElement: number;
  totalSize: number;
  nxtBtnDisable: boolean;
}
