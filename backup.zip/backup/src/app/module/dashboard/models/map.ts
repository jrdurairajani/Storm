export interface POI {
  markers?: Marker[];
  polygons?: Polygon[];
  bounds?: Bound[];
}

export interface Marker {
  coordinates: Coordinates;
  type: 'regular' | 'primary';
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Polygon {
  coordinates: Coordinate[][];
  type: 'regular' | 'primary';
}

export interface Bound {
  coordinates: Coordinate[][];
  type: 'regular' | 'primary';
}

export interface Coordinate {
  lat: number;
  lng: number;
}
