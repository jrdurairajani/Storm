export interface DocumentFile {
  id: string;
  documentCategory?: string;
  lastModifiedBy?: string;
  lastModifiedOn?: any;
  documentName?: string;
  forRoles?: string;
  uploadedOn?: string;
  uploadedBy?: string;
  modifiedBy?: string;
  fileType?: string;
  fileSize?: number;
  overwrittenDocIds?: string;
}
