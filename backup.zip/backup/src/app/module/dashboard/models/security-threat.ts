import { AirportDetails } from './airport-details';
import { CityCountries } from './involved-countries';
import { Bound, Marker, POI } from './map';

export type SecurityThreatViewMode = 'create' | 'details' | 'edit';

export interface SecurityThreatSummary {
  title: string;
  relevantForKfssb: boolean;
  eventReceivedDate: string;
  eventReceivedTime: string;
  threatStartDate: string;
  threatStartTime: string;
  threatEndDate: string;
  threatEndTime: string;
  description: string;
  isError?: boolean;
}

export interface SecurityThreatHeader {
  region: string;
  provider: string;
  continent: string;
  countryCode: string;
  countryName: string;
  state: string;
  city: string;
  location: string;
  station: string;
  freeTextCity?: string;
  freeTextState?: string;
}

export interface SecurityThreatLocation {
  osmId: number;
  osmType: string;
  primaryLocation: string;
  airportCode: string;
  involvedCountries: string[] | CityCountries[];
  country: string;
  marker: Marker;
  bounds: Bound;
  airportDetails?: AirportDetails | null;
}

export interface AddSource {
  name: string;
  link: string;
  disabled?: boolean;
  isDelete?: boolean;
  isAPISource?: boolean;
}

export interface Details {
  category: string[];
  apiData: ApiData;
}

export interface ApiData {
  category: string;
  attackType: string;
  perpetrators: string;
  sector: string;
  station: string;
  assetTypes: string;
  primaryAsset: string;
  secondaryCountries: string;
  perpetratorFreeText: string;
}

export interface ThreatIncidentLevel {
  levelGroup: object;
  overFlightZone: object;
}

export interface Impact {
  accidentLevel: number;
  effectiveLevel: number;
  erc: number;
}

export class MediaFile {
  id: string;
  name: string;
  size: number;

  constructor(id: string, name: string, size: number) {
    this.id = id;
    this.name = name;
    this.size = size;
  }
}

export interface SecurityThreatRecord extends SecurityThreat {
  id?: string;
  referenceNumber?: string;
  createdOn?: string;
  createdBy?: string;
  lastModifiedOn?: string;
  lastModifiedBy?: string;
}

export interface SecurityThreat {
  id?: string;
  summary: SecurityThreatSummary;
  location: SecurityThreatLocation;
  source: AddSource[];
  threatImpact: Impact;
  incidentThreatLevel: ThreatIncidentLevel;
  details: Details;
  poi: POI;
  mediaFiles: MediaFile[];
  eventToThreatConversionID?: string;
}

export interface NextSecurityThreat {
  nextSecurityThreatId: string;
}

export const EMPTY_SECURITY_THREAT: SecurityThreat = {
  summary: {
    title: null,
    relevantForKfssb: false,
    eventReceivedDate: null,
    eventReceivedTime: null,
    threatStartDate: null,
    threatStartTime: null,
    threatEndDate: null,
    threatEndTime: null,
    description: null,
    isError: false
  },
  location: {
    marker: null,
    osmId: null,
    osmType: null,
    primaryLocation: null,
    airportCode: null,
    involvedCountries: null,
    country: null,
    bounds: null
  },
  source: [],
  threatImpact: {
    accidentLevel: 0,
    effectiveLevel: 0,
    erc: 0
  },
  incidentThreatLevel: {
    levelGroup: {},
    overFlightZone: {}
  },
  details: {
    category: null,
    apiData: {
      category: null,
      attackType: null,
      perpetrators: null,
      sector: null,
      station: null,
      assetTypes: null,
      primaryAsset: null,
      secondaryCountries: null,
      perpetratorFreeText: null
    }
  },
  poi: {
    markers: undefined,
    polygons: undefined
  },
  mediaFiles: []
};

export interface SecurityRegion {
  name: string;
}

export interface ElementWithCodeAndName {
  code: string;
  name: string;
}

export interface DataEmitted {
  emitValue: ElementWithCodeAndName;
  displayValue: string;
}

export interface City extends ElementWithCodeAndName {
  state?: ElementWithCodeAndName;
}

// TODO: some of these have conflicting responsibilities. For example: Country is used also for security events.
export type Continent = ElementWithCodeAndName;
export type Country = ElementWithCodeAndName;
export type State = ElementWithCodeAndName;
export type Station = ElementWithCodeAndName;
