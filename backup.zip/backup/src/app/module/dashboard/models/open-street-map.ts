import { Observable } from 'rxjs';
import { Bound, Coordinate, Marker } from './map';

export interface OpenStreetMapSearchResult {
  place_id?: number;
  licence?: string;
  osm_type?: string;
  osm_id?: number;
  lat?: string;
  lon?: string;
  class?: string;
  type?: string;
  place_rank?: number;
  importance?: number;
  addresstype?: string;
  name?: string;
  display_name?: string;
  address?: OpenStreetMapAddress;
  boundingbox?: string[];
  marker?: Marker;
  bounds?: Bound;
  geojson?: {
    type: string;
    coordinates: number[][][];
  };
}

export interface OpenStreetMapAddress {
  country?: string;
  country_code?: string;
  city?: string;
  county?: string;
  municipality?: string;
  postcode?: string;
  road?: string;
  house_number?: string;
  state?: string;
  village?: string;
}

export interface IMapService {
  search(query: string): Observable<OpenStreetMapSearchResult[]>;
}
