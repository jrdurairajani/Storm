import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardBreadcrumbComponent } from './dashboard-breadcrumb.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('DashboardBreadcrumbComponent', () => {
  let component: DashboardBreadcrumbComponent;
  let fixture: ComponentFixture<DashboardBreadcrumbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DashboardBreadcrumbComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(DashboardBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
