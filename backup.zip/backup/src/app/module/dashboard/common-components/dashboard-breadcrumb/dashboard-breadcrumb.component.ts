import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'strm-dashboard-breadcrumb',
  templateUrl: './dashboard-breadcrumb.component.html',
  styleUrls: ['./dashboard-breadcrumb.component.scss']
})
export class DashboardBreadcrumbComponent implements OnInit {
  public currentBreadcrumbData: string[] = [];
  public breadcrumbRouterLinks: string[] = ['', '/'];
  private urlSegments: string[] = [];

  constructor(private router: Router) {}

  ngOnInit(): void {
    const urlSegments: string[] = this.router.url.split('/');
    urlSegments.shift();
    this.urlSegments = urlSegments;
    this.breadcrumbInit();
  }

  private breadcrumbInit(): void {
    let breadcrumbRouterLink = '';

    this.urlSegments.forEach((urlSegment: string, index: number) => {
      breadcrumbRouterLink += urlSegment + '/';
      this.breadcrumbRouterLinks[index] = breadcrumbRouterLink;
    });

    this.currentBreadcrumbData = this.getBreadcrumbData(this.urlSegments);
  }

  private getBreadcrumbData(urlSegments: string[]): string[] {
    return urlSegments.map((item, index) => {
      if (item.includes('?') && this.urlSegments[1] === 'security-threats') {
        item = 'Security Threat';
      }
      if (item.includes('?') && this.urlSegments[1] === 'security-events') {
        item = 'Security Event';
      }
      if (this.urlSegments[index] === 'create' && this.urlSegments[1] === 'security-threats') {
        item = 'Create Security Threat';
      }
      if (this.urlSegments[index] === 'create' && this.urlSegments[1] === 'security-events') {
        item = 'Create Security Event';
      }
      return item;
    });
  }
}
