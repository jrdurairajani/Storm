import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  KfssbFilterValue
} from '../../services/filter.service';
import { ApiSecurityEventService } from '../../services/api-security-event.service';
import { map, Subscription, switchMap } from 'rxjs';
import { NextSecurityEvent, SecurityEvent } from '../../models/security-event';
import { NextSecurityThreat, SecurityThreat } from '../../models/security-threat';
import { take } from 'rxjs/operators';
import { Country } from '../../models/common';
import { SourceFilter } from '../../models/security-event-overview';

@Component({
  selector: 'strm-next-previous-btn',
  templateUrl: './next-previous-button.component.html',
  styleUrls: ['./next-previous-button.component.scss']
})
export class NextPreviousButtonComponent implements OnInit, OnDestroy {
  // TODO: refactor input/outputs to a subject in a service
  @Input()
  public props: {
    pageIndex: number;
    pageCount: number;
    prevBtnDisable: boolean;
    endElement: number;
    totalSize: number;
    nxtBtnDisable: boolean;
  };

  @Output()
  public emitData = new EventEmitter<SecurityThreat | SecurityEvent>();
  @Output()
  public emitEventData = new EventEmitter<SecurityThreat | SecurityEvent>();

  public isPreviousButtonDisabled = true;
  public isNextButtonDisabled = true;

  private filterKey: FilterConsumerKey;
  private endElement: number;
  private totalSize: number;
  private mode: string;
  private subscriptions: Subscription = new Subscription();

  constructor(
    private apiSecurityThreatService: ApiSecurityThreatService,
    private apiSecurityEventService: ApiSecurityEventService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private filterService: FilterService
  ) {}

  public ngOnInit(): void {
    this.mode = this.activatedRoute.snapshot.url[0].path;
    if (this.mode === 'security-threats') {
      this.initSecurityThreatMode();
    } else {
      this.initSecurityEventMode();
    }
    this.calculateButtonVisibility(
      this.props.pageCount,
      this.props.pageIndex,
      this.props.totalSize,
      this.props.endElement
    );
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public async showPrevious(): Promise<void> {
    if (this.props.pageIndex <= 0) {
      this.props.pageIndex = 10;
      this.props.pageCount--;
    }
    this.props.pageIndex--;
    await this.loadItem();
    this.calculateButtonVisibility(
      this.props.pageCount,
      this.props.pageIndex,
      this.props.totalSize,
      this.props.endElement
    );
  }

  public async showNext(): Promise<void> {
    this.props.pageIndex++;
    if (this.props.pageIndex == 10) {
      this.props.pageIndex = 0;
      this.props.pageCount++;
    }
    await this.loadItem();
    this.calculateButtonVisibility(
      this.props.pageCount,
      this.props.pageIndex,
      this.props.totalSize,
      this.props.endElement
    );
  }

  // TODO: Change this to private and refactor unit tests
  public hideNextButton(endEl: number, pCount: number, pTsize: number, pageIndex: number): boolean {
    return endEl == pCount * pTsize - (pTsize - (pageIndex + 1));
  }

  // TODO: Change this to private and refactor unit tests
  public hidePreviousButton(pageCount: number, pageIndex: number): boolean {
    if (pageCount == 1 && pageIndex == 0) {
      return true;
    } else {
      return pageCount == 0;
    }
  }

  private async loadItem(): Promise<void> {
    if (this.mode == 'security-threats') {
      this.loadSecurityThreat();
    } else {
      this.loadSecurityEvent();
    }
  }

  // TODO: Fix this bad design pattern --> shouldn't load events to get the next/previous event. Next/previous info is passable
  //  through a service/input
  private initSecurityEventMode(): void {
    this.filterKey = FilterConsumerKey.EVENTS;
    const sub = this.filterService.filterObservable
      .pipe(
        map((filters) => filters.get(this.filterKey)),
        switchMap((filters) =>
          this.apiSecurityEventService.getSecurityEventOverview(
            this.props.pageCount,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            (filters?.get(FilterKey.SOURCE) as SourceFilter[]) ?? []
          )
        )
      )
      .subscribe((res) => {
        this.endElement = res.totalElements;
        this.totalSize = res.size;
        this.calculateButtonVisibility(
          this.props.pageCount,
          this.props.pageIndex,
          this.totalSize,
          this.endElement
        );
      });
    this.subscriptions.add(sub);
  }

  // TODO: Fix this bad design pattern --> shouldn't load threats to get the next/previous threat. Next/previous info is passable
  //  through a service/input
  private initSecurityThreatMode(): void {
    this.filterKey = FilterConsumerKey.THREATS;
    const sub = this.filterService.filterObservable
      .pipe(
        map((filters) => filters.get(this.filterKey)),
        switchMap((filters) =>
          this.apiSecurityThreatService.getSecurityThreatOverview(
            this.props.pageCount,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            filters?.get(FilterKey.KFSSB) as KfssbFilterValue,
            'open'
          )
        )
      )
      .subscribe((res) => {
        this.endElement = res.totalElements;
        this.totalSize = res.size;
        this.calculateButtonVisibility(
          this.props.pageCount,
          this.props.pageIndex,
          this.totalSize,
          this.endElement
        );
      });
    this.subscriptions.add(sub);
  }

  private loadSecurityEvent(): void {
    this.filterService.filterObservable
      .pipe(
        take(1),
        map((filters) => filters.get(this.filterKey)),
        switchMap((filters) =>
          this.apiSecurityEventService.getNextEventNavigation(
            this.props.pageCount,
            this.props.pageIndex,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            (filters?.get(FilterKey.SOURCE) as SourceFilter[]) ?? []
          )
        ),
        switchMap((nextEvent: NextSecurityEvent) => {
          return this.apiSecurityEventService.getIncidentDetails(nextEvent.nextSecurityEventId);
        })
      )
      .subscribe({
        next: async (securityEvent: SecurityEvent) => {
          this.emitEventData.emit(securityEvent);
          await this.router.navigate(['/dashboard/security-events', securityEvent.id], {
            queryParams: {
              page: this.props.pageCount,
              index: this.props.pageIndex
            }
          });
        },
        error: (error) => {
          if (error) {
            alert('No maritime data available!');
          }
        }
      });
  }

  private loadSecurityThreat(): void {
    this.filterService.filterObservable
      .pipe(
        take(1),
        map((filters) => filters.get(this.filterKey)),
        switchMap((filters) =>
          this.apiSecurityThreatService.getNextThreatNavigation(
            this.props.pageCount,
            this.props.pageIndex,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            filters?.get(FilterKey.KFSSB) as KfssbFilterValue
          )
        ),
        switchMap((nextThreat: NextSecurityThreat) => {
          return this.apiSecurityThreatService.getSecurityThreat(nextThreat.nextSecurityThreatId);
        })
      )
      .subscribe({
        next: async (securityThreat: SecurityThreat) => {
          this.emitData.emit(securityThreat);
          await this.router.navigate(['/dashboard/security-threats', securityThreat.id], {
            queryParams: {
              page: this.props.pageCount,
              index: this.props.pageIndex
            }
          });
        },
        error: (error) => {
          if (error.error.message) {
            alert(error.error.message);
          }
        }
      });
  }

  private calculateButtonVisibility(
    pageCount: number,
    pageIndex: number,
    totalSize: number,
    endElement: number
  ): void {
    this.isPreviousButtonDisabled = this.hidePreviousButton(pageCount, pageIndex);
    this.isNextButtonDisabled = this.hideNextButton(endElement, pageCount, totalSize, pageIndex);
  }
}
