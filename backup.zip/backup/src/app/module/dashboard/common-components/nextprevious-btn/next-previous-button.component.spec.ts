import { ComponentFixture, ComponentFixtureAutoDetect, TestBed } from '@angular/core/testing';

import { NextPreviousButtonComponent } from './next-previous-button.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('NextPreviousButtonComponent', () => {
  let component: NextPreviousButtonComponent;
  let fixture: ComponentFixture<NextPreviousButtonComponent>;
  let mockProps: {
    endElement: number;
    pageCount: number;
    pageIndex: number;
    totalSize: number;
    prevBtnDisable: boolean;
    nxtBtnDisable: boolean;
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [NextPreviousButtonComponent],
      providers: [{ provide: ComponentFixtureAutoDetect, useValue: true }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(NextPreviousButtonComponent);
    component = fixture.componentInstance;
    mockProps = {
      pageIndex: 1,
      pageCount: 5,
      prevBtnDisable: false,
      endElement: 5,
      totalSize: 10,
      nxtBtnDisable: false
    };
    component.props = mockProps;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('If the user clicks last record from the item, next button should disable', () => {
    let endElement = mockProps.endElement;
    let pCount = mockProps.pageCount;
    let pageIndex = mockProps.pageIndex;
    endElement = 19;
    pCount = 2;
    pageIndex = 8;
    const result = component.hideNextButton(endElement, pCount, mockProps.totalSize, pageIndex);
    expect(result).toBeTruthy();
  });

  it('If the user not clicked last record from the item, next button should enable', () => {
    let endElement = mockProps.endElement;
    let pCount = mockProps.pageCount;
    let pageIndex = mockProps.pageIndex;
    endElement = 20;
    pCount = 2;
    pageIndex = 8;
    const result = component.hideNextButton(endElement, pCount, mockProps.totalSize, pageIndex);
    expect(result).toBeFalsy();
  });

  it('Disable previous button if the user clicks or navigate to first item of the record', () => {
    let pageCount = mockProps.pageCount;
    pageCount = 1;
    let pageIndex = mockProps.pageIndex;
    pageIndex = 0;
    const result = component.hidePreviousButton(pageCount, pageIndex);
    expect(result).toBeTruthy();
  });

  it('Enable previous button if the user clicks or navigate to second item of the record', () => {
    let pageCount = mockProps.pageCount;
    pageCount = 1;
    let pageIndex = mockProps.pageIndex;
    pageIndex = 1;
    const result = component.hidePreviousButton(pageCount, pageIndex);
    expect(result).toBeFalsy();
  });
});
