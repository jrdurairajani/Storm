import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { POI } from '../../models/map';
import {
  AddSource,
  Details,
  EMPTY_SECURITY_THREAT,
  Impact,
  MediaFile,
  SecurityThreat,
  SecurityThreatLocation,
  SecurityThreatSummary,
  SecurityThreatViewMode,
  ThreatIncidentLevel
} from '../../models/security-threat';
import { OpenStreetMapService } from '../../services/osm.service';

/*
   This component is responsible for the data input and rendering of a new Security Event or a Security Threat
  Communication with the persistency layer is not scope of this component.
 */
@Component({
  selector: 'strm-security-threat-view-form',
  templateUrl: './threat-view-form.component.html',
  styleUrls: ['./threat-view-form.component.scss']
})
export class ThreatViewFormComponent implements OnChanges, OnInit {
  @Input() public id: string;
  @Input() public data: SecurityThreat = EMPTY_SECURITY_THREAT;

  @Input() public key: string;
  @Input() public mode: SecurityThreatViewMode;
  @Input() public isEdit: boolean;

  @Input() public saveCallback;
  @Input() public editCallback;
  @Input() public setSaveDisabled;

  public poi: POI;
  public locationInput: SecurityThreatLocation;
  public locationOutput: SecurityThreatLocation;
  public summary: SecurityThreatSummary;
  public files: (MediaFile | File)[] = [];
  public details: Details;
  public threatIncident: ThreatIncidentLevel;
  public source: AddSource[] = [];
  public impactLevel: Impact;
  public poiInput: POI;
  public poiOutput: POI;

  isImageUploadError = false;
  sourceMode = 'noApiSource';

  constructor(private openStreetMapService: OpenStreetMapService) {}

  ngOnChanges(changes: SimpleChanges): void {
    const initialize = this.data && changes.data?.previousValue == undefined;
    const next = changes.id && changes.data;

    if (initialize || next) {
      this.assignData(this.data);
    }
  }

  public async ngOnInit(): Promise<void> {
    this.initPoi();
  }

  private initPoi(): void {
    if (!this.poiInput) {
      this.poiInput = {};
    }

    if (!this.poiInput?.markers) {
      this.poiInput.markers = [];
    }
    if (!this.poiInput?.polygons) {
      this.poiInput.polygons = [];
    }
    if (!this.poiInput?.bounds) {
      this.poiInput.bounds = [];
    }
  }

  public receiveLocation(location: SecurityThreatLocation): void {
    this.locationOutput = location;
    this.poiInput = { ...this.openStreetMapService.handleLocationUpdate(location, this.poiInput) };
  }

  public receiveFiles(files: (MediaFile | File)[]): void {
    this.files = files;
  }

  public receiveMap(poi: POI): void {
    this.poiInput.markers = poi.markers;
    this.poiInput.polygons = poi.polygons;
    this.poiInput.bounds = poi.bounds;
    this.poiOutput = poi;
  }

  public receiveSummary(summary: SecurityThreatSummary): void {
    this.summary = summary;
    if (this.mode === 'create' || this.isEdit) {
      this.setSaveDisabled(summary.isError || this.isImageUploadError);
    } else {
      this.setSaveDisabled(true);
    }
  }

  public receiveSource(source: AddSource[]): void {
    this.source = source;
  }

  public receiveDetails(details: Details): void {
    this.details = details;
  }

  public receiveThreadLevel(threatIncident: ThreatIncidentLevel): void {
    this.threatIncident = threatIncident;
  }

  public receiveImpact(impact: Impact): void {
    this.impactLevel = impact;
  }

  public isImageUploadValid(isValid: boolean): void {
    this.isImageUploadError = !isValid;
    this.setSaveDisabled(this.summary.isError || this.isImageUploadError);
  }

  public getPayload(): SecurityThreat {
    return {
      location: this.locationOutput,
      summary: this.summary,
      source: this.source,
      threatImpact: this.impactLevel,
      incidentThreatLevel: this.threatIncident,
      details: this.details,
      poi: this.poi,
      mediaFiles: this.files?.filter((f) => f instanceof MediaFile) as MediaFile[]
    };
  }

  public getFilePayload(): File[] {
    return this.files?.filter((f) => f instanceof File) as File[];
  }

  private assignData(data: SecurityThreat): void {
    this.summary = data?.summary;
    this.source = data?.source;
    this.impactLevel = data?.threatImpact;
    this.threatIncident = data?.incidentThreatLevel;
    this.details = data?.details;
    this.poi = data?.poi;
    this.files = data?.mediaFiles;
    this.locationInput = data.location;
    this.locationInput.marker = this.openStreetMapService.getMarker(data.poi);
    this.locationInput.bounds = this.openStreetMapService.getBounds(data.poi);
  }
}
