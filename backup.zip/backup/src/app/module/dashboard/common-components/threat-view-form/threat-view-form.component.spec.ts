import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';

import { ToastrModule } from 'ngx-toastr';
import { ThreatViewFormComponent } from './threat-view-form.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SecurityThreatLocation } from '../../models/security-threat';
import { OpenStreetMapService } from '../../services/osm.service';

describe('ThreatViewFormComponent', () => {
  let component: ThreatViewFormComponent;
  let fixture: ComponentFixture<ThreatViewFormComponent>;
  let openStreetMapService: OpenStreetMapService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { paramMap: convertToParamMap({ id: 'create' }) } }
        }
      ],
      imports: [HttpClientTestingModule, ToastrModule.forRoot()],
      declarations: [ThreatViewFormComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreatViewFormComponent);
    component = fixture.componentInstance;
    openStreetMapService = TestBed.inject(OpenStreetMapService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call handleLocationUpdate method from OpenStreetMapService when receiveLocation is called', () => {
    const testLocation: SecurityThreatLocation = {
      osmId: 123456,
      osmType: 'node',
      primaryLocation: 'Test Location',
      airportCode: 'TST',
      involvedCountries: ['Testland'],
      country: 'Testland',
      bounds: null,
      marker: {
        coordinates: { lat: 10, lng: 20 },
        type: 'primary'
      }
    };
    const handleLocationUpdateSpy = spyOn(openStreetMapService, 'handleLocationUpdate');

    component.receiveLocation(testLocation);

    expect(handleLocationUpdateSpy).toHaveBeenCalled();
  });
});
