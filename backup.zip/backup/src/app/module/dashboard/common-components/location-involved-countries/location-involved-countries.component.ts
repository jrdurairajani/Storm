import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { CityCountries } from '../../models/involved-countries';
import { Subscription } from 'rxjs';
import { SecurityThreatViewMode } from '../../models/security-threat';

@Component({
  selector: 'strm-location-involved-countries',
  templateUrl: './location-involved-countries.component.html',
  styleUrls: ['./location-involved-countries.component.scss']
})
export class LocationInvolvedCountriesComponent implements OnInit, OnDestroy {
  @Input() set countriesDetails(address: string[] | CityCountries[]) {
    if (!address) this.countriesDisplay = 'None';
    this.threatDetailsResult(address);
  }
  @Input() public mode: SecurityThreatViewMode;
  @Output() public selectedInvolvedCountries = new EventEmitter<CityCountries[] | string[]>();
  public involvedCountries!: string[] | CityCountries[];
  public selectedCountries: string[] | CityCountries[];
  private subscriptions = new Subscription();
  public countriesDisplay = '';
  constructor(private apiSecurityThreatService: ApiSecurityThreatService) {}

  public async ngOnInit(): Promise<void> {
    if (this.countriesDetails) {
      this.threatDetailsResult(this.countriesDetails);
    }
    const sub = this.apiSecurityThreatService
      .getInvolvedCountries()
      .subscribe((airportList: CityCountries[]) => {
        this.involvedCountries = airportList;
      });
    this.subscriptions.add(sub);
  }

  private threatDetailsResult(countriesDetails: CityCountries[] | string[]): void {
    if (countriesDetails?.length > 0) {
      this.selectedCountries = countriesDetails;
      this.countriesDisplay = this.selectedCountries.map((country) => country.name).join(', ');
      this.selectedInvolvedCountries.emit(this.selectedCountries);
    }
  }

  public onSelect(countries: CityCountries[]): void {
    this.selectedInvolvedCountries.emit(countries);
  }

  public onClear(): void {
    this.selectedInvolvedCountries.emit(null);
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
