import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LocationInvolvedCountriesComponent } from './location-involved-countries.component';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { of } from 'rxjs';
import { CityCountries } from '../../models/involved-countries';

describe('LocationInvolvedCountriesComponent', () => {
  let component: LocationInvolvedCountriesComponent;
  let fixture: ComponentFixture<LocationInvolvedCountriesComponent>;
  let apiSecurityThreatService: jasmine.SpyObj<ApiSecurityThreatService>;

  beforeEach(async () => {
    const mockApiSecurityThreatService = jasmine.createSpyObj('ApiSecurityThreatService', [
      'getInvolvedCountries'
    ]);

    await TestBed.configureTestingModule({
      declarations: [LocationInvolvedCountriesComponent],
      providers: [{ provide: ApiSecurityThreatService, useValue: mockApiSecurityThreatService }]
    });

    fixture = TestBed.createComponent(LocationInvolvedCountriesComponent);
    component = fixture.componentInstance;
    apiSecurityThreatService = TestBed.inject(
      ApiSecurityThreatService
    ) as jasmine.SpyObj<ApiSecurityThreatService>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch involved countries on ngOnInit', () => {
    const mockCountries: CityCountries[] = [
      { name: 'Country1', code: 'AG' },
      { name: 'Country2', code: 'AG' }
    ];
    apiSecurityThreatService.getInvolvedCountries.and.returnValue(of(mockCountries));

    component.ngOnInit();

    expect(apiSecurityThreatService.getInvolvedCountries).toHaveBeenCalled();
    expect(component.involvedCountries).toEqual(mockCountries);
  });

  it('should emit selected IATA code on onSelect', () => {
    const mockCountriesDetails: CityCountries[] = [{ name: 'Country1', code: 'AG' }];
    spyOn(component.selectedInvolvedCountries, 'emit');

    component.onSelect(mockCountriesDetails);

    expect(component.selectedInvolvedCountries.emit).toHaveBeenCalledWith(mockCountriesDetails);
  });

  it('should emit null on onClear', () => {
    spyOn(component.selectedInvolvedCountries, 'emit');

    component.onClear();

    expect(component.selectedInvolvedCountries.emit).toHaveBeenCalledWith(null);
  });

  it('should unsubscribe from subscriptions on ngOnDestroy', () => {
    spyOn(component['subscriptions'], 'unsubscribe');

    component.ngOnDestroy();
    expect(component['subscriptions'].unsubscribe).toHaveBeenCalled();
  });
});
