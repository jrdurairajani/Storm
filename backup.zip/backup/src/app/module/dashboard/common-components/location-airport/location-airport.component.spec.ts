import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LocationAirportComponent } from './location-airport.component';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { of } from 'rxjs';
import { AirportDetails } from '../../models/airport-details';

describe('LocationAirportComponent', () => {
  let component: LocationAirportComponent;
  let fixture: ComponentFixture<LocationAirportComponent>;
  let apiSecurityThreatServiceSpy: jasmine.SpyObj<ApiSecurityThreatService>;

  beforeEach(async () => {
    const mockApiSecurityThreat = jasmine.createSpyObj('ApiSecurityThreatService', ['getAirports']);

    await TestBed.configureTestingModule({
      declarations: [LocationAirportComponent],
      providers: [{ provide: ApiSecurityThreatService, useValue: mockApiSecurityThreat }]
    });

    fixture = TestBed.createComponent(LocationAirportComponent);
    component = fixture.componentInstance;
    apiSecurityThreatServiceSpy = TestBed.inject(
      ApiSecurityThreatService
    ) as jasmine.SpyObj<ApiSecurityThreatService>;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should set airports when mode is not "details"', () => {
    const airportList: AirportDetails[] = [
      {
        airportName: 'NEW RIVER VALLEY AIRPORT',
        city: 'DUBLIN',
        cityIataCode: 'PSK',
        country: 'UNITED STATES',
        iataCode: 'PSK',
        icaoCode: 'ABC',
        id: '36042dc8-7de3-433d-b6e3-e28bfe713815'
      }
    ];
    apiSecurityThreatServiceSpy.getAirports.and.returnValue(of(airportList));

    component.ngOnInit();

    expect(component.airports).toEqual(component.mapListOfAirports(airportList));
    expect(apiSecurityThreatServiceSpy.getAirports).toHaveBeenCalledOnceWith();
  });

  it('should filter airports based on the query', () => {
    const airportList: AirportDetails[] = [
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'AAA',
        icaoCode: 'ICAOAAA',
        city: 'City1',
        country: 'Country1',
        airportName: 'Airport1'
      },
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'BBB',
        icaoCode: 'ICAOBBB',
        city: 'City2',
        country: 'Country2',
        airportName: 'Airport2'
      }
    ];

    component.airports = airportList;

    component.filterAirport({ query: 'BB', originalEvent: new Event('input') });

    expect(component.filteredAirports).toEqual([
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'BBB',
        icaoCode: 'ICAOBBB',
        city: 'City2',
        country: 'Country2',
        airportName: 'Airport2'
      }
    ]);
  });

  it('should filter airports case-insensitively', () => {
    const airportList: AirportDetails[] = [
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'AAA',
        icaoCode: 'ICAOAAA',
        city: 'City1',
        country: 'Country1',
        airportName: 'Airport1'
      },
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'BBB',
        icaoCode: 'ICAOBBB',
        city: 'City2',
        country: 'Country2',
        airportName: 'Airport2'
      }
    ];

    component.airports = airportList;

    component.filterAirport({ query: 'bbb', originalEvent: new Event('input') });

    expect(component.filteredAirports).toEqual([
      {
        id: '12345',
        cityIataCode: 'ABC',
        iataCode: 'BBB',
        icaoCode: 'ICAOBBB',
        city: 'City2',
        country: 'Country2',
        airportName: 'Airport2'
      }
    ]);
  });
  it('should emit selected IATA code on onSelect', () => {
    const selectedAirport: AirportDetails = {
      id: '12345',
      cityIataCode: 'ABC',
      iataCode: 'BBB',
      icaoCode: 'ICAOBBB',
      city: 'City2',
      country: 'Country2',
      airportName: 'Airport2'
    };
    spyOn(component.selectedIATACode, 'emit');

    component.onSelect(selectedAirport);

    expect(component.selectedIATACode.emit).toHaveBeenCalledWith('BBB');
  });

  it('should emit null on onClear', () => {
    spyOn(component.selectedIATACode, 'emit');

    component.onClear();

    expect(component.selectedIATACode.emit).toHaveBeenCalledWith(null);
  });

  it('should unsubscribe from subscriptions on ngOnDestroy', () => {
    spyOn(component['subscriptions'], 'unsubscribe');

    component.ngOnDestroy();
    expect(component['subscriptions'].unsubscribe).toHaveBeenCalled();
  });
});
