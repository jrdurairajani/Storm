import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { AirportDetails } from '../../models/airport-details';
import { Subscription } from 'rxjs';
import { SecurityThreatViewMode } from '../../models/security-threat';

interface AutoCompleteCompleteEvent {
  originalEvent: Event;
  query: string;
}
@Component({
  selector: 'strm-location-airport',
  templateUrl: './location-airport.component.html',
  styleUrls: ['./location-airport.component.scss']
})
export class LocationAirportComponent implements OnInit, OnDestroy {
  @Output() public selectedIATACode = new EventEmitter<string>();
  @Input() set airportDetails(address: AirportDetails) {
    if (!address) this.displayAirtport = 'None';
    this.threatDetailsResult(address);
  }
  public selectedAirport: AirportDetails;
  public displayAirtport = '';
  @Input() public mode: SecurityThreatViewMode;
  public airports: AirportDetails[];
  public filteredAirports: AirportDetails[] | undefined;
  private subscriptions = new Subscription();
  constructor(private apisecurityThreatService: ApiSecurityThreatService) {}

  public ngOnInit(): void {
    if (this.airportDetails) {
      this.threatDetailsResult(this.airportDetails);
    }
    const sub = this.apisecurityThreatService
      .getAirports()
      .subscribe((airportList: AirportDetails[]) => {
        this.airports = this.mapListOfAirports(airportList);
      });
    this.subscriptions.add(sub);
  }

  private threatDetailsResult(airportDetails: AirportDetails): void {
    if (airportDetails) {
      const airportLabel = {
        id: airportDetails.id,
        iataCode: airportDetails.iataCode,
        icaoCode: airportDetails.icaoCode,
        airportName: airportDetails.airportName,
        cityIataCode: airportDetails.cityIataCode,
        city: airportDetails.city,
        country: airportDetails.country,
        airportLocation: this.prepareDisplayAirtport(airportDetails)
      };
      this.selectedAirport = airportLabel;
      this.displayAirtport = airportLabel.airportLocation;
      this.selectedIATACode.emit(this.selectedAirport.iataCode);
    }
  }

  private prepareDisplayAirtport(selectedAirport: AirportDetails): string {
    let codes;
    if (selectedAirport.iataCode && selectedAirport.icaoCode) {
      codes = `${selectedAirport.iataCode}/${selectedAirport.icaoCode}`;
    } else if (selectedAirport.iataCode) {
      codes = selectedAirport.iataCode;
    } else if (selectedAirport.icaoCode) {
      codes = selectedAirport.icaoCode;
    }

    return `${codes}, ${this.capitalizeFirstLetter(
      selectedAirport.airportName
    )}, ${this.capitalizeFirstLetter(selectedAirport.city)}, ${this.capitalizeFirstLetter(
      selectedAirport.country
    )}`;
  }

  private capitalizeFirstLetter(word: string): string {
    if (!word) return '';
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }

  public mapListOfAirports(airportList: AirportDetails[]): AirportDetails[] {
    const airports = airportList.map((airport: AirportDetails) => {
      const airportNameTitlecase = this.formatAirportLocation(airport.airportName);
      const airportCityTitlecase = this.formatAirportLocation(airport.city);
      const airportCountryTitlecase = this.formatAirportLocation(airport.country);
      const filteredIcaoCode = this.formatIcaoCode(airport.icaoCode);
      return this.prepareAirportDetails(
        airport,
        filteredIcaoCode,
        airportNameTitlecase,
        airportCityTitlecase,
        airportCountryTitlecase
      );
    });
    return airports;
  }

  prepareAirportDetails(
    airport: AirportDetails,
    filteredIcaoCode: string,
    airportNameTitlecase: string,
    airportCityTitlecase: string,
    airportCountryTitlecase: string
  ): AirportDetails {
    return {
      ...airport,
      airportLocation:
        airport.iataCode +
        filteredIcaoCode +
        ', ' +
        '\n' +
        airportNameTitlecase +
        ', ' +
        '\n' +
        airportCityTitlecase +
        ', ' +
        airportCountryTitlecase
    };
  }

  private mapAirport(airportCode: string, airports: AirportDetails[]): AirportDetails {
    return airports.find((airport: AirportDetails) => airport.iataCode === airportCode);
  }

  public filterAirport(event: AutoCompleteCompleteEvent): void {
    const filtered: AirportDetails[] = [];
    const query = event.query;
    for (let i = 0; i < (this.airports as AirportDetails[]).length; i++) {
      const country = (this.airports as AirportDetails[])[i];
      if (country.iataCode.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      } else if (country.icaoCode?.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      } else if (country.city.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      } else if (country.country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      } else if (country.airportName.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredAirports = filtered;
  }

  public onSelect(airport: AirportDetails): void {
    this.selectedIATACode.emit(airport.iataCode);
  }

  public onClear(): void {
    this.selectedIATACode.emit(null);
  }

  public formatAirportLocation(airportInfo: string): string {
    return airportInfo
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.toLowerCase().slice(1))
      .join(' ');
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private formatIcaoCode(icaoCode: string): string {
    let filteredIcaoCode = icaoCode;
    if (filteredIcaoCode == null) {
      filteredIcaoCode = '';
    } else {
      filteredIcaoCode = '/' + filteredIcaoCode;
    }
    return filteredIcaoCode;
  }
}
