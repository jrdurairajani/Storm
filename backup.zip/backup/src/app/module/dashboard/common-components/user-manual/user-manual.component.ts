import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ApiDashboardService } from '../../services/api-dashboard.service';

@Component({
  selector: 'strm-user-manual',
  templateUrl: './user-manual.component.html',
  styleUrls: ['./user-manual.component.scss']
})
export class UserManualComponent implements OnInit {
  dateUpload = '';
  file: Blob;
  name = '';
  constructor(private apiDashboard: ApiDashboardService) {}

  ngOnInit(): void {
    this.getData();
  }

  download(): void {
    const url = window.URL.createObjectURL(this.file);
    const anchor = document.createElement('a');
    anchor.download = this.name;
    anchor.href = url;
    anchor.click();
  }

  getData(): void {
    this.apiDashboard.downloadManual().subscribe((res) => {
      const date = new Date(res.dateUpload);
      this.dateUpload = moment(date).format('DD MMM YYYY');
      this.file = new Blob([res.body], { type: res.type });
      this.name = res.fileName;
    });
  }
}
