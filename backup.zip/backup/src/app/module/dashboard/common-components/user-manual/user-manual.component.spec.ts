import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as moment from 'moment';
import { of } from 'rxjs';
import { ApiDashboardService } from '../../services/api-dashboard.service';

import { UserManualComponent } from './user-manual.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('UserManualComponent', () => {
  let component: UserManualComponent;
  let fixture: ComponentFixture<UserManualComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, BrowserAnimationsModule],
      declarations: [UserManualComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserManualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getData should retrieve from endpoint and assign values to global variables', () => {
    const dateUpload = '03.04.1995';
    const fileName = 'fileName';
    const type = 'content-type';

    const mapsService = TestBed.inject(ApiDashboardService);
    const mock = { body: '', fileName, dateUpload, type };
    spyOn(mapsService, 'downloadManual').and.returnValue(of(mock));
    component.getData();

    expect(component.name).toEqual(fileName);
    const blob = new Blob([''], { type });
    expect(component.file).toEqual(blob);
    const dateFormatted = moment(dateUpload).format('DD MMM YYYY');
    expect(component.dateUpload).toEqual(dateFormatted);
  });
});
