import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxQuillComponent } from './ngx-quill.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('NgxQuillComponent', () => {
  let component: NgxQuillComponent;
  let fixture: ComponentFixture<NgxQuillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [],
      declarations: [NgxQuillComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NgxQuillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
