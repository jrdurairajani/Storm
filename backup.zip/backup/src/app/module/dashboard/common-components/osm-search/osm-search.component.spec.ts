import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';

import { OpenStreetMapSearchComponent } from './osm-search.component';
import { OpenStreetMapService } from '../../services/osm.service';
import { of } from 'rxjs';
import { ToastrModule } from 'ngx-toastr';
import { IMapService, OpenStreetMapSearchResult } from '../../models/open-street-map';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('OpenStreetMapSearchComponent', () => {
  let component: OpenStreetMapSearchComponent;
  let fixture: ComponentFixture<OpenStreetMapSearchComponent>;

  let osmServiceMock: IMapService;
  const mockResponse: OpenStreetMapSearchResult[] = [
    {
      place_id: 371380173,
      licence: 'Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright',
      osm_type: 'relation',
      osm_id: 175905,
      lat: '40.7127281',
      lon: '-74.0060152',
      class: 'boundary',
      type: 'administrative',
      place_rank: 10,
      importance: 0.8175766114518461,
      addresstype: 'city',
      name: 'Nowy Jork',
      display_name: 'Nowy Jork, Stany Zjednoczone',
      address: {
        city: 'Nowy Jork',
        state: 'Nowy Jork',
        country: 'Stany Zjednoczone',
        country_code: 'us'
      },
      boundingbox: ['40.4765780', '40.9176300', '-74.2588430', '-73.7002330']
    },
    {
      place_id: 306170897,
      licence: 'Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright',
      osm_type: 'relation',
      osm_id: 61320,
      lat: '43.1561681',
      lon: '-75.8449946',
      class: 'boundary',
      type: 'administrative',
      place_rank: 8,
      importance: 0.7655846409089574,
      addresstype: 'state',
      name: 'Nowy Jork',
      display_name: 'Nowy Jork, Stany Zjednoczone',
      address: {
        state: 'Nowy Jork',
        country: 'Stany Zjednoczone',
        country_code: 'us'
      },
      boundingbox: ['40.4765780', '45.0158611', '-79.7619758', '-71.7909720']
    }
  ];

  beforeEach(async () => {
    osmServiceMock = {
      search: jasmine.createSpy('search').and.returnValue(of(mockResponse))
    };

    await TestBed.configureTestingModule({
      imports: [ToastrModule.forRoot()],
      declarations: [OpenStreetMapSearchComponent],
      providers: [{ provide: OpenStreetMapService, useValue: osmServiceMock }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(OpenStreetMapSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call search on OsmService, update filteredAddresses, and handle loading state', fakeAsync(() => {
    const testQuery = 'test';
    component.searchQuery = testQuery;

    spyOn(component, 'showDropdown');

    component.searchAddress();
    tick();

    expect(osmServiceMock.search).toHaveBeenCalledWith(testQuery);
    expect(component.filteredAddresses).toEqual(mockResponse);
    expect(component.isLoading).toBeFalse();
    expect(component.showDropdown).toHaveBeenCalled();
  }));

  it('should emit selected address object when an OpenStreetMapSearchResult object is passed', () => {
    const mockAddress: OpenStreetMapSearchResult = {
      place_id: 1,
      display_name: 'Test Address'
    };

    spyOn(component.address, 'emit');

    component.onSelectAddress(mockAddress);

    expect(component.searchQuery).toEqual(mockAddress.display_name);
    expect(component.address.emit).toHaveBeenCalledWith(mockAddress);
  });

  it('should emit an object with empty address object when null is passed', () => {
    spyOn(component.address, 'emit');

    component.onSelectAddress(null);

    expect(component.searchQuery).toBeUndefined();
    expect(component.address.emit).toHaveBeenCalledWith({ address: {} });
  });

  it('should not emit or change searchQuery when a string is passed', () => {
    const initialSearchQuery = component.searchQuery;
    spyOn(component.address, 'emit');

    component.onSelectAddress('Test String' as any);

    expect(component.searchQuery).toEqual(initialSearchQuery);
    expect(component.address.emit).not.toHaveBeenCalled();
  });
});
