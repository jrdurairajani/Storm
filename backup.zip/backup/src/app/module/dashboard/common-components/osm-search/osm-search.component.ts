import { Component, EventEmitter, Input, OnDestroy, Output, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { OverlayOptions } from 'primeng/api';
import { Dropdown } from 'primeng/dropdown';
import { Subscription } from 'rxjs';
import { OpenStreetMapSearchResult } from '../../models/open-street-map';
import { SecurityThreatViewMode } from '../../models/security-threat';
import { OpenStreetMapService } from '../../services/osm.service';

@Component({
  selector: 'strm-osm-search',
  templateUrl: './osm-search.component.html',
  styleUrls: ['./osm-search.component.scss']
})
export class OpenStreetMapSearchComponent implements OnDestroy {
  public displayNone: string;
  public searchQuery: string;
  @ViewChild('dropdown') public dropdown: Dropdown;
  @Input() set setAddress(address: OpenStreetMapSearchResult) {
    if (!address) return;
    this.searchQuery = address.display_name;
    this.address.emit(address);
  }
  @Input() public mode: SecurityThreatViewMode;
  @Output() public address = new EventEmitter<OpenStreetMapSearchResult>();

  public filteredAddresses: OpenStreetMapSearchResult[] = [];
  private timeOut = 5000;
  public isLoading = false;
  private subscriptions: Subscription = new Subscription();

  constructor(
    private osmService: OpenStreetMapService,
    private toast: ToastrService
  ) {}

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public getOverlayOptions(): OverlayOptions {
    return {
      listener: () => {
        return false;
      }
    };
  }

  public searchAddress(): void {
    if (!this.searchQuery) return;
    this.isLoading = true;
    const searchSubscription = this.osmService.search(this.searchQuery).subscribe({
      next: (openStreetMapSearch: OpenStreetMapSearchResult[]) => {
        this.filteredAddresses = [...openStreetMapSearch];
        this.showDropdown();
        this.isLoading = false;
      },
      error: (error) => {
        this.toast.error(error, 'Error when fetching addresses', {
          timeOut: this.timeOut
        });
        this.isLoading = false;
      }
    });
    this.subscriptions.add(searchSubscription);
  }

  public showDropdown(): void {
    const dropdownElement = this.dropdown.el.nativeElement;
    const trigger = dropdownElement.querySelector('.p-dropdown-trigger');
    trigger.click();
  }

  public onSelectAddress(event: string | OpenStreetMapSearchResult): void {
    let selectedAddress = event;
    if (selectedAddress === null) {
      selectedAddress = {};
      selectedAddress.address = {};
    }
    if (typeof selectedAddress === 'object' && selectedAddress !== null) {
      this.searchQuery = selectedAddress.display_name;
      this.address.emit(selectedAddress);
    }
  }
}
