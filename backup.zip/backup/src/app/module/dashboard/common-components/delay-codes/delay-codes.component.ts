import { Component } from '@angular/core';

@Component({
  selector: 'strm-delay-codes',
  templateUrl: './delay-codes.component.html',
  styleUrls: ['./delay-codes.component.scss']
})
export class DelayCodesComponent {
  goToLink(): void {
    const url = 'https://milweb.airfrance.fr/MilordWeb/delayCode.do?action=init';
    window.open(url, '_blank');
  }
}
