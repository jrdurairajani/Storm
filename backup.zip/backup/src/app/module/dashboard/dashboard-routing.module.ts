import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EventOverviewComponent } from 'src/app/module/dashboard/intel-security/event-overview/event-overview.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SecurityThreatComponent } from './intel-security/security-threat/security-threat.component';
import { ThreatOverviewComponent } from './intel-security/threat-overview/threat-overview.component';
import { EventCreationComponent } from './intel-security/event-creation/event-creation.component';
import { SecurityEventComponent } from './intel-security/event-details-container/security-event.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    pathMatch: 'full'
  },
  {
    path: 'security-events',
    component: EventOverviewComponent,
    pathMatch: 'full'
  },
  {
    path: 'security-events/create',
    component: EventCreationComponent,
    pathMatch: 'full'
  },
  {
    path: 'security-threats',
    component: ThreatOverviewComponent,
    pathMatch: 'full'
  },
  {
    path: 'security-events/:id',
    component: SecurityEventComponent,
    pathMatch: 'full'
  },
  {
    path: 'security-threats/:id',
    component: SecurityThreatComponent,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
