import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/internal/Observable';
import { Role } from 'src/app/core/model/role.model';
import { User } from 'src/app/core/model/user.model';
import { InitService } from 'src/app/core/services/init.service';
import { RootState } from 'src/app/model/root-state.model';
import * as RootSelectors from '../../../state/root.selectors';

@Component({
  selector: 'strm-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  Role = Role;
  currentUser: Observable<User | undefined> = this.store.select(RootSelectors.selectCurrentUser);

  constructor(
    private readonly store: Store<RootState>,
    private initService: InitService
  ) {}

  ngOnInit(): void {
    this.initService.displayBack = false;
  }
}
