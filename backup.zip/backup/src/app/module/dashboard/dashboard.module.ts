import { NgModule } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSliderModule } from '@angular/material/slider';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { QuillModule } from 'ngx-quill';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { AccordionModule } from 'primeng/accordion';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FstMaterialModule } from 'src/app/fst-material/fst-material.module';
import { SharedModule } from '../shared/shared.module';
import { IntelSecurityComponent } from './intel-security/intel-security.component';
import { EventOverviewComponent } from './intel-security/event-overview/event-overview.component';
import { ImpactComponent } from './intel-security/impact/impact.component';
import { SummaryPipe } from './common-pipes/summary.pipe';
import { HyphenPipe } from './common-pipes/hyphen.pipe';
import { ImageUploadComponent } from './intel-security/security-threat/image-upload/image-upload.component';
import { SecurityThreatComponent } from './intel-security/security-threat/security-threat.component';
import { AddSourceComponent } from './intel-security/security-threat/add-source/add-source.component';
import { ThreadImpactComponent } from './intel-security/security-threat/thread-impact/thread-impact.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ThreatIncidentComponent } from './intel-security/security-threat/threat-incident/threat-incident.component';
import { MapComponent } from './intel-security/security-threat/map/map.component';
import { SummaryComponent } from './intel-security/security-threat/summary/summary.component';
import { DetailsHeaderComponent } from './intel-security/security-threat/details-header/details-header.component';
import { DashboardBreadcrumbComponent } from './common-components/dashboard-breadcrumb/dashboard-breadcrumb.component';
import { DelayCodesComponent } from './common-components/delay-codes/delay-codes.component';
import { NgxQuillComponent } from './common-components/ngx-quill/ngx-quill.component';
import { UserManualComponent } from './common-components/user-manual/user-manual.component';
import { ApiDashboardService } from './services/api-dashboard.service';
import { ApiFlightReportService } from './services/api-flight-report.service';
import { ApiSecurityEventService } from './services/api-security-event.service';
import { ApiSecurityThreatService } from './services/api-security-threat.service';
import { ThreatOverviewComponent } from './intel-security/threat-overview/threat-overview.component';
import { DetailsComponent } from './intel-security/security-threat/details/details.component';
import { CountryMultiSelectComponent } from './intel-security/threat-overview/country-multi-select/country-multi-select.component';
import { NextPreviousButtonComponent } from './common-components/nextprevious-btn/next-previous-button.component';
import { DatePipe } from './common-pipes/datetime.pipe';
import { DateSeparatedPipe } from './common-pipes/datetime-separated.pipe';
import { SourceComponent } from './intel-security/security-threat/source/source.component';
import { SearchableListComponent } from './intel-security/threat-overview/searchable-list/searchable-list.component';
import { CapitalizePipe } from './common-pipes/capital-letter.pipe';
import { Pipe2Comma } from './common-pipes/pipe-2-comma.pipe';
import { SplitWord } from './common-pipes/split-word.pipe';
import { CharRemoval } from './common-pipes/charremoval.pipe';
import { ThreatViewFormComponent } from './common-components/threat-view-form/threat-view-form.component';
import { EventCreationComponent } from './intel-security/event-creation/event-creation.component';
import { CommonContainerComponent } from './intel-security/event-details-container/common/common-container.component';
import { SecurityEventComponent } from './intel-security/event-details-container/security-event.component';
import { ReportComponent } from './intel-security/event-details-container/report/report.component';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { MultiSelectModule } from 'primeng/multiselect';
import { ChipsModule } from 'primeng/chips';
import { ButtonModule } from 'primeng/button';
import { ConvertService } from './services/convert.service';
import { ClickStopPropagationDirective } from '../../core/directive/click-stop-propagation.directive';
import { LocationAirportComponent } from './common-components/location-airport/location-airport.component';
import { InputTextModule } from 'primeng/inputtext';
import { ListboxModule } from 'primeng/listbox';
import { OpenStreetMapSearchComponent } from './common-components/osm-search/osm-search.component';
import { LocationInvolvedCountriesComponent } from './common-components/location-involved-countries/location-involved-countries.component';
import { LocationPartComponent } from './intel-security/security-threat/location-part/location-part.component';
import { MedaireAssessmentComponent } from './intel-security/event-details-container/medaire-assessment/medaire-assessment.component';
import { SafehtmlPipe } from './common-pipes/safehtml.pipe';
import { SourceFilteringComponent } from './intel-security/event-overview/source-filtering/source-filtering.component';

@NgModule({
  declarations: [
    DashboardComponent,
    UserManualComponent,
    IntelSecurityComponent,
    DelayCodesComponent,
    EventOverviewComponent,
    ImpactComponent,
    NgxQuillComponent,
    SummaryPipe,
    DashboardBreadcrumbComponent,
    HyphenPipe,
    SecurityThreatComponent,
    ImageUploadComponent,
    SummaryComponent,
    AddSourceComponent,
    ThreadImpactComponent,
    ThreatIncidentComponent,
    MapComponent,
    DetailsHeaderComponent,
    ThreatOverviewComponent,
    DetailsComponent,
    CountryMultiSelectComponent,
    NextPreviousButtonComponent,
    DatePipe,
    DateSeparatedPipe,
    SourceComponent,
    SearchableListComponent,
    CapitalizePipe,
    Pipe2Comma,
    CharRemoval,
    SplitWord,
    ThreatViewFormComponent,
    EventCreationComponent,
    CommonContainerComponent,
    SecurityEventComponent,
    ReportComponent,
    ClickStopPropagationDirective,
    OpenStreetMapSearchComponent,
    LocationAirportComponent,
    LocationInvolvedCountriesComponent,
    LocationPartComponent,
    MedaireAssessmentComponent,
    SafehtmlPipe,
    SourceFilteringComponent
  ],

  imports: [
    CommonModule,
    DashboardRoutingModule,
    FstMaterialModule,
    MatSliderModule,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    QuillModule.forRoot(),
    NgxMaterialTimepickerModule,
    AccordionModule,
    TableModule,
    TagModule,
    MultiSelectModule,
    ChipsModule,
    AutoCompleteModule,
    DropdownModule,
    CalendarModule,
    ButtonModule,
    NgOptimizedImage,
    InputTextModule,
    ListboxModule
  ],
  providers: [
    ApiDashboardService,
    ApiFlightReportService,
    ApiSecurityEventService,
    ApiSecurityThreatService,
    ConvertService
  ]
})
export class DashboardModule {}
