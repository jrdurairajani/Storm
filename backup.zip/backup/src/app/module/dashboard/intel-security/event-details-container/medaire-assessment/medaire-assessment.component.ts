import { Component, Input } from '@angular/core';
import { Assessment, SecurityEvent } from '../../../models/security-event';

@Component({
  selector: 'strm-medaire-assessment',
  templateUrl: './medaire-assessment.component.html',
  styleUrls: ['./medaire-assessment.component.scss']
})
export class MedaireAssessmentComponent {
  public assessment: Assessment[];
  public assessmentSource: string;
  @Input() set assessmentSecurityEvent(assessment: SecurityEvent) {
    if (!assessment) return;
    this.assessmentSource = assessment.source;
    this.assessment = assessment?.assessment.filter((assessmentFilter) => {
      return assessmentFilter.description !== '';
    });
  }
}
