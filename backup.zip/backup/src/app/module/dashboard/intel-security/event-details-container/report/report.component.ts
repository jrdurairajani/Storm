import { Component, Input } from '@angular/core';
import { SecurityEvent } from '../../../models/security-event';

@Component({
  selector: 'strm-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent {
  @Input() public reportSecurityEvent: SecurityEvent;
}
