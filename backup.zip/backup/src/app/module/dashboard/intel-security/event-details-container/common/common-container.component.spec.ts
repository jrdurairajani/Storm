import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonContainerComponent } from './common-container.component';
import { SecurityEvent } from '../../../models/security-event';
import { DatePipe } from '../../../common-pipes/datetime.pipe';

describe('CommonContainerComponent', () => {
  let component: CommonContainerComponent;
  let fixture: ComponentFixture<CommonContainerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CommonContainerComponent, DatePipe],
      providers: [
        {
          provide: DatePipe,
          useValue: jasmine.createSpyObj('DatePipe', ['transform'])
        }
      ]
    });

    fixture = TestBed.createComponent(CommonContainerComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set securityEvent and prepare poi on input change', () => {
    const securityEvent: SecurityEvent = {
      id: 'b41f91cb-59d5-44fa-836b-857b07491a1b',
      status: 'CREATED',
      source: 'MEDAIRE',
      region: {
        flag: '-',
        securityRegion: '-',
        regionNameProvider: '-',
        continent: {
          id: '47ed559e-b412-4e86-82fa-291ab32406b2',
          code: 'AS',
          name: 'Asia',
          latitude: '64.116211',
          longitude: '28.246328'
        },
        country: {
          code: 'PK',
          name: 'Pakistan'
        },
        state: '-',
        city: '-',
        location: '-',
        station: '-',
        latitude: 64.116211,
        longitude: 28.246328
      },
      summary: {
        eventDate: '2024-02-14T10:40:28',
        eventLastModifiedDate: '2024-02-14T10:40:28',
        description:
          '<p>Expect disruption across Balochistan province <strong>in the coming days</strong> due to an ongoing shutdown strike by major opposition parties contesting the results of the general elections on 8 February. The parties, including the Balochistan National Party, have been protesting since 10 February, claiming that the results have been rigged. The strike has led to business closures, including in the capital Quetta. A blockade has also been launched along major motorways, with sit-in protests occurring at key intersections in urban centres. A heightened security presence can be expected, and clashes may occur if protesters attempt to breach security cordons and/or stage protracted sit-ins. The security forces are liable to respond with forcible dispersal measures.</p>'
      },
      assessment: [
        {
          header: 'Assessment',
          description: ''
        },
        {
          header: 'Advice',
          description: ''
        },
        {
          header: 'Manager advice',
          description: ''
        },
        {
          header: 'Traveller advice',
          description:
            '<ul>\n    <li>Liaise with local contacts to remain apprised of related gatherings. Avoid all such events as a precaution and to minimise travel delays.</li>\n    <li>Leave an area at the first sign that demonstrators and/or the security forces are gathering.</li>\n    <li>Reconfirm the status of routes before setting out and allow additional time for journeys.</li>\n    <li>Expect increased security measures near strike-related demonstrations. Follow all directives issued by the police.</li>\n    <li>Monitor our Pakistan alerts for updates.</li>\n</ul>'
        },
        {
          header: 'Additional information',
          description: ''
        }
      ],
      report: {
        category: 'Strike, Protest/Rally, Road disruption',
        exactLocation: 'Balochistan, Pakistan',
        service: 'Security',
        eventStart: null,
        eventEnd: null,
        attackType: '',
        perpetrators: '',
        sector: '',
        assetTypes: '',
        secondaryCountries: ''
      },
      impact: {
        severityScore: '1',
        totalFatalities: 1
      }
    };

    component.setSecurityEvent = securityEvent;

    expect(component.securityEvent).toEqual(securityEvent);
    expect(component.poi).toBeDefined();
  });

  it('should not set securityEvent and prepare poi if input is not provided', () => {
    component.setSecurityEvent = null;

    expect(component.securityEvent).toBeUndefined();
    expect(component.poi).toBeUndefined();
  });
});
