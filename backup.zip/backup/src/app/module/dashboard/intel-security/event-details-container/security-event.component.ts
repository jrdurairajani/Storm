import { Component, OnDestroy, OnInit } from '@angular/core';
import { SecurityEventOverview, SourceFilter } from '../../models/security-event-overview';
import { SecurityEvent } from '../../models/security-event';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiSecurityEventService } from '../../services/api-security-event.service';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService
} from '../../services/filter.service';
import { SecurityThreat } from '../../models/security-threat';
import { NextPrevSettings } from '../../models/utils';
import { map, Subscription, switchMap } from 'rxjs';
import { ConvertService } from '../../services/convert.service';
import { Country } from '../../models/common';

const FILTER_CONSUMER_KEY = FilterConsumerKey.EVENTS;

@Component({
  selector: 'strm-event-details-container',
  templateUrl: './security-event.component.html',
  styleUrls: ['./security-event.component.scss']
})
export class SecurityEventComponent implements OnInit, OnDestroy {
  public endElement: number;
  public totalSize: number;
  public pageCount: number;
  public pageIndex: number;
  public prevBtnDisable: boolean;
  public nxtBtnDisable = false;
  public nextPrevSettings: NextPrevSettings;
  public securityEvent: SecurityEvent;

  private subscriptions: Subscription = new Subscription();

  constructor(
    private router: Router,
    private apiSecurityEvent: ApiSecurityEventService,
    private route: ActivatedRoute,
    private filterService: FilterService,
    private convertService: ConvertService
  ) {}

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public ngOnInit(): void {
    const currentId = this.route.snapshot.paramMap.get('id');
    const sub = this.apiSecurityEvent
      .getIncidentDetails(currentId as string)
      .subscribe((securityEventDetails: SecurityEvent) => {
        this.securityEvent = securityEventDetails;
      });
    this.subscriptions.add(sub);

    this.handlePrevState();
    this.passDataNxtPre();
    this.loadEventList(this.pageCount);
  }

  public convertEventToThreat(securityEvent: SecurityEvent): void {
    const eventID = this.route.snapshot.paramMap.get('id');
    const threatData: SecurityThreat = this.convertService.convert(securityEvent, eventID);
    this.router.navigate(['/dashboard/security-threats', 'create'], { state: threatData }).then();
  }

  public handlePrevState(): void {
    const qParams = this.route.snapshot.queryParamMap;
    this.pageCount = parseInt(qParams.get('page'));
    this.pageIndex = parseInt(qParams.get('index'));
    if (this.pageCount == 1 && this.pageIndex == 0) {
      this.prevBtnDisable = true;
    }
  }

  public handleNextState(res: SecurityEventOverview): void {
    this.endElement = res.totalElements;
    this.totalSize = res.size;
    const calc = this.pageCount * this.totalSize - (this.totalSize - (this.pageIndex + 1));
    if (this.endElement === calc) {
      this.nxtBtnDisable = true;
    }
  }

  // TODO: Don't make an unnecessary http call, when this data can be passed through a service from the overview component
  public loadEventList(pageCount: number): void {
    const sub = this.filterService.filterObservable
      .pipe(
        map((filters) => filters.get(FILTER_CONSUMER_KEY)),
        switchMap((filters) =>
          this.apiSecurityEvent.getSecurityEventOverview(
            pageCount,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            (filters?.get(FilterKey.SOURCE) as SourceFilter[]) ?? []
          )
        )
      )
      .subscribe((securityEvents: SecurityEventOverview) => {
        this.handleNextState(securityEvents);
        this.passDataNxtPre();
      });
    this.subscriptions.add(sub);
  }

  // TODO: Make this private and refactor unit tests
  public passDataNxtPre(): void {
    this.nextPrevSettings = {
      pageIndex: this.pageIndex,
      pageCount: this.pageCount,
      prevBtnDisable: this.prevBtnDisable,
      endElement: this.endElement,
      totalSize: this.totalSize,
      nxtBtnDisable: this.nxtBtnDisable
    };
  }

  public setNavData(data: SecurityEvent | SecurityThreat): void {
    this.securityEvent = { ...(data as SecurityEvent) };
  }

  public archiveEvent(removalItem: string): void {
    const sub = this.apiSecurityEvent.archive(removalItem).subscribe((resp) => {
      if (resp.status === 'DELETED') {
        this.router.navigate(['dashboard/security-events']).then();
      }
    });
    this.subscriptions.add(sub);
  }
}
