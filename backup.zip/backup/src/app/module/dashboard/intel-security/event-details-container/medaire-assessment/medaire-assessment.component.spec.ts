import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedaireAssessmentComponent } from './medaire-assessment.component';

describe('MedaireAssessmentComponent', () => {
  let component: MedaireAssessmentComponent;
  let fixture: ComponentFixture<MedaireAssessmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MedaireAssessmentComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(MedaireAssessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
