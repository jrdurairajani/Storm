import { Component, Input } from '@angular/core';
import { Coordinates, Marker, POI } from '../../../models/map';
import { SecurityEvent } from '../../../models/security-event';

@Component({
  selector: 'strm-common-container',
  templateUrl: './common-container.component.html',
  styleUrls: ['./common-container.component.scss']
})
export class CommonContainerComponent {
  public securityEvent: SecurityEvent;
  public poi: POI;

  @Input() public set setSecurityEvent(securityEvent: SecurityEvent) {
    if (!securityEvent) return;
    this.securityEvent = securityEvent;
    this.poi = this.prepareMarker(
      this.securityEvent.region.longitude,
      this.securityEvent.region.latitude
    );
  }

  // TODO: should be private and tests should be refactored
  private prepareMarker(lng: number, lat: number): POI {
    const coordinates: Coordinates = { lng, lat };
    const marker: Marker = { coordinates, type: 'regular' };
    const markers: Marker[] = [marker];
    return {
      markers,
      polygons: []
    };
  }
}
