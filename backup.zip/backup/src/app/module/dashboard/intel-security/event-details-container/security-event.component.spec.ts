import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecurityEventComponent } from './security-event.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { SecurityEventOverview } from '../../models/security-event-overview';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('EventDetailsContainerComponent', () => {
  let component: SecurityEventComponent;
  let fixture: ComponentFixture<SecurityEventComponent>;
  const mockActivatedRoute = {
    snapshot: {
      paramMap: convertToParamMap({ id: 1 }),
      queryParamMap: convertToParamMap({ page: '1', index: '0' })
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: ActivatedRoute,
          useValue: mockActivatedRoute
        }
      ],
      imports: [HttpClientTestingModule],
      declarations: [SecurityEventComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable prev button when on first page and index is 0', () => {
    component.handlePrevState();
    expect(component.pageCount).toBe(1);
    expect(component.pageIndex).toBe(0);
    expect(component.prevBtnDisable).toBeTrue();
  });

  it('should disable next button when at the end of list', () => {
    component.pageCount = 1;
    component.pageIndex = 9;
    component.totalSize = 10;

    const res: SecurityEventOverview = {
      totalElements: 10,
      size: 10
    };

    component.handleNextState(res);

    expect(component.nxtBtnDisable).toBeTrue();
  });

  it('should not disable next button when not at the end of list', () => {
    component.pageCount = 1;
    component.pageIndex = 0;
    component.totalSize = 10;

    const res: SecurityEventOverview = {
      totalElements: 20,
      size: 10
    };

    component.handleNextState(res);

    expect(component.nxtBtnDisable).toBeFalse();
  });

  it('should set nextPrevSettings correctly', () => {
    component.pageIndex = 1;
    component.pageCount = 2;
    component.prevBtnDisable = false;
    component.endElement = 30;
    component.totalSize = 10;
    component.nxtBtnDisable = false;

    component.passDataNxtPre();

    expect(component.nextPrevSettings).toEqual({
      pageIndex: 1,
      pageCount: 2,
      prevBtnDisable: false,
      endElement: 30,
      totalSize: 10,
      nxtBtnDisable: false
    });
  });
});
