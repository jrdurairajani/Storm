import { Component, OnInit } from '@angular/core';
import { ApiDashboardService } from '../services/api-dashboard.service';

@Component({
  selector: 'strm-intel-security',
  templateUrl: './intel-security.component.html',
  styleUrls: ['./intel-security.component.scss']
})
export class IntelSecurityComponent implements OnInit {
  public totalEventCount: number;
  public totalThreatCount: number;

  constructor(private apiDashboardCount: ApiDashboardService) {}

  public ngOnInit(): void {
    this.apiDashboardCount.controlRiskNotification().subscribe({
      next: (resp) => {
        this.totalEventCount = resp.securityEventCount;
        this.totalThreatCount = resp.securityThreatCount;
      },
      error: (error) => console.error(error)
    });
  }
}
