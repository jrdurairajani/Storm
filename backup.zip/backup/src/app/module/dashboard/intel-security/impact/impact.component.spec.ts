import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImpactComponent } from './impact.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ImpactComponent', () => {
  let component: ImpactComponent;
  let fixture: ComponentFixture<ImpactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ImpactComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ImpactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
