import { Component, Input, OnInit, OnChanges, ElementRef } from '@angular/core';

@Component({
  selector: 'strm-impact',
  templateUrl: './impact.component.html',
  styleUrls: ['./impact.component.scss']
})
export class ImpactComponent implements OnInit, OnChanges {
  @Input() getImpact: number;

  constructor(private el: ElementRef) {}

  ngOnInit(): void {
    this.scorecard();
  }

  ngOnChanges(change) {
    this.getImpact = change.getImpact.currentValue;
    if (change.getImpact.previousValue) {
      const impactRating = document.getElementsByClassName(
        `rating_${change.getImpact.previousValue}`
      )[0];
      impactRating.classList.remove('impact-expand');
      this.impactHighlight();
    }
  }

  scorecard(): void {
    const impactContainer = document.getElementsByClassName('impact-container')[0];
    const bgColors = [
      '#4AA43F',
      '#7EC63B',
      '#A4D442',
      '#C9DB46',
      '#E3DC48',
      '#F1D64D',
      '#F1BB47',
      '#E4752D',
      '#D85425',
      '#CD2B40'
    ];
    if (impactContainer instanceof HTMLElement) {
      for (let i = 1; i <= 10; i++) {
        const div = document.createElement('div');
        div.style.width = '92px';
        div.style.height = '32px';
        div.style.lineHeight = '24px';
        div.style.fontSize = '16px';
        div.style.color = '#ffffff';
        div.style.backgroundColor = bgColors[i - 1];
        div.style.fontFamily =
          "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', sans-serif";
        div.style.fontWeight = 'bold';
        div.className = `rating_${i} flex items-center justify-center cls_rating`;
        div.innerHTML = `${i}`;
        impactContainer.append(div);
      }
    }
    if (this.getImpact) {
      this.impactHighlight();
    }
  }

  impactHighlight() {
    const impactRating = document.getElementsByClassName(`rating_${this.getImpact}`)[0];
    if (impactRating instanceof HTMLElement) {
      impactRating.classList.add('impact-expand');
    } else {
      impactRating.classList.remove('impact-expand');
    }
  }
}
