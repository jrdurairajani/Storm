import { Component, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';

import { ThreatViewFormComponent } from '../../common-components/threat-view-form/threat-view-form.component';
import {
  SecurityThreat,
  SecurityThreatRecord,
  SecurityThreatViewMode
} from '../../models/security-threat';
import { ApiSecurityEventService } from '../../services/api-security-event.service';
import { SecurityEventDTO } from '../../models/security-event';

// TODO: This shouldn't be a different component from SecurityEventComponent
@Component({
  selector: 'strm-event-creation',
  templateUrl: './event-creation.component.html',
  styleUrls: ['./event-creation.component.scss']
})
export class EventCreationComponent implements OnDestroy {
  // TODO: remove this constant
  private static readonly PARENT_PAGE_URL = 'dashboard/security-events';
  // TODO: fix class member signatures
  @ViewChild(ThreatViewFormComponent) form: ThreatViewFormComponent;
  key = 'events';
  id = 'create';
  mode: SecurityThreatViewMode = 'create';
  isEdit = true;
  timeOut = 5000;
  public isSaveDisabled = true;
  data: SecurityThreatRecord;
  private subscriptions: Subscription;

  constructor(
    private toast: ToastrService,
    private apiSecurityEvent: ApiSecurityEventService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.subscriptions = new Subscription();
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  assignData(respData: SecurityThreat): void {
    this.data = respData;
  }

  public discard(): void {
    this.router.navigate([EventCreationComponent.PARENT_PAGE_URL]).then();
    this.isEdit = false;
  }

  public save(): void {
    const data = this.form.getPayload();
    const payload = this.parseData(data);
    const filePayload = this.form.getFilePayload();
    const sub = this.apiSecurityEvent.saveSecurityEvent(payload, filePayload).subscribe({
      next: () => this.router.navigate([EventCreationComponent.PARENT_PAGE_URL]),
      error: (error) => {
        if (error.error.errors) {
          error.error.errors.forEach((message) => {
            this.toast.error(message, error.error.type || '', {
              closeButton: true,
              disableTimeOut: true
            });
          });
        } else {
          this.toast.error(error.error.name, 'Response status code: ' + error.status, {
            timeOut: this.timeOut
          });
        }
      }
    });
    this.subscriptions.add(sub);
  }

  setSaveDisabled = (value: boolean): void => {
    this.isSaveDisabled = value;
  };

  private parseData(data: SecurityThreat): SecurityEventDTO {
    return {
      summary: {
        title: data.summary.title,
        relevantForKfssb: data.summary.relevantForKfssb,
        eventReceivedDate: data.summary.eventReceivedDate,
        eventReceivedTime: data.summary.eventReceivedTime,
        eventStartDate: data.summary.threatStartDate,
        eventStartTime: data.summary.threatStartTime,
        eventEndDate: data.summary.threatEndDate,
        eventEndTime: data.summary.threatEndTime,
        description: data.summary.description
      },
      source: data.source,
      eventImpact: data.threatImpact,
      incidentEventLevel: data.incidentThreatLevel,
      details: data.details,
      poi: data.poi,
      location: data.location
    };
  }
}
