import { Component, EventEmitter, OnInit, Output, OnChanges, Input } from '@angular/core';
import { Impact } from '../../../models/security-threat';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'strm-thread-impact',
  templateUrl: './thread-impact.component.html',
  styleUrls: ['./thread-impact.component.scss']
})
export class ThreadImpactComponent implements OnInit, OnChanges {
  accidentIndex = 0;
  effectiveIndex = 0;
  accidentScore: string[] = ['Insignificant', 'Minor', 'Major', 'Catastrophic'];
  effectiveScore: string[] = ['Not effective', 'Minimal', 'Limited', 'Effective'];
  ercValue: string[] = ['Low', 'Medium', 'High', 'Very High'];
  ercMsg = '';
  steps: number[] = [1, 2, 3, 4];
  isVisible = false;
  checkCreateForm = true;

  effectiveLevel = 1;
  accidentLevel = 1;
  erc = 1;

  threatImpact: Impact = {
    accidentLevel: this.accidentLevel,
    effectiveLevel: this.effectiveLevel,
    erc: this.erc
  };

  @Output() emitImpact = new EventEmitter<Impact>();
  @Input() isEdit;
  @Input() set impactRetrieve(data: Impact) {
    if (data) {
      this.accidentIndex = data.accidentLevel - 1;
      this.accidentSlider(this.accidentIndex);
      this.effectiveIndex = data.effectiveLevel - 1;
      this.effectiveSlider(this.effectiveIndex);
    } else {
      this.ercLevel(this.accidentLevel, this.effectiveLevel);
    }
  }

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.checkCreateForm = id === 'create' ? true : false;
  }

  ngOnChanges(): void {
    if (!this.checkCreateForm) {
      this.isVisible = true;
      if (this.isEdit) {
        this.isVisible = false;
      }
    }
  }

  accidentSlider(data) {
    if (data.value) {
      this.accidentIndex = data.value;
      this.accidentLevel = this.steps[this.accidentIndex];
      if (this.accidentLevel == undefined) {
        this.accidentLevel = 1;
      }
      this.threatImpact.accidentLevel = this.accidentLevel;
      this.ercLevel(this.accidentLevel, this.effectiveLevel);
      this.emitImpact.emit(this.threatImpact);
    } else {
      this.accidentIndex = data;
      this.accidentLevel = this.steps[this.accidentIndex];
      if (this.accidentLevel == undefined) {
        this.accidentLevel = 1;
      }
      this.threatImpact.accidentLevel = this.accidentLevel;
      this.ercLevel(this.accidentLevel, this.effectiveLevel);
      this.emitImpact.emit(this.threatImpact);
    }
  }

  effectiveSlider(data) {
    if (data.value) {
      this.effectiveIndex = data.value;
      this.effectiveLevel = this.steps[this.effectiveIndex];
      if (this.effectiveLevel == undefined) {
        this.effectiveLevel = 1;
      }
      this.threatImpact.effectiveLevel = this.effectiveLevel;
      this.ercLevel(this.accidentLevel, this.effectiveLevel);
      this.emitImpact.emit(this.threatImpact);
    } else {
      this.effectiveIndex = data;
      this.effectiveLevel = this.steps[this.effectiveIndex];
      if (this.effectiveLevel == undefined) {
        this.effectiveLevel = 1;
      }
      this.threatImpact.effectiveLevel = this.effectiveLevel;
      this.ercLevel(this.accidentLevel, this.effectiveLevel);
      this.emitImpact.emit(this.threatImpact);
    }
  }

  ercLevel(accident, effective) {
    if (
      (accident === 1 && effective === 1) ||
      (accident === 1 && effective === 2) ||
      (accident === 1 && effective === 3) ||
      (accident === 1 && effective === 4) ||
      (accident === 2 && effective === 4) ||
      (accident === 2 && effective === 3) ||
      (accident === 3 && effective === 4)
    ) {
      this.ercMsg = this.ercValue[0];
      this.threatImpact.erc = 1;
      this.erc = 1;
    } else if (
      (accident === 2 && effective === 1) ||
      (accident === 2 && effective === 2) ||
      (accident === 3 && effective === 2) ||
      (accident === 3 && effective === 3) ||
      (accident === 4 && effective === 3) ||
      (accident === 4 && effective === 4)
    ) {
      this.ercMsg = this.ercValue[1];
      this.threatImpact.erc = 2;
      this.erc = 2;
    } else if ((accident === 3 && effective === 1) || (accident === 4 && effective === 2)) {
      this.ercMsg = this.ercValue[2];
      this.threatImpact.erc = 3;
      this.erc = 3;
    } else {
      this.ercMsg = this.ercValue[3];
      this.threatImpact.erc = 4;
      this.erc = 4;
    }
    this.emitImpact.emit(this.threatImpact);
  }
}
