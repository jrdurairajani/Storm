import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { map, Subscription, switchMap } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Country } from '../../models/common';
import { POI } from '../../models/map';
import { SecurityEvent } from '../../models/security-event';
import {
  AddSource,
  Details,
  Impact,
  MediaFile,
  SecurityThreat,
  SecurityThreatHeader,
  SecurityThreatLocation,
  SecurityThreatRecord,
  SecurityThreatSummary,
  SecurityThreatViewMode,
  ThreatIncidentLevel
} from '../../models/security-threat';
import { SecurityThreatOverview } from '../../models/security-threat-overview';
import { NextPrevSettings } from '../../models/utils';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  KfssbFilterValue
} from '../../services/filter.service';
import { OpenStreetMapService } from '../../services/osm.service';

const FILTER_CONSUMER_KEY = FilterConsumerKey.THREATS;

@Component({
  selector: 'strm-security-thread',
  templateUrl: './security-threat.component.html',
  styleUrls: ['./security-threat.component.scss']
})
export class SecurityThreatComponent implements OnInit, OnDestroy {
  // TODO: switch inputs/outputs to a subject in a service
  public threatHeaderInput: SecurityThreatHeader;
  public threatHeaderOutput: SecurityThreatHeader;
  public threatLocationInput: SecurityThreatLocation;
  public threatLocationOutput: SecurityThreatLocation;
  public attachedFiles: (MediaFile | File)[] = [];
  public threatSummaryInput: SecurityThreatSummary;
  public threatSummaryOutput: SecurityThreatSummary;
  public source: AddSource[] = [];
  public threatIncidentLevel: ThreatIncidentLevel;
  public threatDetailsInput: Details;
  public threatDetailsOutput: Details;
  public impactLevel: Impact;
  public isSaveDisabled = true;
  public isEditMode = false;
  public securityThreatRecord: SecurityThreatRecord;
  public mode: SecurityThreatViewMode;
  public poiInput: POI;
  public poiOutput: POI;
  public navProps: NextPrevSettings;
  public sourceMode: string;
  public threatId: string;

  private eventID: string;
  private totalSize: number;
  private prevBtnDisable: boolean;
  private nxtBtnDisable = false;
  private endElement: number;
  private isImageUploadError = false;
  private timeOut = 5000;
  private currentPage: number;
  private pageIndex: number;
  private subscriptions: Subscription = new Subscription();

  constructor(
    private toast: ToastrService,
    private apiSecurityThreat: ApiSecurityThreatService,
    private route: ActivatedRoute,
    private router: Router,
    private filterService: FilterService,
    private openStreetMapService: OpenStreetMapService
  ) {}

  public async ngOnInit(): Promise<void> {
    this.initPoi();
    await this.initSecurityThreat();
  }

  public ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  public getNavData(data: SecurityThreat | SecurityEvent): void {
    this.assignData(data as SecurityThreat);
  }

  // TODO: threats response data is previously known --> save the data in a service and
  //  load it, instead of calling the API unnecessarily
  public async loadThreat(id: string): Promise<void> {
    const sub = this.apiSecurityThreat
      .getSecurityThreat(id)
      .pipe(
        tap((securityThreat) => {
          if (this.currentPage == 1 && this.pageIndex == 0) {
            this.prevBtnDisable = true;
          }
          this.assignData(securityThreat);
        }),
        switchMap(() => this.filterService.filterObservable),
        map((filters) => filters.get(FILTER_CONSUMER_KEY)),
        switchMap((filters) =>
          this.apiSecurityThreat.getSecurityThreatOverview(
            this.currentPage,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.startDate,
            (filters?.get(FilterKey.DATE) as DateFilterValue)?.endDate,
            (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [],
            filters?.get(FilterKey.KFSSB) as KfssbFilterValue,
            'open'
          )
        )
      )
      .subscribe((securityThreats: SecurityThreatOverview) => {
        this.endElement = securityThreats.totalElements;
        this.totalSize = securityThreats.size;
        this.passDataNxtPre();
        if (
          this.endElement ==
          this.currentPage * this.totalSize - (this.totalSize - (this.pageIndex + 1))
        ) {
          this.nxtBtnDisable = true;
        }
      });
    this.subscriptions.add(sub);
  }

  public receiveLocation(location: SecurityThreatLocation): void {
    this.threatLocationOutput = location;
    this.poiInput = { ...this.openStreetMapService.handleLocationUpdate(location, this.poiInput) };
  }

  public receiveHeader(header: SecurityThreatHeader): void {
    if (header.state === 'NONE') {
      header.state = null;
    }
    this.threatHeaderOutput = header;
  }

  public receiveFiles(files: (MediaFile | File)[]): void {
    this.attachedFiles = files;
  }

  public isImageUploadValid(isValid: boolean): void {
    this.isImageUploadError = !isValid;
    this.isSaveDisabled = this.threatSummaryOutput.isError || this.isImageUploadError;
  }

  /**
   * on purpose I'm not creating new object. Don't want to trigger input
   * @param poi - The `POI` object containing the Points of Interest data, including markers,
   * polygons, and bounds, to be used for updating.
   */
  public receiveMap(poi: POI): void {
    this.poiInput.markers = poi.markers;
    this.poiInput.polygons = poi.polygons;
    this.poiInput.bounds = poi.bounds;
    this.poiOutput = poi;
  }

  public receiveSummary(summary: SecurityThreatSummary): void {
    this.threatSummaryOutput = summary;
    if (this.mode === 'create' || this.isEditMode) {
      this.isSaveDisabled = summary.isError || this.isImageUploadError;
    } else {
      this.isSaveDisabled = true;
    }
  }

  public receiveSource(source: AddSource[]): void {
    this.source = source;
  }

  public receiveDetails(details: Details): void {
    this.threatDetailsOutput = details;
  }

  public receiveThreadLevel(threatIncident: ThreatIncidentLevel): void {
    this.threatIncidentLevel = threatIncident;
  }

  public receiveImpact(impact: Impact): void {
    this.impactLevel = impact;
  }

  public switchToEditMode(): void {
    this.isEditMode = true;
    this.isSaveDisabled = false;
    this.mode = 'edit';
  }

  public remove(threatId: string): void {
    const subscription = this.apiSecurityThreat.archive(threatId).subscribe({
      next: () => {
        this.router.navigate(['dashboard/security-threats']);
        this.toast.success('Threat archived');
      },
      error: (error) =>
        this.toast.error(error.error.key, 'Response status code: ' + error.status, {
          timeOut: this.timeOut
        })
    });
    this.subscriptions.add(subscription);
  }

  public discard(): void {
    this.router.navigate(['dashboard/security-threats']).then();
    this.isEditMode = false;
  }

  public save(): void {
    const threatPayload = this.createThreatPayload();
    const filePayload = this.createFileUploadPayload(this.attachedFiles);
    const sub = this.apiSecurityThreat.saveSecurityThreat(threatPayload, filePayload).subscribe({
      next: (value: SecurityThreatRecord) => {
        const isConversion = !!this.eventID;
        console.log({ isConversion });
        let title: string;
        let message: string;
        if (isConversion) {
          this.router.navigate(['dashboard/security-events']);
          title = 'Event converted to threat';
          message = `<a href="#/dashboard/security-threats/${value.id}">Open threat</a>`;
        } else {
          this.router.navigate(['dashboard/security-threats']);
          title = 'Threat created';
        }
        this.toast.success(message, title, {
          enableHtml: true,
          timeOut: this.timeOut
        });
      },
      error: (error) =>
        this.toast.error(error.error.key, 'Response status code: ' + error.status, {
          timeOut: this.timeOut
        })
    });
    this.subscriptions.add(sub);
  }

  public edit(): void {
    const threatPayload = this.createThreatPayload();
    const filePayload = this.createFileUploadPayload(this.attachedFiles);
    const id = this.route.snapshot.paramMap.get('id');
    const sub = this.apiSecurityThreat
      .editSecurityThreat(id, threatPayload, filePayload)
      .subscribe({
        next: () => {
          this.router.navigate(['dashboard/security-threats']);
          this.toast.success(id, 'Threat modified', {
            timeOut: this.timeOut
          });
        },
        error: (error) =>
          this.toast.error(error.error.key, 'Response status code: ' + error.status, {
            timeOut: this.timeOut
          })
      });
    this.subscriptions.add(sub);
  }

  private initPoi(): void {
    if (!this.poiInput) {
      this.poiInput = {};
    }

    if (!this.poiInput?.markers) {
      this.poiInput.markers = [];
    }
    if (!this.poiInput?.polygons) {
      this.poiInput.polygons = [];
    }
    if (!this.poiInput?.bounds) {
      this.poiInput.bounds = [];
    }
  }

  private async initSecurityThreat(): Promise<void> {
    this.threatId = this.route.snapshot.paramMap.get('id');
    const securityThreat: SecurityThreat = history.state;
    const isConversion = securityThreat
      ? Object.prototype.hasOwnProperty.call(securityThreat, 'summary')
      : false;
    if (isConversion) {
      this.initConversion(securityThreat);
      return;
    }

    if (this.threatId !== 'create') {
      await this.initDetailsMode(this.threatId);
    } else {
      this.initCreationMode();
    }
  }

  private initCreationMode(): void {
    this.mode = 'create';
    this.sourceMode = 'noApiSource';
    this.isEditMode = true;
  }

  private async initDetailsMode(id: string): Promise<void> {
    this.mode = 'details';
    this.isEditMode = false;
    this.initNextPrevious();
    await this.loadThreat(id);
    console.log('initDetailsMode');
  }

  private initConversion(data: SecurityThreat): void {
    this.isEditMode = true;
    this.mode = 'create';
    this.sourceMode = 'apiSource';
    this.assignData(data);
    this.eventID = data.eventToThreatConversionID;
  }

  private initNextPrevious(): void {
    const qParams = this.route.snapshot.queryParamMap;
    const page = qParams.get('page');
    const index = qParams.get('index');
    this.currentPage = page ? parseInt(page, 10) : 1;
    this.pageIndex = parseInt(index, 10);
    this.passDataNxtPre();
  }

  // TODO: remove this function and fix this bad practice: use services to pass data between components
  private passDataNxtPre(): void {
    this.navProps = {
      pageIndex: this.pageIndex,
      pageCount: this.currentPage,
      prevBtnDisable: this.prevBtnDisable,
      endElement: this.endElement,
      totalSize: this.totalSize,
      nxtBtnDisable: this.nxtBtnDisable
    };
    console.log({ navProps: this.navProps });
  }

  private assignData(securityThreat: SecurityThreat): void {
    this.securityThreatRecord = securityThreat;
    this.threatSummaryInput = securityThreat.summary;
    this.source = securityThreat.source;
    this.impactLevel = securityThreat.threatImpact;
    this.threatIncidentLevel = securityThreat.incidentThreatLevel;
    this.threatDetailsInput = securityThreat.details;
    this.poiInput = securityThreat.poi;
    this.poiOutput = securityThreat.poi;
    this.attachedFiles = securityThreat.mediaFiles;
    this.eventID = securityThreat.eventToThreatConversionID;
    this.threatLocationInput = securityThreat.location;
    if (this.threatLocationInput) {
      this.threatLocationInput.marker = this.openStreetMapService.getMarker(securityThreat.poi);
      this.threatLocationInput.bounds = this.openStreetMapService.getBounds(securityThreat.poi);
    }
  }

  /**
   * MediaFiles are already uploaded, so we exclude them from being uploaded again.
   * @param files files
   */
  private createFileUploadPayload(files: (MediaFile | File)[]): File[] {
    return files.filter((f) => f instanceof File) as File[];
  }

  // TODO: remove this function and fix this bad practice: should be in model
  private createThreatPayload(): SecurityThreat {
    return {
      location: this.threatLocationOutput,
      summary: this.threatSummaryOutput,
      source: this.source,
      threatImpact: this.impactLevel,
      incidentThreatLevel: this.threatIncidentLevel,
      details: this.threatDetailsOutput,
      poi: this.poiOutput,
      mediaFiles: this.attachedFiles?.filter((f) => f instanceof MediaFile) as MediaFile[],
      eventToThreatConversionID: this.isEventToThreatConversion()
    };
  }

  private isEventToThreatConversion(): string {
    if (this.eventID) {
      return this.eventID;
    } else {
      return null;
    }
  }
}
