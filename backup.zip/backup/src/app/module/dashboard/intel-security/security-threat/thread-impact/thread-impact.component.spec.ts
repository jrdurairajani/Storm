import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreadImpactComponent } from './thread-impact.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ThreadImpactComponent', () => {
  let component: ThreadImpactComponent;
  let fixture: ComponentFixture<ThreadImpactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterModule.forRoot([])],
      declarations: [ThreadImpactComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ThreadImpactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('If accident = 1 and effective = 1 then erclevel should be low', () => {
    component.ercLevel(1, 1);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 1 and effective = 2 then erclevel should be low', () => {
    component.ercLevel(1, 2);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 1 and effective = 3 then erclevel should be low', () => {
    component.ercLevel(1, 3);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 1 and effective = 4 then erclevel should be low', () => {
    component.ercLevel(1, 4);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 2 and effective = 4 then erclevel should be low', () => {
    component.ercLevel(2, 4);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 2 and effective = 3 then erclevel should be low', () => {
    component.ercLevel(2, 3);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 3 and effective = 4 then erclevel should be low', () => {
    component.ercLevel(3, 4);
    expect(component.ercMsg).toBe('Low');
  });

  it('If accident = 2 and effective = 1 then erclevel should be Medium', () => {
    component.ercLevel(2, 1);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 2 and effective = 2 then erclevel should be Medium', () => {
    component.ercLevel(2, 2);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 3 and effective = 2 then erclevel should be Medium', () => {
    component.ercLevel(3, 2);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 3 and effective = 3 then erclevel should be Medium', () => {
    component.ercLevel(3, 3);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 4 and effective = 3 then erclevel should be Medium', () => {
    component.ercLevel(4, 3);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 4 and effective = 4 then erclevel should be Medium', () => {
    component.ercLevel(4, 4);
    expect(component.ercMsg).toBe('Medium');
  });

  it('If accident = 3 and effective = 1 then erclevel should be High', () => {
    component.ercLevel(3, 1);
    expect(component.ercMsg).toBe('High');
  });

  it('If accident = 4 and effective = 2 then erclevel should be High', () => {
    component.ercLevel(4, 2);
    expect(component.ercMsg).toBe('High');
  });

  it('If accident = 4 and effective = 1 then erclevel should be Very High', () => {
    component.ercLevel(4, 1);
    expect(component.ercMsg).toBe('Very High');
  });
});
