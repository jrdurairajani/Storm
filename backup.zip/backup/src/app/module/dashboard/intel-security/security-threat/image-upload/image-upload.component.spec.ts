import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageUploadComponent } from './image-upload.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ImageUpload', () => {
  let component: ImageUploadComponent;
  let fixture: ComponentFixture<ImageUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ImageUploadComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('checkFilesCount should set showExceedFilesCount = true if first param is > 3', () => {
  //   component.checkFilesCount(4, null)
  //   expect(component.showExceedFilesCount).toBe(true)
  // });

  // it('checkFilesCount should set showExceedFilesCount = false if first param is <= 3', () => {
  //   spyOn(component, 'upload').and.returnValue(null);
  //   component.checkFilesCount(3, null)
  //   expect(component.showExceedFilesCount).toBe(false)
  // });

  // it('countFiles should return 4 if this.multiples.length = 2 and files = 2', () => {
  //   const element: FileData = {name: 'name1'}
  //   const element2: FileData = {name: 'name2'}
  //   component.files = [element, element2]
  //   const length = component.countFiles(2)
  //   expect(length).toBe(4)
  // });

  // it('delete should remove element from this.multiples on given index', () => {
  //   const element: FileData = {name: 'name1'}
  //   const element2: FileData = {name: 'name2'}
  //   const element3: FileData = {name: 'name3'}
  //   component.files = [element, element2, element3]

  //   const result = [element, element3]

  //   component.delete(1)
  //   expect(component.files).toEqual(result)
  // });

  // it(`if(type === 'jpg' || type === 'jpeg' || type === 'png' || type === 'bmp' || type === 'gif' || type === 'heic') return true`, () => {
  //   const result = component.isImage('jpg')
  //   expect(result).toBe(true)

  //   const result1 = component.isImage('jpeg')
  //   expect(result1).toBe(true)

  //   const result2 = component.isImage('png')
  //   expect(result2).toBe(true)

  //   const result3 = component.isImage('bmp')
  //   expect(result3).toBe(true)

  //   const result4 = component.isImage('gif')
  //   expect(result4).toBe(true)

  //   const result5 = component.isImage('heic')
  //   expect(result5).toBe(true)
  // });

  // it(`if(type !== 'jpg' && type !== 'jpeg' & type !== 'png' & type !== 'bmp' & type !== 'gif' & type !== 'heic') return false`, () => {
  //   const result = component.isImage('exe')
  //   expect(result).toBe(false)
  // });

  // it('expect extractType will return jpg if as parametr got .jpg', () => {
  //   const result = component.extractType('.jpg')
  //   expect(result).toBe('jpg')
  // });

  it('expect reduceString to return same string like in parameter if string is <= 22', () => {
    const input = 'aaabbbccc';
    const result = component.reduceString(input);
    expect(result).toBe(input);
  });

  it('expect reduceString to return aaabbbcccdddeeefffggg... if aaabbbcccdddeeefffggghhh is a parameter', () => {
    const input = 'aaabbbcccdddeeefffggghhh';
    const result = component.reduceString(input);
    const expected = 'aaabbbcccdddeeefffggg...';
    expect(result).toBe(expected);
  });
});
