import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatIncidentComponent } from './threat-incident.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ThreatIncidentComponent', () => {
  let component: ThreatIncidentComponent;
  let fixture: ComponentFixture<ThreatIncidentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, MatCheckboxModule, MatRadioModule, RouterModule.forRoot([])],
      declarations: [ThreatIncidentComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ThreatIncidentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
