import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MediaFile } from '../../../models/security-threat';

@Component({
  selector: 'strm-image-upload',
  templateUrl: './image-upload.component.html',
  styleUrls: ['./image-upload.component.scss']
})
export class ImageUploadComponent {
  files: (MediaFile | File)[] = [];
  showExceedFilesCount = false;
  invalidFileTypeError = false;
  showMaxFileSizeExceededError = false;
  maxTotalAttachmentSizeInMb = 70;
  maxUploadFilesAllowed = 3;
  allowedTypes = [
    '.jpeg',
    '.jpg',
    'gif',
    '.svg',
    '.png',
    '.tif',
    '.tiff',
    '.pdf',
    '.doc',
    '.docx',
    '.xls',
    '.xlsx',
    '.txt',
    '.mp4',
    '.mov',
    '.ppt',
    '.pptx',
    '.odp',
    '.mp3',
    '.m4a',
    '.wav'
  ];

  @Output() emitFiles = new EventEmitter<(MediaFile | File)[]>();
  @Output() emitCanSave = new EventEmitter<boolean>();
  @Input() isEdit: boolean;

  @Input() set setFiles(data: (MediaFile | File)[]) {
    if (data !== undefined && data?.length >= 0) {
      this.files = data;
    }
  }

  get allowedFileTypes(): string {
    return this.allowedTypes.join(', ');
  }

  onSelectFile(event): void {
    const newFiles: File[] = Array.from(event.target.files);
    this.files = [...this.files, ...newFiles];

    this.isMaxAllowedFilesExceeded(this.files);
    this.isUnderMaxAllowedFileLimit(this.files);

    this.emitCanSave.emit(this.canSave());
    this.emitFiles.emit(this.files);
  }

  canSave(): boolean {
    return !(this.showExceedFilesCount || this.showMaxFileSizeExceededError);
  }

  isMaxAllowedFilesExceeded(files: (MediaFile | File)[]): void {
    this.showExceedFilesCount = files.length > this.maxUploadFilesAllowed;
  }

  isUnderMaxAllowedFileLimit(files: (MediaFile | File)[]): void {
    let totalSize = 0;
    files.forEach((item) => {
      totalSize += item.size;
    });
    const totalSizeInMB = totalSize / (1024 * 1024);
    this.showMaxFileSizeExceededError = totalSizeInMB >= this.maxTotalAttachmentSizeInMb;
  }

  delete(fileToDelete: File | MediaFile): void {
    this.files = this.files.filter((f) => f !== fileToDelete);

    this.isMaxAllowedFilesExceeded(this.files);
    this.isUnderMaxAllowedFileLimit(this.files);

    this.emitCanSave.emit(this.canSave());
    this.emitFiles.emit(this.files);
  }

  reduceString(name: string): string {
    const till = 22;
    if (name.length > till) {
      const cut = name.slice(0, till - 1);
      const result = `${cut}...`;
      return result;
    } else {
      return name;
    }
  }

  validFiles(files: FileList): boolean {
    return Array.from(files).every((file) => {
      const extension = file.name.slice(((file.name.lastIndexOf('.') - 1) >>> 0) + 2);
      return this.allowedFileTypes.includes(`.${extension}`);
    });
  }

  onDrop(files: FileList): void {
    if (files.length > 0 && this.validFiles(files)) {
      this.onSelectFile({ target: { files } });
    }
  }

  getIconForFile(file: MediaFile | File): string {
    const extension = file.name.split('.').pop();

    switch (extension.toLowerCase()) {
      case 'peg':
      case 'jpg':
      case 'gif':
      case 'svg':
      case 'png':
      case 'tif':
      case 'tiff':
        return 'photo';
      case 'pdf':
        return 'picture_as_pdf';
      case 'doc':
      case 'docx':
        return 'description';
      case 'xls':
      case 'xlsx':
        return 'table_view';
      case 'txt':
        return 'notes';
      case 'mp4':
      case 'mov':
        return 'movie';
      case 'ppt':
      case 'pptx':
      case 'odp':
        return 'slideshow';
      case 'mp3':
      case '4a':
      case 'wav':
        return 'music_note';
      default:
        return 'file_present';
    }
  }

  getDownloadUrl(file: MediaFile | File): string {
    if (file instanceof MediaFile) {
      return `/api/securitythreats/mediafiles/${file.id}`;
    } else {
      return '';
    }
  }
}
