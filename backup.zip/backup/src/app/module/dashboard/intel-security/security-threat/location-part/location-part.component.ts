import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AirportDetails } from '../../../models/airport-details';
import { CityCountries } from '../../../models/involved-countries';
import { OpenStreetMapSearchResult } from '../../../models/open-street-map';
import { SecurityThreatLocation, SecurityThreatViewMode } from '../../../models/security-threat';
@Component({
  selector: 'strm-location-part',
  templateUrl: './location-part.component.html',
  styleUrls: ['./location-part.component.scss']
})
export class LocationPartComponent {
  public osmInput: OpenStreetMapSearchResult;
  public countriesDetails: CityCountries[] | string[];
  public airportDetails: AirportDetails;
  @Input() public mode: SecurityThreatViewMode;
  @Input() public locationDetails: SecurityThreatLocation = {
    osmId: null,
    osmType: null,
    primaryLocation: null,
    airportCode: null,
    involvedCountries: null,
    country: null,
    marker: null,
    bounds: null
  };
  @Input() set setLocationDetails(address: SecurityThreatLocation) {
    if (!address) return;
    this.osmInput = {
      osm_id: address.osmId,
      osm_type: address.osmType,
      display_name: address.primaryLocation,
      address: {
        country: address.country
      },
      marker: address.marker,
      bounds: address.bounds
    };
    this.countriesDetails = address.involvedCountries;
    this.airportDetails = address.airportDetails;
  }
  @Output() public emitThreatLocation = new EventEmitter<SecurityThreatLocation>();

  public pickAddress(primaryLocation: OpenStreetMapSearchResult) {
    if (primaryLocation !== null) {
      this.locationDetails.osmId = primaryLocation.osm_id;
      this.locationDetails.osmType = primaryLocation.osm_type;
      this.locationDetails.primaryLocation = primaryLocation.display_name;
      this.locationDetails.country = primaryLocation.address.country;
      this.locationDetails.marker = primaryLocation.marker;
      this.locationDetails.bounds = primaryLocation.bounds;
      this.locationDetailsEmitter();
    } else {
      this.locationDetails.osmId = null;
      this.locationDetails.osmType = null;
      this.locationDetails.primaryLocation = null;
      this.locationDetails.country = null;
      this.locationDetails.marker = null;
      this.locationDetails.bounds = null;
      this.locationDetailsEmitter();
    }
  }

  public receiveIataCode(airport: string): void {
    this.locationDetails.airportCode = airport;
    this.locationDetailsEmitter();
  }

  public receiveInvolvedCountries(countries: CityCountries[] | string[]): void {
    if (countries !== null && countries.length > 0) {
      this.locationDetails.involvedCountries = countries.map((countries) => countries.code);
      this.locationDetailsEmitter();
    } else {
      this.locationDetails.involvedCountries = null;
      this.locationDetailsEmitter();
    }
  }

  private locationDetailsEmitter(): void {
    this.emitThreatLocation.emit(this.locationDetails);
  }
}
