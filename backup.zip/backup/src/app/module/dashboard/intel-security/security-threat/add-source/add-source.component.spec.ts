import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddSourceComponent } from './add-source.component';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('AddSourceComponent', () => {
  let component: AddSourceComponent;
  let fixture: ComponentFixture<AddSourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
        HttpClientModule,
        RouterModule.forRoot([])
      ],
      declarations: [AddSourceComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(AddSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create a form using formbuilder', () => {
    expect(component.form instanceof FormGroup).toBeTruthy();
  });

  it('Onload empty row with source and provider need to be added', () => {
    component.createFieldRow();
    expect(component.sources.length).toBe(1);
  });

  // it('Source field should be required/mandatory', () => {
  //     component.createFieldRow();
  //     component.addContactField();
  //     const name = component.sources.controls[0].get('name');
  //     expect(name.invalid).toBeFalsy();

  //     name.setValue('');
  //     expect(name.hasError('required')).toBeTruthy();
  // });

  // it('Source invalid when empty', () => {
  //   component.createFieldRow();
  //   component.addContactField();
  //   component.sources.controls[0].get('name').setValue('');
  //   expect(component.sources.valid).toBeFalsy();
  // });

  // it('Reference valid when empty', () => {
  //   component.createFieldRow();
  //   component.addContactField();
  //   component.sources.controls[0].get('link').setValue('');
  //   expect(component.sources.valid).toBeTruthy();
  // });

  it('Should check if the referene link is valid with start text should be http', () => {
    component.createFieldRow();
    const url = 'http://www.google.com';
    const validURL = component.isValidUrl(url);
    expect(validURL).toBeTruthy();
  });
});
