import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationPartComponent } from './location-part.component';

describe('LocationPartComponent', () => {
  let component: LocationPartComponent;
  let fixture: ComponentFixture<LocationPartComponent>;
  const addressMock = {
    address: { country: 'India', country_code: 'in' },
    boundingbox: ['6.5531169', '35.6745457', '67.9544415', '97.3955610'],
    class: 'boundary',
    importance: 0.847689135880987,
    lat: '22.3511148',
    licence: 'Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright',
    lon: '78.6677428',
    name: 'India',
    osm_id: 304716,
    osm_type: 'relation',
    place_id: 246685686,
    place_rank: 4,
    type: 'administrative',
    display_name: 'India',
    addresstype: 'country'
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LocationPartComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(LocationPartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should assign osm id', () => {
    component.pickAddress(addressMock);
    const osmID = component.locationDetails.osmId;
    expect(osmID).toEqual(304716);
  });

  it('should assign primary location', () => {
    component.pickAddress(addressMock);
    const primaryLocation = component.locationDetails.primaryLocation;
    expect(primaryLocation).toEqual('India');
  });

  it('should assign osm type', () => {
    component.pickAddress(addressMock);
    const osmType = component.locationDetails.osmType;
    expect(osmType).toEqual('relation');
  });

  it('should assign airport code', () => {
    const airport = 'GYA';
    component.receiveIataCode(airport);
    const airportCode = component.locationDetails.airportCode;
    expect(airportCode).toEqual(airport);
  });

  it('should assign involved countries', () => {
    const involvedCountries = [
      {
        name: 'Angola',
        code: 'AO'
      },
      {
        name: 'Andorra',
        code: 'AD'
      },
      {
        name: 'Algeria',
        code: 'DZ'
      }
    ];
    const result = ['AO', 'AD', 'DZ'];
    component.receiveInvolvedCountries(involvedCountries);
    const countries = component.locationDetails.involvedCountries;
    expect(countries).toEqual(result);
  });
});
