import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';

import { SecurityThreatComponent } from './security-threat.component';
import { ToastrModule } from 'ngx-toastr';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SecurityThreatLocation } from '../../models/security-threat';
import { OpenStreetMapService } from '../../services/osm.service';

describe('SecurityThreadComponent', () => {
  let component: SecurityThreatComponent;
  let fixture: ComponentFixture<SecurityThreatComponent>;
  let openStreetMapService: OpenStreetMapService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { paramMap: convertToParamMap({ id: 'create' }) } }
        },
        OpenStreetMapService
      ],
      imports: [HttpClientTestingModule, ToastrModule.forRoot()],
      declarations: [SecurityThreatComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityThreatComponent);
    component = fixture.componentInstance;
    openStreetMapService = TestBed.inject(OpenStreetMapService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call handleLocationUpdate method from OpenStreetMapService when receiveLocation is called', () => {
    const testLocation: SecurityThreatLocation = {
      osmId: 123456,
      osmType: 'node',
      primaryLocation: 'Test Location',
      airportCode: 'TST',
      involvedCountries: ['Testland'],
      country: 'Testland',
      bounds: null,
      marker: {
        coordinates: { lat: 10, lng: 20 },
        type: 'primary'
      }
    };
    const handleLocationUpdateSpy = spyOn(openStreetMapService, 'handleLocationUpdate');

    component.receiveLocation(testLocation);

    expect(handleLocationUpdateSpy).toHaveBeenCalled();
  });
});
