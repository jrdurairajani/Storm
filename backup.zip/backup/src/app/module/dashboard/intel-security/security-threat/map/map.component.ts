import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  ViewChild
} from '@angular/core';
import * as L from 'leaflet';
import { Layer } from 'leaflet';
import 'leaflet-draw';
import 'leaflet.markercluster';
import { Bound, Coordinate, Marker, POI, Polygon } from '../../../models/map';

@Component({
  selector: 'strm-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnDestroy, AfterViewInit {
  ngAfterViewInit(): void {
    this.initMap();
    this.displayMapElements();
  }
  @Input() public set setPoi(poi: POI) {
    if (!poi) return;
    this.poi = poi;
    this.reloadMap();
    this.emitMap.emit(poi);
  }
  @Input() public set setMode(mode: string) {
    this.mode = mode;
    this.reloadMap();
  }
  @Output() public emitMap = new EventEmitter<POI>();

  private iconDefault = L.icon({
    iconRetinaUrl: 'assets/marker-icon-2x.png',
    iconUrl: 'assets/marker-icon.png',
    shadowUrl: 'assets/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
  });

  private mode: string;
  private poi: POI;
  public isPlaceholder = false;
  private isEventListenerStarted = false;

  private map: L.Map;
  private markers: L.FeatureGroup = L.markerClusterGroup();
  private drawnItems: L.FeatureGroup;
  @ViewChild('mapElement', { static: false }) public mapElement: ElementRef;

  private reloadMap(): void {
    const firstMarker = this.poi?.markers[0]?.coordinates;
    if (this.mode === 'details') {
      this.isPlaceholder = this.usePlaceholder(firstMarker?.lat, firstMarker?.lng);
    }
    if (this.drawnItems && this.map) {
      this.drawnItems.clearLayers();
      this.displayMapElements();
    }
  }

  public ngOnDestroy(): void {
    this.mapElement.nativeElement.remove();
    if (this.map) {
      this.map.off();
      this.map.remove();
      this.map = null;
    }
  }

  private displayMapElements(): void {
    this.initDrawControl();
    this.displayMarkers(this.poi?.markers);
    this.displayPolygons(this.poi?.polygons);
    this.displayBounds(this.poi?.bounds);
  }

  private initDrawControl(): void {
    const drawControl = new L.Control.Draw({
      draw: {
        polygon: {
          allowIntersection: false,
          shapeOptions: {
            color: 'blue'
          }
        },
        polyline: false,
        rectangle: false,
        circle: false,
        marker: {
          icon: L.icon({
            iconUrl: 'assets/marker-icon.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34]
          })
        }
      },
      edit: {
        featureGroup: this.drawnItems
      }
    });

    if (this.mode !== 'details') {
      this.map.addControl(drawControl);
    }

    if (!this.isEventListenerStarted) {
      this.isEventListenerStarted = true;

      this.map.on(L.Draw.Event.CREATED, (event: any) => {
        const layer = event.layer;
        this.drawnItems.addLayer(layer);

        const poi: POI = this.exportLayers(this.drawnItems.getLayers());
        this.emitMap.emit(poi);
      });

      this.map.on(L.Draw.Event.EDITED, (event: any) => {
        const poi: POI = this.exportLayers(this.drawnItems.getLayers());
        this.emitMap.emit(poi);
      });

      this.map.on(L.Draw.Event.DELETED, (event: any) => {
        const poi: POI = this.exportLayers(this.drawnItems.getLayers());
        this.emitMap.emit(poi);
      });
    }
  }

  private exportLayers(layers: Layer[]): POI {
    const markers: Marker[] = [];
    const polygons: Polygon[] = [];
    const bounds: Bound[] = [];

    layers.forEach((layer) => {
      if (layer instanceof L.Marker) {
        const type = (layer as any).type || 'regular';
        markers.push({
          coordinates: { lat: layer.getLatLng().lat, lng: layer.getLatLng().lng },
          type: type
        });
      } else if (layer instanceof L.Polygon) {
        polygons.push({ coordinates: this.extractLayerCoordinates(layer), type: 'regular' });
      } else if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
        bounds.push({ coordinates: this.extractLayerCoordinates(layer), type: 'primary' });
      }
    });

    return { markers, polygons, bounds };
  }

  /**
   * Extracts and transforms the coordinates from a given Leaflet polygon layer into a structured format.
   * This function handles both simple polygons (single array of `L.LatLng` objects) and complex polygons
   * (array of arrays of `L.LatLng` objects, typically used for polygons with holes) by checking the structure
   * of the `latLngs` array. It then maps the latitude and longitude values of each point to a more structured
   * `Coordinate` type defined as `{ lat: number, lng: number }`.
   *
   * @param layer - The `L.Polygon` instance from which to extract the coordinates. This polygon can represent
   *                either a simple shape or a complex one with multiple rings.
   * @returns An array of `Coordinate` arrays, where each `Coordinate` is an object with `lat` and `lng` properties.
   *          For simple polygons, this will be an array containing a single `Coordinate` array. For complex polygons,
   *          it may contain multiple `Coordinate` arrays, one for each ring of the polygon.
   */
  private extractLayerCoordinates(layer: L.Polygon): Coordinate[][] {
    const latLngs = layer.getLatLngs();
    if (Array.isArray(latLngs[0])) {
      return [
        (latLngs[0] as L.LatLng[]).map((latLng) => ({
          lat: latLng.lat,
          lng: latLng.lng
        }))
      ];
    } else {
      return [
        [
          ...(latLngs as L.LatLng[]).map((latLng) => ({
            lat: latLng.lat,
            lng: latLng.lng
          }))
        ]
      ];
    }
  }

  private displayMarkers(markers: Marker[]): void {
    if (markers?.length > 0) {
      markers.forEach((marker, i) => {
        const isSetView = this.setView(i, markers.length - 1);
        this.addMarker(marker, isSetView);
      });
    }
  }

  private displayBounds(bounds: Bound[]): void {
    bounds?.forEach((bound) => {
      const polyline = L.polyline(this.convertCoordinates(bound.coordinates), {
        color: 'blue',
        weight: 4,
        opacity: 0.7,
        smoothFactor: 1
      });
      this.drawnItems.addLayer(polyline);
      this.map.setView([bounds[0].coordinates[0][0].lat, bounds[0].coordinates[0][0].lng], 8);
    });
  }

  private convertCoordinates(coordinates: Coordinate[][]): L.LatLngExpression[] {
    return coordinates.flat().map((coord) => [coord.lat, coord.lng] as L.LatLngExpression);
  }

  private displayPolygons(polygons: Polygon[]): void {
    if (polygons?.length > 0) {
      polygons.forEach((polygon: Polygon) => {
        const polygonObject = L.polygon(polygon.coordinates);
        this.drawnItems.addLayer(polygonObject);
      });
    }
  }

  private initMap(longitude = 52, latitude = 9): void {
    L.Marker.prototype.options.icon = this.iconDefault;
    this.map = L.map('map', {
      center: [longitude, latitude],
      zoom: 3
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });

    tiles.addTo(this.map);
    this.drawnItems = L.featureGroup().addTo(this.map);
  }

  private addMarker(marker: Marker, isSetView: boolean): void {
    const leafletMarker = L.marker([marker.coordinates.lat, marker.coordinates.lng], {
      icon: this.iconDefault
    });

    (leafletMarker as any).type = marker.type;
    this.drawnItems.addLayer(leafletMarker);

    if (isSetView) {
      this.map.setView([marker.coordinates.lat, marker.coordinates.lng], 8);
    }
  }

  private usePlaceholder(latitude: number, longitude: number): boolean {
    if (latitude === 0 && longitude === 0) {
      return true;
    } else {
      return false;
    }
  }

  private setView(iterator: number, listLength: number): boolean {
    if (iterator === listLength) {
      return true;
    } else {
      return false;
    }
  }
}
