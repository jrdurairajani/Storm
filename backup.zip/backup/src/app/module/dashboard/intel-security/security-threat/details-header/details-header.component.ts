import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiSecurityThreatService } from '../../../services/api-security-threat.service';
import {
  City,
  Continent,
  Country,
  DataEmitted,
  ElementWithCodeAndName,
  SecurityRegion,
  SecurityThreatHeader,
  SecurityThreatViewMode,
  State,
  Station
} from '../../../models/security-threat';

@Component({
  selector: 'strm-details-header',
  templateUrl: './details-header.component.html',
  styleUrls: ['./details-header.component.scss']
})
export class DetailsHeaderComponent implements OnInit {
  formHeader: FormGroup;
  continentData: Continent[] = [];
  countryData: Country[] = [];
  stateData: State[] = [];
  cityData: City[] = [];
  stationData: Station[] = [];
  securityRegionData: SecurityRegion[] = [];
  cityInitial: string;
  stateInitial: string;
  mode: SecurityThreatViewMode;
  disableStateCity = true;
  disableLocation = true;

  @Output() emitThreatHeader = new EventEmitter<SecurityThreatHeader>();

  constructor(
    private fb: FormBuilder,
    private api: ApiSecurityThreatService,
    private elementRef: ElementRef
  ) {
    this.formHeader = fb.group({
      region: null,
      provider: 'Not Available',
      continent: null,
      country: null,
      state: null,
      city: null,
      location: null,
      station: null,
      freeTextCity: null,
      freeTextState: null
    });
  }

  @Input() set setMode(mode: SecurityThreatViewMode) {
    this.mode = mode;
    this.switchOnOffForm(mode);
  }

  // TODO: add proper types
  @Input() set setHeaderRetrieve(headerRetrieve: any) {
    if (headerRetrieve?.continent) {
      this.loadData(headerRetrieve);
    }
  }

  async ngOnInit(): Promise<void> {
    this.continentData = await this.api.getSecurityThreatContinent();
    this.securityRegionData = await this.api.getSecurityRegion();
    this.emitThreatHeader.emit(this.formHeader.value);

    this.formHeader.valueChanges.subscribe(() => {
      if (this.mode === 'create' || this.mode === 'edit') {
        this.emitThreatHeader.emit(this.formHeader.value);
      }
    });
  }

  switchOnOffForm(mode: string): void {
    if (mode === 'details') {
      this.formHeader.disable();
      this.elementRef.nativeElement.querySelectorAll('.mat-select-arrow').forEach((x) => {
        x.classList.add('border-0');
      });
    } else {
      this.formHeader.enable();
      this.elementRef.nativeElement.querySelectorAll('.mat-select-arrow').forEach((x) => {
        x.classList.remove('border-0');
      });
    }
  }

  async loadData(headerRetrieve): Promise<void> {
    this.formHeader.controls.continent.setValue(headerRetrieve.continent);
    await this.continentSelect(headerRetrieve.continent);

    this.formHeader.controls.country.setValue(headerRetrieve.countryCode);
    await this.countrySelect(headerRetrieve.countryCode);

    this.stateInitial = this.getState(headerRetrieve.state, headerRetrieve.freeTextState); // select state as regular or custom
    const stateExists: boolean = this.existsInList(this.stateInitial, this.stateData);
    if (stateExists) {
      // state is valid, it's not custom or null
      this.formHeader.controls.state.setValue(this.stateInitial);
      await this.stateSelect(this.stateInitial);
    } else {
      // state is custom or null
      this.formHeader.controls.freeTextState.setValue(this.stateInitial);
      const country: string = this.formHeader.controls.country.value;
      const continent: string = this.formHeader.controls.continent.value;
      this.cityData = await this.getCityList(continent, country, 'NONE'); // NONE means get cities based on country
    }

    this.cityInitial = headerRetrieve.city ? headerRetrieve.city : headerRetrieve.freeTextCity;
    const cityExists = this.existsInList(this.cityInitial, this.cityData);
    if (cityExists) {
      // city is valid, it's not custom or null
      this.formHeader.controls.city.setValue(this.cityInitial);
      await this.citySelect(this.cityInitial);
    } else {
      // city is custom or null
      this.formHeader.controls.freeTextCity.setValue(this.cityInitial);
    }

    this.formHeader.controls.station.setValue(headerRetrieve.station);
    this.formHeader.controls.region.setValue(headerRetrieve.region);
    this.formHeader.controls.location.setValue(headerRetrieve.location);
  }

  existsInList(code: string, list: ElementWithCodeAndName[]): boolean {
    if (!code || list.length === 0) {
      return false;
    }
    const result = list.find((el) => el.code.toLocaleLowerCase() === code.toLocaleLowerCase());
    return !!result;
  }

  async continentSelect(continent: string): Promise<void> {
    if (!continent) {
      return;
    }
    this.resetNestedSelection(false, true, true, true, true);
    this.countryData = await this.getCountryList(continent);
    this.disableStateCity = true;
    this.disableLocation = true;
  }

  async countrySelect(countryCode: string): Promise<void> {
    if (!countryCode) {
      return;
    }
    const continent: string = this.formHeader.controls.continent.value;
    this.resetNestedSelection(false, false, true, true, true);
    this.stateData = await this.getStateList(continent, countryCode); // once country selected get state list

    this.formHeader.controls.state.setValue('NONE');
    this.cityData = await this.getCityList(continent, countryCode, 'NONE'); // once country selected get city list based on country
    this.disableStateCity = false;
    this.disableLocation = true;
  }

  async stateSelect(stateCode: string, reset = true): Promise<void> {
    if (!stateCode) {
      return;
    }
    const continent: string = this.formHeader.controls.continent.value;
    const country: string = this.formHeader.controls.country.value;
    if (reset) {
      this.resetNestedSelection(false, false, false, true, true);
    }
    if (stateCode !== 'new_code') {
      // if it's valid state, not custom
      this.cityData = await this.getCityList(continent, country, stateCode);
    } else {
      // if it's custom state
      this.cityData = await this.getCityList(continent, country, 'NONE'); // get city based on country
    }
    this.disableLocation = true;
  }

  async citySelect(cityCode: string): Promise<void> {
    if (!cityCode) {
      return;
    }
    const continent: string = this.formHeader.controls.continent.value;
    const country: string = this.formHeader.controls.country.value;
    let state: string = this.formHeader.controls.state.value;

    const stateExists: boolean = this.existsInList(this.stateInitial, this.stateData);
    if (!state || !stateExists) {
      state = 'NONE';
    }
    this.resetNestedSelection(false, false, false, false, true);
    if (cityCode !== 'new_code') {
      // if city is valid, not custom
      this.stationData = await this.getStationList(continent, country, state, cityCode); // get station list based on city

      if (this.stateData.length > 0 && !this.stateInitial) {
        // if state list exists and state was not picked
        this.stateInitial = this.getStateBasedOnCity(cityCode, this.cityData); // get state based on city
        this.formHeader.controls.state.setValue(this.stateInitial);
        this.stateSelect(this.stateInitial, false); // init state selection and generate new city list
      }
    }
    this.disableLocation = false;
  }

  getStateBasedOnCity(cityCode: string, cityList: City[]): string {
    const cityElement = cityList.find(
      (city) => city?.code?.toLocaleLowerCase() == cityCode?.toLocaleLowerCase()
    );
    return cityElement?.state.code;
  }

  receiveState(data: DataEmitted): void {
    const state: ElementWithCodeAndName = data.emitValue;
    this.stateInitial = data.displayValue;
    if (state.code === 'new_code') {
      this.formHeader.controls.freeTextState.setValue(state.name);
      this.formHeader.controls.state.setValue(null);
    } else if (state.name === '') {
      this.formHeader.controls.state.setValue(null);
      this.formHeader.controls.freeTextState.setValue(null);
    } else {
      this.formHeader.controls.state.setValue(state.code);
    }
    this.stateSelect(state.code);
  }

  receiveCity(data): void {
    const city: ElementWithCodeAndName = data.emitValue;
    this.cityInitial = data.displayValue;
    if (city.code === 'new_code') {
      this.formHeader.controls.freeTextCity.setValue(city.name);
      this.formHeader.controls.city.setValue(null);
    } else if (city.name === '') {
      this.formHeader.controls.city.setValue(null);
      this.formHeader.controls.freeTextCity.setValue(null);
    } else {
      this.formHeader.controls.city.setValue(city.code);
    }
    this.citySelect(city.code);
  }

  getState(state: string, freeTextState: string): string {
    if (state) {
      return state;
    } else if (freeTextState) {
      return freeTextState;
    } else {
      return 'NONE';
    }
  }

  resetNestedSelection(
    continent: boolean,
    country: boolean,
    state: boolean,
    city: boolean,
    station: boolean
  ): void {
    if (continent) {
      this.formHeader.controls.continent.setValue(null);
      this.continentData = [];
    }
    if (country) {
      this.formHeader.controls.country.setValue(null);
      this.countryData = [];
    }
    if (state) {
      this.formHeader.controls.state.setValue(null);
      this.stateData = [];
      this.stateInitial = '';
    }
    if (city) {
      this.formHeader.controls.city.setValue(null);
      this.cityData = [];
      this.cityInitial = '';
    }
    if (station) {
      this.formHeader.controls.station.setValue(null);
      this.stationData = [];
    }
    this.formHeader.updateValueAndValidity();
  }

  getCountryList(continent: string): Promise<Country[]> {
    return this.api.getSecurityThreatLocations(continent, '', '', '');
  }

  getStateList(continent: string, country: string): Promise<State[]> {
    return this.api.getSecurityThreatLocations(continent, country, '', '');
  }

  getCityList(continent: string, country: string, state: string): Promise<City[]> {
    return this.api.getSecurityThreatLocations(continent, country, state, '');
  }

  getStationList(
    continent: string,
    country: string,
    state: string,
    city: string
  ): Promise<Station[]> {
    return this.api.getSecurityThreatLocations(continent, country, state, city);
  }
}
