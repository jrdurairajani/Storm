import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SecurityThreatSummary } from '../../../models/security-threat';

import { SummaryComponent } from './summary.component';
import { FormControl } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('SummaryComponent', () => {
  let component: SummaryComponent;
  let fixture: ComponentFixture<SummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterModule.forRoot([])],
      declarations: [SummaryComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should throw value false if the event date & time and threat end date & time are equal', () => {
    const data: SecurityThreatSummary = {
      description: 'test',
      title: 'test',
      eventReceivedDate: '2023-04-07',
      eventReceivedTime: '',
      threatStartDate: '2023-04-07',
      threatStartTime: '',
      threatEndDate: '2023-04-07',
      threatEndTime: '',
      relevantForKfssb: true
    };
    const result = component.threatEndSameOrLaterStartDateValidation(data);
    expect(result).toBeFalsy();
  });

  it('Should throw value true if the event date & time and threat end date & time are not equal', () => {
    const data: SecurityThreatSummary = {
      description: 'test',
      title: 'test',
      eventReceivedDate: '2023-04-07',
      eventReceivedTime: '',
      threatStartDate: '2023-04-07',
      threatStartTime: '',
      threatEndDate: '2023-04-6',
      threatEndTime: '',
      relevantForKfssb: true
    };
    const result = component.threatEndSameOrLaterStartDateValidation(data);
    expect(result).toBeTruthy();
  });

  it('should return value true if 2 dates are equal', () => {
    const data: SecurityThreatSummary = {
      description: 'test',
      title: 'test',
      eventReceivedDate: '2023-04-07',
      eventReceivedTime: '',
      threatStartDate: '2023-04-07',
      threatStartTime: '',
      threatEndDate: '2023-04-06',
      threatEndTime: '',
      relevantForKfssb: true
    };
    const result1 = component.isSameDateValidation(data.eventReceivedDate, data.threatStartDate);
    expect(result1).toBeTruthy();
  });

  it('should return value false if 2 dates are not equal', () => {
    const data: SecurityThreatSummary = {
      description: 'test',
      title: 'test',
      eventReceivedDate: '2023-04-07',
      eventReceivedTime: '',
      threatStartDate: '2023-04-06',
      threatStartTime: '',
      threatEndDate: '2023-04-6',
      threatEndTime: '',
      relevantForKfssb: true
    };
    const result1 = component.isSameDateValidation(data.eventReceivedDate, data.threatStartDate);
    expect(result1).toBeFalsy();
  });

  it('should return value false if 2 dates and times are not equal', () => {
    const data: SecurityThreatSummary = {
      description: 'test',
      title: 'test',
      eventReceivedDate: '2023-04-07',
      eventReceivedTime: '14:45',
      threatStartDate: '2023-04-06',
      threatStartTime: '',
      threatEndDate: '2023-04-6',
      threatEndTime: '',
      relevantForKfssb: true
    };
    const result1 = component.isBeforeDateValidation(
      data.eventReceivedDate + data.eventReceivedTime,
      data.threatStartDate + data.threatStartTime
    );
    expect(result1).toBeFalsy();
  });

  it('should set value of control to time when minutes are 00', () => {
    const control = new FormControl('');
    const time = '10:00';

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual(time);
  });

  it('should set value of control to time when hour is 12', () => {
    const control = new FormControl('');
    const time = '12:30';

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual(time);
  });

  it('should not modify control when hour is not 12 and minutes are not 00', () => {
    const control = new FormControl('');
    const time = '11:30';

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual('');
  });

  it('should not modify control when time is null', () => {
    const control = new FormControl('');
    const time = null;

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual('');
  });

  it('should not modify control when time is undefined', () => {
    const control = new FormControl('');
    const time = undefined;

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual('');
  });

  it('should not modify control when time is an empty string', () => {
    const control = new FormControl('');
    const time = '';

    component.adjustTimeValue(time, control);

    expect(control.value).toEqual('');
  });
});
