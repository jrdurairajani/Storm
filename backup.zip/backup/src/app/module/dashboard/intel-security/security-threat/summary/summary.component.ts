import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormControl, FormGroup } from '@angular/forms';
import { SecurityThreatSummary, SecurityThreatViewMode } from '../../../models/security-threat';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { MAT_DATE_FORMATS } from '@angular/material/core';

export const MY_CUSTOM_FORMATS = {
  parse: {
    dateInput: 'DD-MM-YYYY'
  },
  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

@Component({
  selector: 'strm-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_CUSTOM_FORMATS }]
})
export class SummaryComponent implements OnInit {
  @Input() isEdit: boolean;
  @Input() mode: SecurityThreatViewMode;
  @Output() emitSummary = new EventEmitter<SecurityThreatSummary>();
  data: SecurityThreatSummary;
  noTEDate = true;
  isError: boolean;
  isFormEmpty: boolean;
  threatEndDateError: boolean;
  threatTitleLengthError: boolean;
  threatDescLengthError: boolean;
  checkCreateForm = true;
  hintColor = '#ff0000';
  descriptionHtml;
  summary = new FormGroup({
    title: new FormControl(''),
    relevantForKfssb: new FormControl(false),
    eventReceivedDate: new FormControl(''),
    eventReceivedTime: new FormControl(''),
    threatStartDate: new FormControl(''),
    threatStartTime: new FormControl(''),
    threatEndDate: new FormControl(''),
    threatEndTime: new FormControl(''),
    description: new FormControl('')
  });

  constructor(private route: ActivatedRoute) {}

  @Input() set setData(data: SecurityThreatSummary) {
    if (data) {
      this.data = data;
      this.descriptionHtml = data.description;
      this.summary.setValue(data);
    }
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.checkCreateForm = id === 'create';
    this.subscribeToForm();
  }

  quillResult(data: string): void {
    this.summary.controls.description.setValue(data);
  }

  dateFormatter(date): moment.Moment {
    return moment(date, 'YYYY-MM-DD');
  }

  timeFormatter(time): moment.Moment {
    return moment(time, 'HH:mm');
  }

  combinedDateTime(date, time): string {
    const dateNTime = date.set({ hour: time.hour(), minute: time.minute() });
    return dateNTime.format('YYYY-MM-DD HH:mm');
  }

  isSameDateValidation(date1, date2): boolean {
    return moment(date1).isSame(date2);
  }

  isBeforeDateValidation(date1, date2): boolean {
    return moment(date1).isBefore(date2);
  }

  isDateNTimeValid(dataX, dataY): boolean {
    const equalEventNThreatStart = moment(dataX).isSame(dataY);
    const beforeEventNThreatStart = moment(dataX).isBefore(dataY);
    return !(equalEventNThreatStart || beforeEventNThreatStart);
  }

  threatEndSameOrLaterStartDateValidation(data: SecurityThreatSummary): boolean {
    const threatStartDate = this.dateFormatter(data.threatStartDate);
    const threatStartTime = this.timeFormatter(data.threatStartTime);
    const threatEndDate = this.dateFormatter(data.threatEndDate);
    const threatEndTime = this.timeFormatter(data.threatEndTime);
    const combinedEventStartDateTime = this.combinedDateTime(threatStartDate, threatStartTime);
    const combinedThreatEndDateTime = this.combinedDateTime(threatEndDate, threatEndTime);
    if (!data.threatEndTime) {
      return this.isDateNTimeValid(data.threatStartDate, data.threatEndDate);
    }

    if (data.threatEndTime) {
      return this.isDateNTimeValid(combinedEventStartDateTime, combinedThreatEndDateTime);
    }

    return false;
  }

  threatTitleLengthValidation(data: SecurityThreatSummary): boolean {
    return !(data && data.title !== null && data.title.length <= 250);
  }

  threatDescriptionLengthValidation(data: SecurityThreatSummary): boolean {
    return !(data && data.title !== null && data.description.length <= 5000);
  }

  requiredFieldsHaveData(data: SecurityThreatSummary): boolean {
    return !!data.title && !!data.description && !!data.eventReceivedDate && !!data.threatStartDate;
  }

  adjustTimeValue(time: string, control: AbstractControl): void {
    if (!time) {
      return;
    }
    const timeSplit = time.split(':');
    if (timeSplit[1] === '00' || timeSplit[0] === '12') {
      control.setValue(`${timeSplit[0]}:${timeSplit[1]}`, { emitEvent: false });
    }
  }

  subscribeToForm(): void {
    this.summary.valueChanges.subscribe((data: SecurityThreatSummary) => {
      if (data.threatEndDate === null) {
        this.noTEDate = this.isEdit;
      } else {
        this.noTEDate = true;
      }
      let edate = data.eventReceivedDate;
      edate = moment(edate).format('YYYY-MM-DD');
      const etime = data.eventReceivedTime;
      let tSdate = data.threatStartDate;
      tSdate = moment(tSdate).format('YYYY-MM-DD');
      const tStime = data.threatStartTime;
      let tEdate = data.threatEndDate;
      tEdate = moment(tEdate).format('YYYY-MM-DD');
      const tEtime = data.threatEndTime;

      this.adjustTimeValue(etime, this.summary.controls.eventReceivedTime);
      this.adjustTimeValue(tStime, this.summary.controls.threatStartTime);
      this.adjustTimeValue(tEtime, this.summary.controls.threatEndTime);
      this.isFormEmpty = !this.requiredFieldsHaveData(data);
      if (!this.isFormEmpty) {
        this.threatTitleLengthError = this.threatTitleLengthValidation(data);
        this.threatDescLengthError = this.threatDescriptionLengthValidation(data);

        if (data.threatEndDate) {
          this.threatEndDateError = this.threatEndSameOrLaterStartDateValidation(data);
        }

        if (data.threatEndTime) {
          this.threatEndDateError = this.threatEndSameOrLaterStartDateValidation(data);
        }
      }

      this.isError =
        this.isFormEmpty ||
        this.threatTitleLengthError ||
        this.threatDescLengthError ||
        this.threatEndDateError ||
        this.threatEndDateError;
      data.isError = this.isError;

      if (this.summary.controls.eventReceivedDate.value) {
        data.eventReceivedDate = edate;
      }
      if (this.summary.controls.threatStartDate.value) {
        data.threatStartDate = tSdate;
      }
      if (this.summary.controls.threatEndDate.value) {
        data.threatEndDate = tEdate;
      }
      this.emitSummary.emit(data);
    });
  }
}
