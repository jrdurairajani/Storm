import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { POI } from '../../../models/map';

import { MapComponent } from './map.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('MapComponent', () => {
  let component: MapComponent;
  let fixture: ComponentFixture<MapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [MapComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call reloadMap and emit poi when setPoi is set', () => {
    const testPoi: POI = {
      markers: [
        {
          coordinates: { lat: 10, lng: 20 },
          type: 'primary'
        }
      ],
      polygons: []
    };

    spyOn<any>(component, 'reloadMap').and.callThrough();
    spyOn(component.emitMap, 'emit');

    component.setPoi = testPoi;

    expect(component['reloadMap']).toHaveBeenCalled();
    expect(component.emitMap.emit).toHaveBeenCalledWith(testPoi);
  });

  it('should call reloadMap when setMode is set', () => {
    const testMode = 'details';
    spyOn<any>(component, 'reloadMap').and.callThrough();
    component.setMode = testMode;
    expect(component['reloadMap']).toHaveBeenCalled();
  });
});
