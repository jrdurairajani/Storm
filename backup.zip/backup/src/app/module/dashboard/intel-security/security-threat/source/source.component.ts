import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'strm-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.scss']
})
export class SourceComponent {
  myForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.myForm = this.fb.group({
      inputA: ['', Validators.required],
      inputB: ['', Validators.required],
      rows: this.fb.array([]) // For additional rows
    });
  }
  addRow() {
    const newRow = this.fb.group({
      inputA: ['', Validators.required],
      inputB: ['', Validators.required]
    });

    this.rows.push(newRow);
  }

  get rows(): FormArray {
    return this.myForm.get('rows') as FormArray;
  }
}
