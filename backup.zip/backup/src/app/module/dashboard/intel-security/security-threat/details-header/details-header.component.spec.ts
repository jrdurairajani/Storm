import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';

import { DetailsHeaderComponent } from './details-header.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ApiSecurityThreatService } from '../../../services/api-security-threat.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Country } from '../../../models/common';

describe('DetailsHeaderComponent', () => {
  let component: DetailsHeaderComponent;
  let fixture: ComponentFixture<DetailsHeaderComponent>;
  let apiService: ApiSecurityThreatService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientTestingModule,
        MatSelectModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
        RouterModule.forRoot([])
      ],
      declarations: [DetailsHeaderComponent],
      providers: [ApiSecurityThreatService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(DetailsHeaderComponent);
    component = fixture.componentInstance;
    apiService = TestBed.inject(ApiSecurityThreatService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('#continentSelect', () => {
    it('should load country data when a continent is selected', fakeAsync(() => {
      const countries: Country[] = [
        { code: 'USA', name: 'United States of America' },
        { code: 'CAN', name: 'Canada' },
        { code: 'MEX', name: 'Mexico' }
      ];
      spyOn(apiService, 'getSecurityThreatLocations').and.returnValue(Promise.resolve(countries));
      const continent = 'North America';

      component.continentSelect(continent);
      fixture.detectChanges();
      tick();

      expect(apiService.getSecurityThreatLocations).toHaveBeenCalledWith(continent, '', '', '');
      expect(component.countryData.length).toBe(3);
      expect(component.countryData[0]).toEqual(countries[0]);
      expect(component.countryData[1]).toEqual(countries[1]);
      expect(component.countryData[2]).toEqual(countries[2]);
      expect(component.disableStateCity).toBeTrue();
      expect(component.disableLocation).toBeTrue();
    }));
  });

  describe('#existsInList', () => {
    it('should return true for an existing code in the list', () => {
      const list = [
        { code: 'ABC', name: 'Element A' },
        { code: 'DEF', name: 'Element B' },
        { code: 'GHI', name: 'Element C' }
      ];
      const exists = component.existsInList('DEF', list);
      expect(exists).toBeTrue();
    });

    it('should return false for a non-existing code in the list', () => {
      const list = [
        { code: 'ABC', name: 'Element A' },
        { code: 'DEF', name: 'Element B' },
        { code: 'GHI', name: 'Element C' }
      ];
      const exists = component.existsInList('XYZ', list);
      expect(exists).toBeFalse();
    });

    it('should return false for an empty code', () => {
      const list = [
        { code: 'ABC', name: 'Element A' },
        { code: 'DEF', name: 'Element B' },
        { code: 'GHI', name: 'Element C' }
      ];
      const exists = component.existsInList('', list);
      expect(exists).toBeFalse();
    });

    it('should return false for an empty list', () => {
      const list = [];
      const exists = component.existsInList('ABC', list);
      expect(exists).toBeFalse();
    });
  });

  describe('#getStateBasedOnCity', () => {
    it('should return the state code for a valid city code', () => {
      const cityList = [
        { code: 'ABC', name: 'City A', state: { code: 'ST1', name: 'State 1' } },
        { code: 'DEF', name: 'City B', state: { code: 'ST2', name: 'State 2' } }
      ];
      const stateCode = component.getStateBasedOnCity('ABC', cityList);
      expect(stateCode).toEqual('ST1');
    });

    it('should return undefined for an invalid city code', () => {
      const cityList = [
        { code: 'ABC', name: 'City A', state: { code: 'ST1', name: 'State 1' } },
        { code: 'DEF', name: 'City B', state: { code: 'ST2', name: 'State 2' } }
      ];
      const stateCode = component.getStateBasedOnCity('XYZ', cityList);
      expect(stateCode).toBeUndefined();
    });

    it('should return undefined for an empty city code', () => {
      const cityList = [
        { code: 'ABC', name: 'City A', state: { code: 'ST1', name: 'State 1' } },
        { code: 'DEF', name: 'City B', state: { code: 'ST2', name: 'State 2' } }
      ];
      const stateCode = component.getStateBasedOnCity('', cityList);
      expect(stateCode).toBeUndefined();
    });

    it('should return undefined for an empty city list', () => {
      const cityList = [];
      const stateCode = component.getStateBasedOnCity('ABC', cityList);
      expect(stateCode).toBeUndefined();
    });
  });

  describe('#getState', () => {
    it('should return state if state exists', () => {
      const state = 'CA';
      const freeTextState = '';
      const result = component.getState(state, freeTextState);
      expect(result).toEqual(state);
    });

    it('should return freeTextState if state does not exist', () => {
      const state = '';
      const freeTextState = 'Custom State';
      const result = component.getState(state, freeTextState);
      expect(result).toEqual(freeTextState);
    });

    it('should return NONE if neither state nor freeTextState exist', () => {
      const state = '';
      const freeTextState = '';
      const result = component.getState(state, freeTextState);
      expect(result).toEqual('NONE');
    });
  });

  it('should reset nested select elements', () => {
    // set initial values for the form's nested select elements
    component.formHeader.controls['continent'].setValue('Asia');
    component.formHeader.controls['country'].setValue('PH');
    component.formHeader.controls['state'].setValue('CA');
    component.formHeader.controls['city'].setValue('Quezon City');

    // call the resetNestedSelection method
    component.resetNestedSelection(true, true, true, true, true);

    // check if the nested select elements are reset to their initial values
    expect(component.formHeader.controls['continent'].value).toBeNull();
    expect(component.formHeader.controls['country'].value).toBeNull();
    expect(component.formHeader.controls['state'].value).toBeNull();
    expect(component.formHeader.controls['city'].value).toBeNull();
  });
});
