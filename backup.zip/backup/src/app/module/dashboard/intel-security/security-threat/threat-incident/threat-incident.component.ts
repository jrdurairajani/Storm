import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChildren,
  QueryList,
  ElementRef,
  Renderer2
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ThreatIncidentLevel } from '../../../models/security-threat';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'strm-threat-incident',
  templateUrl: './threat-incident.component.html',
  styleUrls: ['./threat-incident.component.scss']
})
export class ThreatIncidentComponent implements OnInit {
  incientForm: FormGroup;
  incidentValues: any = [
    { name: 'Station threat', value: 'station' },
    { name: 'City threat', value: 'city' },
    { name: 'Country threat', value: 'country' },
    { name: 'Continent threat', value: 'continent' },
    { name: 'Worldwide threat', value: 'world' }
  ];

  checkCreateForm = true;
  isChecked = false;
  defaultCheckArr: any;
  selectBlock = true;
  permitter = 0;
  @Output() emitThreadLevel = new EventEmitter<ThreatIncidentLevel>();
  @Input() isEdit;
  @ViewChildren('myCheckbox') private myCheckboxes: QueryList<any>;
  @Input() set threatLevelRetrieve(data: ThreatIncidentLevel) {
    if (data && !this.checkCreateForm) {
      const allSelected = [];
      const totalSelected = Object.values(data.levelGroup).reduce((a, item) => a + item, 0);
      const checker = (arr) => arr.every(Boolean);
      Object.keys(data.levelGroup).forEach((key, idx) => {
        if (idx <= totalSelected - 1) {
          for (let i = 0; i <= idx; i++) {
            allSelected.push(data.levelGroup[key]);
          }
        }
      });

      if (this.permitter == 0) {
        this.selectedIndex = totalSelected - 1;
        if (checker(allSelected)) {
          for (let i = 0; i <= totalSelected - 2; i++) {
            this.renderer.addClass(
              this.elem.nativeElement.querySelector(`#mat-checkbox-${i + 1}`),
              'mat-checkbox-indeterminate'
            );
          }
        } else {
          for (let i = 0; i <= totalSelected - 1; i++) {
            Object.keys(data.levelGroup).forEach((key, idx) => {
              if (data.levelGroup[key] == true) {
                this.renderer.addClass(
                  this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
                  'mat-checkbox-checked'
                );
              }
            });
          }
        }
        this.permitter = 1;
      }

      this.incientForm.setValue(data);
      this.defaultCheckArr = data.levelGroup;
    }
  }

  incident: any;
  selectedIndex: number;
  resultValue = [];

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private elem: ElementRef,
    private renderer: Renderer2
  ) {
    this.incientForm = fb.group({
      levelGroup: fb.group({
        station: false,
        city: false,
        country: false,
        continent: false,
        world: false
      }),
      overFlightZone: 'none'
    });
  }

  subscribeForm() {
    this.incientForm.valueChanges.subscribe((res) => {
      this.emitThreadLevel.emit(this.incientForm.value);
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.checkCreateForm = id === 'create' ? true : false;
    this.subscribeForm();
  }

  changeSelection(event, index) {
    if (event.checked) {
      this.selectedIndex = event.checked ? index : index;
      this.defaultCheckArr = this.incientForm.controls['levelGroup'].value;
      Object.keys(this.defaultCheckArr).forEach((key, idx) => {
        if (index >= idx) {
          if (idx < index) {
            this.renderer.addClass(
              this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
              'mat-checkbox-indeterminate'
            );
          }
          this.defaultCheckArr[key] = true;
        } else {
          this.defaultCheckArr[key] = false;
        }
        this.selectBlock = true;
      });
    } else {
      if (this.selectedIndex == index && this.selectBlock) {
        // this.selectedIndex = -1;
        Object.keys(this.defaultCheckArr).forEach((key, idx) => {
          if (this.defaultCheckArr[key] == true) {
            if (index == idx) {
              this.defaultCheckArr[key] = false;
              this.renderer.removeClass(
                this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
                'mat-checkbox-indeterminate'
              );
            }
            if (idx < index) {
              this.renderer.removeClass(
                this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
                'mat-checkbox-indeterminate'
              );
              this.renderer.addClass(
                this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
                'mat-checkbox-checked'
              );
            }
          }
        });
      } else if (this.selectedIndex > index) {
        Object.keys(this.defaultCheckArr).forEach((key, idx) => {
          if (index == idx) {
            this.defaultCheckArr[key] = false;
            this.renderer.removeClass(
              this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
              'mat-checkbox-indeterminate'
            );
          } else if (this.defaultCheckArr[key]) {
            this.selectBlock = false;
            this.renderer.removeClass(
              this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
              'mat-checkbox-indeterminate'
            );
            this.renderer.addClass(
              this.elem.nativeElement.querySelector(`#mat-checkbox-${idx + 1}`),
              'mat-checkbox-checked'
            );
          }
        });
      } else {
        Object.keys(this.defaultCheckArr).forEach((key, idx) => {
          if (index == idx) {
            this.defaultCheckArr[key] = false;
          }
        });
      }
    }
    this.incientForm.controls['levelGroup'].setValue(this.defaultCheckArr);
    this.incientForm.controls['levelGroup'].updateValueAndValidity();
    this.incident = this.incientForm.value;
  }
}
