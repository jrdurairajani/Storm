import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApiData, Details } from '../../../models/security-threat';
import { ApiSecurityThreatService } from '../../../services/api-security-threat.service';

@Component({
  selector: 'strm-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  public details = new FormGroup({
    category: new FormControl([])
  });
  public isApiData: boolean;
  public apiData: ApiData;
  public categoryViewData: string[];
  @Output() emitDetails = new EventEmitter<Details>();
  @Input() isEdit;
  public categories!: string[];

  constructor(private apiThreatData: ApiSecurityThreatService) {}

  @Input() set setDetails(details: Details) {
    if (details?.apiData) {
      this.apiData = details.apiData;
      this.isApiData = true;
    } else {
      this.isApiData = false;
    }
    if (details?.category) {
      this.categoryViewData = details.category;
      this.details.controls.category.setValue(details.category);
    }
    this.emitDetails.emit(details);
  }

  public ngOnInit(): void {
    this.apiThreatData.getCategoryListing().subscribe((resp) => {
      this.categories = resp;
    });
    this.subscribeToForm();
  }

  public sentenceCase(txt): string {
    let formatText = txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase();
    if (formatText == 'Assettypes') {
      formatText = 'Asset types';
    } else if (formatText == 'Attacktype') {
      formatText = 'Attack types';
    } else if (formatText == 'Secondarycountries') {
      formatText = 'Secondary countries';
    }
    return formatText;
  }

  private subscribeToForm(): void {
    this.details.valueChanges.subscribe((data) => {
      const details: Details = {
        category: data.category,
        apiData: this.apiData
      };
      this.emitDetails.emit(details);
    });
  }
}
