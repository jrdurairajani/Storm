import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AddSource } from '../../../models/security-threat';

@Component({
  selector: 'strm-add-source',
  templateUrl: './add-source.component.html',
  styleUrls: ['./add-source.component.scss']
})
export class AddSourceComponent implements OnInit, OnChanges {
  isTyped = false;
  maxLimited = false;
  isVisible = false;
  cnt = 0;
  btnPermit = 0;
  count;
  permitter = 0;
  validationCheck = false;
  isError: boolean;
  isSourceAPI = false;
  apiSourceData;
  @Output() emitSource = new EventEmitter<AddSource[]>();
  @Input() isEdit;
  @Input() mode;
  @Input() sourceMode;

  @Input() set sourceRetrieve(data: AddSource[]) {
    const dataFilter = [];
    if (data && this.mode == 'details' && !this.isEdit && this.permitter == 0) {
      data.forEach((item) => {
        if (item.name !== '') {
          dataFilter.push(item);
        }
      });
      this.sources.clear();
      if (dataFilter.length > 0) {
        dataFilter.filter((item, index) => {
          if (item.disabled) {
            this.count = index;
          }
        });
        this.isVisible = true;
        dataFilter.forEach((sourceList, index) => {
          this.sources.push(
            this.formBuilder.group({
              name: sourceList.name,
              link: sourceList.link,
              isDelete: true,
              isAPISource: sourceList.disabled,
              disabled: sourceList.disabled
            })
          );
          this.sources.controls[index].get('name').markAsTouched();
          this.sources.controls[index].get('name').addValidators(Validators.required);
        });
      } else {
        this.count = dataFilter.length;
      }
    }
    if (this.sourceMode == 'apiSource' && this.permitter == 0) {
      data.forEach((item) => {
        dataFilter.push(item);
      });
      this.sources.clear();
      if (dataFilter.length > 0) {
        this.count = dataFilter.length - 1;
        this.isVisible = true;
        dataFilter.forEach((sourceList) => {
          this.sources.push(
            this.formBuilder.group({
              name: sourceList.name,
              link: sourceList.link,
              isDelete: false,
              isAPISource: true,
              disabled: true
            })
          );
        });

        this.createFieldRow();
        this.permitter = 1;
      } else {
        this.count = dataFilter.length;
      }
    }
  }

  contact = {
    sources: []
  };

  form: FormGroup = this.formBuilder.group({
    sources: this.buildsources(this.contact.sources)
  });

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    if (this.sourceMode == 'noApiSource') {
      this.createFieldRow();
    }
    this.valueEmitter(this.sources.value);
    this.cnt = 1;
    this.btnPermit = this.sources.length;
    this.isVisible = true;
  }

  ngOnChanges(): void {
    if (!this.isEdit && this.mode == 'details') {
      this.form.disable();
      if (this.sources.length > 0) {
        this.isVisible = true;
      } else {
        this.isVisible = false;
      }
    } else {
      this.form.enable();
      this.isVisible = true;
      if (this.mode !== 'create' && this.sources.length == 0 && this.permitter == 0) {
        this.createFieldRow();
        this.btnPermit = 1;
        this.permitter = 1;
      }
    }
    if (this.isEdit && this.mode !== 'create') {
      if (this.mode !== 'create' && this.sources.length <= 2 && this.permitter == 0) {
        this.addContactField(this.sources.length - 1);
        this.permitter = 1;
      }
    }
  }

  get sources(): FormArray {
    return this.form.get('sources') as FormArray;
  }

  createFieldRow(): void {
    if (this.sourceMode == 'apiSource') {
      return this.sources.push(
        this.formBuilder.group({
          name: '',
          link: '',
          isDelete: false,
          isAPISource: false
        })
      );
    } else {
      return this.sources.push(
        this.formBuilder.group({
          name: '',
          link: '',
          isDelete: false,
          isAPISource: false
        })
      );
    }
  }

  buildsources(
    sources: {
      name: string;
      link: string;
      isDelete: boolean;
      isAPISource: boolean;
      disabled: boolean;
    }[] = []
  ): FormArray {
    return this.formBuilder.array(sources.map((contact) => this.formBuilder.group(contact)));
  }

  addContactField(index): void {
    if (this.sources.controls[index].get('name').value == '') {
      this.sources.controls[index].get('name').markAsTouched();
      this.sources.controls[index].get('name').addValidators(Validators.required);
    } else {
      this.sources.controls[index].patchValue({ isDelete: true });
    }
    this.sources.updateValueAndValidity();
    const maxCount = 3;
    if (this.sources.length <= maxCount && this.sources.controls[index].get('name').value !== '') {
      if (this.sources.length < maxCount) {
        this.createFieldRow();
      }
    } else {
      this.maxLimited = true;
    }
    this.valueEmitter(this.sources.value);
  }

  updateValue(index: number, fieldName: string, event): void {
    const sorceUpdate = [];
    if (this.sources.controls[index].get('isDelete').value) {
      this.sources.controls[index].get(fieldName).patchValue(event.target.value);
      this.sources.value.forEach((item, sourceindex) => {
        if (this.sources.controls[sourceindex].get('isDelete').value) {
          sorceUpdate.push(this.sources.controls[sourceindex].value);
          this.valueEmitter(sorceUpdate);
        }
      });
    } else {
      this.sources.controls[index].get('name').markAsTouched();
      this.sources.controls[index].get('name').addValidators(Validators.required);
    }
  }

  removeContactField(index: number): void {
    if (this.sources.length >= 1) {
      this.sources.removeAt(index);
      this.valueEmitter(this.sources.value);
    } else {
      this.sources.patchValue([{ name: '', link: '' }]);
      this.valueEmitter(this.sources.value);
    }
    this.sources.controls[this.sources.length - 1].patchValue({ isDelete: false });
  }

  valueEmitter(sourceOutput) {
    const filteredSource = sourceOutput.filter((item) => {
      delete item.isAPISource;
      delete item.isDelete;
      return item;
    });
    const correctRecord = filteredSource.filter((res) => res.name !== '');
    this.emitSource.emit(correctRecord);
  }

  openURL(index: number): void {
    const url = this.sources.value[index].link;
    const validURLCheck = this.isValidUrl(url);
    if (!url.startsWith('http') && url.endsWith('.com') && !url.startsWith('www')) {
      if (validURLCheck) {
        window.open(`https://www.${url}`, '_blank');
      }
    }
    if (!url.startsWith('http') && url.startsWith('www') && url.endsWith('.com')) {
      if (validURLCheck) {
        window.open(`https://${url}`, '_blank');
      }
    }
    if (validURLCheck && url.startsWith('https')) {
      window.open(url, '_blank');
    }
    if (url.startsWith('https') || url.startsWith('http')) {
      window.open(url, '_blank');
    }
  }

  isValidUrl(url): boolean {
    const urlPattern = new RegExp(
      '^(https?:\\/\\/)?' +
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' +
        '((\\d{1,3}\\.){3}\\d{1,3}))' +
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' +
        '(\\?[;&a-z\\d%_.~+=-]*)?' +
        '(\\#[-a-z\\d_]*)?$',
      'i'
    );
    return !!urlPattern.test(url);
  }
}
