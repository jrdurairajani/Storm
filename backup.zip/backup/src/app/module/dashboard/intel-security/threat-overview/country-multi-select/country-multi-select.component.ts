import { Component, EventEmitter, Input, Output } from '@angular/core';
import { firstValueFrom, Observable } from 'rxjs';
import { SecurityEventService } from '../../../services/security-event.service';
import { Country } from '../../../models/common';

@Component({
  selector: 'strm-country-multiselect',
  templateUrl: './country-multi-select.component.html',
  styleUrls: ['./country-multi-select.component.scss']
})
export class CountryMultiSelectComponent {
  @Input() countryFilter: Country[] = [];
  @Output() searchEmit = new EventEmitter<Country[]>();
  public filteredCountries: Country[];
  private countryListObservable: Observable<Country[]>;

  constructor(securityEventService: SecurityEventService) {
    this.countryListObservable = securityEventService.countryListObservable;
  }

  public async filterCountry(event: { query: string }): Promise<void> {
    const query = event.query;
    this.filteredCountries = (await firstValueFrom(this.countryListObservable)).filter(
      (country) => country.name.toLowerCase().search(query.toLowerCase()) > -1
    );
  }

  public emitChanges(): void {
    this.searchEmit.emit(this.countryFilter);
  }
}
