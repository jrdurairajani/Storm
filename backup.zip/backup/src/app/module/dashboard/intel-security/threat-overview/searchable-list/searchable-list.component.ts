import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { map, Observable, startWith } from 'rxjs';
import { City, ElementWithCodeAndName, State } from '../../../models/security-threat';

@Component({
  selector: 'strm-searchable-list',
  templateUrl: './searchable-list.component.html',
  styleUrls: ['./searchable-list.component.scss']
})
export class SearchableListComponent {
  itemCtrl: FormControl;
  filteredItems: Observable<any[]>;
  showAddButton = false;

  prompt = 'Press <enter> to add "';

  items: City[] | State[] = [];
  startValue: string;

  @Output() valueEmit = new EventEmitter<any>();
  @Input() mode: string;
  @Input() disable: boolean;

  @Input() set setList(data: City[] | State[]) {
    this.items = data;
    const name = this.getFullName(this.items, this.startValue);
    this.itemCtrl.setValue(name);
    this.itemCtrl.updateValueAndValidity();
  }

  @Input() set setStartValue(value: string) {
    this.handleStartValue(value);
  }

  handleStartValue(value: string): void {
    if (value !== 'NONE') {
      this.startValue = value;
      const name = this.getFullName(this.items, this.startValue);
      this.itemCtrl.setValue(name);
    } else {
      this.itemCtrl.setValue('');
      this.startValue = '';
    }
  }

  getFullName(items, startValue): string {
    if (items.length > 0 && startValue) {
      const found = items.find((el) => el.code.toLowerCase() === startValue.toLowerCase());
      if (found) {
        return found.name.toLowerCase();
      } else {
        return startValue?.toLowerCase();
      }
    } else {
      return startValue;
    }
  }

  constructor() {
    this.itemCtrl = new FormControl();
    this.filteredItems = this.itemCtrl.valueChanges.pipe(
      startWith(''),
      map((item) => (item ? this.filterItems(item) : this.items.map((i) => i.name)))
    );

    this.itemCtrl.valueChanges.subscribe((value) => {
      if (value === '') {
        const emitValue: ElementWithCodeAndName = {
          code: '',
          name: ''
        };
        this.valueEmit.emit({ emitValue, displayValue: '' });
      }
    });
  }

  filterItems(name: string): string[] {
    let results = this.items
      .filter((item) => item.name.toLowerCase().startsWith(name.toLowerCase()))
      .map((i) => i.name);
    this.showAddButton = results.length === 0;
    if (this.showAddButton) {
      results = [this.prompt + name + '"'];
    }
    return results;
  }

  optionSelected(option): void {
    const value = option.value;
    let emitValue: ElementWithCodeAndName;
    let displayValue: string;
    const foundItem = this.items.find((item) => item.name.toLowerCase() === value.toLowerCase());
    if (foundItem) {
      emitValue = foundItem;
      displayValue = foundItem.name;
    } else {
      const item = this.addOption();
      emitValue = item;
      displayValue = item.name;
    }
    this.itemCtrl.setValue(displayValue, { emitEvent: false });
    this.valueEmit.emit({ emitValue, displayValue });
  }

  addOption(): ElementWithCodeAndName {
    const name = this.removePromptFromOption(this.itemCtrl.value);
    const newItem: ElementWithCodeAndName = { name, code: 'new_code' };
    this.items.push(newItem);
    this.valueEmit.emit({ emitValue: newItem, displayValue: newItem.name });
    this.itemCtrl.setValue(newItem.name, { emitEvent: false });
    return newItem;
  }

  removePromptFromOption(option: string): string {
    if (option.startsWith(this.prompt)) {
      return option.substring(this.prompt.length, option.length - 1);
    }
    return option;
  }
}
