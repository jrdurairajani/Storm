import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchableListComponent } from './searchable-list.component';
import { MatAutocomplete } from '@angular/material/autocomplete';
import { FormControl } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('SearchableListComponent', () => {
  let component: SearchableListComponent;
  let fixture: ComponentFixture<SearchableListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchableListComponent, MatAutocomplete],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(SearchableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('#handleStartValue', () => {
    it('should handle start value correctly', () => {
      component.itemCtrl = new FormControl('');
      component.items = [
        { code: '1', name: 'Item One' },
        { code: '2', name: 'Item Two' }
      ];

      spyOn(component, 'getFullName').and.callFake((items, code) => {
        const item = items.find((i) => i.code === code);
        return item ? item.name : null;
      });

      component.handleStartValue('1');
      expect(component.startValue).toBe('1');
      expect(component.itemCtrl.value).toBe('Item One');

      component.handleStartValue('NONE');
      expect(component.startValue).toBe('');
      expect(component.itemCtrl.value).toBe('');
    });
  });

  describe('#getFullName', () => {
    it('should return name from items when match found', () => {
      const items = [
        { code: 'A1', name: 'Alice' },
        { code: 'B2', name: 'Bob' }
      ];
      const result = component.getFullName(items, 'A1');
      expect(result).toBe('alice');
    });

    it('should return startValue when no match found', () => {
      const items = [
        { code: 'A1', name: 'Alice' },
        { code: 'B2', name: 'Bob' }
      ];
      const result = component.getFullName(items, 'Z3');
      expect(result).toBe('z3');
    });

    it('should return startValue when items array is empty', () => {
      const items = [];
      const result = component.getFullName(items, 'A1');
      expect(result).toBe('A1');
    });

    it('should return startValue when startValue is null or undefined', () => {
      const items = [
        { code: 'A1', name: 'Alice' },
        { code: 'B2', name: 'Bob' }
      ];
      expect(component.getFullName(items, null)).toBeNull();
      expect(component.getFullName(items, undefined)).toBeUndefined();
    });
  });

  describe('#filterItems', () => {
    beforeEach(() => {
      component.items = [
        { code: 'A1', name: 'Alice' },
        { code: 'B2', name: 'Bob' },
        { code: 'C3', name: 'Charlie' },
        { code: 'D4', name: 'David' }
      ];
    });

    it('should return all items when name is empty', () => {
      const result = component.filterItems('');
      expect(result).toEqual(['Alice', 'Bob', 'Charlie', 'David']);
      expect(component.showAddButton).toBeFalsy();
    });

    it('should return matching items', () => {
      const result = component.filterItems('a');
      expect(result).toEqual(['Alice']);
      expect(component.showAddButton).toBeFalsy();
    });

    it('should return prompt when no matches found', () => {
      const result = component.filterItems('e');
      expect(result).toEqual(['Press <enter> to add "e"']);
      expect(component.showAddButton).toBeTruthy();
    });

    it('should add new item when prompt is selected', () => {
      const addSpy = spyOn(component, 'addOption').and.returnValue({
        name: 'newItem',
        code: 'newCode'
      });
      const option = { value: 'Press <enter> to add "newItem"' };
      component.filterItems('e');
      component.optionSelected(option);
      expect(addSpy).toHaveBeenCalled();
      expect(component.itemCtrl.value).toEqual('newItem');
    });
  });

  describe('#optionSelected', () => {
    beforeEach(() => {
      component.items = [
        { code: 'A1', name: 'Alice' },
        { code: 'B2', name: 'Bob' },
        { code: 'C3', name: 'Charlie' },
        { code: 'D4', name: 'David' }
      ];
    });

    it('should emit existing item value when found in items', () => {
      const emitSpy = spyOn(component.valueEmit, 'emit');
      const option = { value: 'Bob' };
      component.optionSelected(option);
      expect(emitSpy).toHaveBeenCalledWith({
        emitValue: { code: 'B2', name: 'Bob' },
        displayValue: 'Bob'
      });
      expect(component.itemCtrl.value).toEqual('Bob');
    });

    it('should add new item and emit value when prompt is selected', () => {
      const addSpy = spyOn(component, 'addOption').and.returnValue({
        name: 'newItem',
        code: 'newCode'
      });
      const emitSpy = spyOn(component.valueEmit, 'emit');
      const option = { value: 'Press <enter> to add "newItem"' };
      component.optionSelected(option);
      expect(addSpy).toHaveBeenCalled();
      expect(emitSpy).toHaveBeenCalledWith({
        emitValue: { name: 'newItem', code: 'newCode' },
        displayValue: 'newItem'
      });
      expect(component.itemCtrl.value).toEqual('newItem');
    });

    it('should emit empty value when item is deselected', () => {
      const emitSpy = spyOn(component.valueEmit, 'emit');
      component.itemCtrl.setValue('');
      expect(emitSpy).toHaveBeenCalledWith({ emitValue: { code: '', name: '' }, displayValue: '' });
    });
  });

  describe('#AddOption', () => {
    it('should add a new item and emit value', () => {
      const emitSpy = spyOn(component.valueEmit, 'emit');
      component.itemCtrl = new FormControl('testOption');

      const newItem = component.addOption();

      expect(newItem).toEqual({ name: 'testOption', code: 'new_code' });
      expect(component.items).toEqual([{ name: 'testOption', code: 'new_code' }]);
      expect(emitSpy).toHaveBeenCalledWith({ emitValue: newItem, displayValue: 'testOption' });
    });
  });

  describe('removePromptFromOption', () => {
    it('should remove prompt from option', () => {
      component.prompt = 'prompt:';
      const option = 'prompt:TestOption';
      const result = component.removePromptFromOption(option);
      expect(result).toEqual('TestOptio');
    });

    it('should return original string if it does not start with prompt', () => {
      component.prompt = 'prompt:';
      const option = 'TestOption';
      const result = component.removePromptFromOption(option);
      expect(result).toEqual('TestOption');
    });
  });
});
