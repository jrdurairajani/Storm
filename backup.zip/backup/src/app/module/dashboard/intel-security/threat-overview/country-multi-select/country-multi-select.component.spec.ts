import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CountryMultiSelectComponent } from './country-multi-select.component';
import { SecurityEventService } from '../../../services/security-event.service';
import { of } from 'rxjs';
import { Country } from '../../../models/security-threat';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('CountryMultiSelectComponent', () => {
  let mockSecurityEventService: jasmine.SpyObj<SecurityEventService>;
  let component: CountryMultiSelectComponent;
  let fixture: ComponentFixture<CountryMultiSelectComponent>;
  const mockCountries: Country[] = [
    { name: 'Hungary', code: 'HU' },
    { name: 'Netherlands', code: 'NL' }
  ];

  beforeEach(async () => {
    mockSecurityEventService = jasmine.createSpyObj('SecurityEventService', [], {
      countryListObservable: of(mockCountries)
    });

    await TestBed.configureTestingModule({
      declarations: [CountryMultiSelectComponent],
      providers: [{ provide: SecurityEventService, useValue: mockSecurityEventService }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(CountryMultiSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should filter on loaded countries', async () => {
    await component.filterCountry({ query: 'Hun' });
    expect(component.filteredCountries).toEqual([{ name: 'Hungary', code: 'HU' }]);
  });
});
