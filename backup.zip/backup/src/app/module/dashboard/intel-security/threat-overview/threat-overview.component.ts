import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  FilterValue,
  KfssbFilterValue
} from '../../services/filter.service';
import {
  SecurityThreatOverview,
  SecurityThreatRecord
} from '../../models/security-threat-overview';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import { Observable, Subscription, switchMap, tap } from 'rxjs';
import { LazyLoadEvent } from 'primeng/api';
import { Country } from '../../models/common';
import { DateUtilService, DISPLAY_DATE_FORMAT } from '../../../../core/services/date-util.service';

const FILTER_CONSUMER_KEY = FilterConsumerKey.THREATS;

@Component({
  selector: 'strm-threat-overview',
  templateUrl: './threat-overview.component.html',
  styleUrls: ['./threat-overview.component.scss']
})
export class ThreatOverviewComponent implements OnInit, OnDestroy {
  public tableData: SecurityThreatRecord[] = [];
  public isLoading: boolean;
  public currentPage: number;
  public numberOfPages: number;
  public totalRecords: number;
  public displayedColumns: string[] = [
    'referenceNumber',
    'createdBy',
    'title',
    'country',
    'dateTime',
    'kfssb',
    'delete'
  ];
  public kfssbFilters = [
    {
      label: 'KFSSB: Relevant',
      value: 'relevant'
    },
    {
      label: 'KFSSB: Not Relevant',
      value: 'notRelevant'
    }
  ];

  private subscriptions: Subscription = new Subscription();
  private isLoadingTimeoutId: number;

  constructor(
    private apiSecurityThreatService: ApiSecurityThreatService,
    private router: Router,
    private filterService: FilterService
  ) {}

  private _startDateFilter: string | null;

  get startDateFilter(): string | null {
    return this._startDateFilter;
  }

  set startDateFilter(value: string | null) {
    this._startDateFilter = value;
    this.filterDates();
  }

  private _endDateFilter: string | null;

  get endDateFilter(): string | null {
    return this._endDateFilter;
  }

  set endDateFilter(value: string | null) {
    this._endDateFilter = value;
    this.filterDates();
  }

  private _dateFilter: DateFilterValue | null;

  get dateFilter(): DateFilterValue | null {
    return this._dateFilter;
  }

  set dateFilter(dateFilter: DateFilterValue | null) {
    this._dateFilter = dateFilter;
    this._startDateFilter = this.dateFilter?.startDate
      ? DateUtilService.formatDate(this.dateFilter?.startDate, DISPLAY_DATE_FORMAT)
      : null;
    this._endDateFilter = this.dateFilter?.endDate
      ? DateUtilService.formatDate(this.dateFilter?.endDate, DISPLAY_DATE_FORMAT)
      : null;
  }

  private _countryFilter: Country[] = [];

  get countryFilter(): Country[] {
    return this._countryFilter;
  }

  set countryFilter(countryFilter: Country[]) {
    this._countryFilter = countryFilter;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, this.dateFilter],
      [FilterKey.COUNTRY, countryFilter],
      [FilterKey.KFSSB, this.kfssbFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  private _kfssbFilter: KfssbFilterValue;

  get kfssbFilter(): KfssbFilterValue {
    return this._kfssbFilter;
  }

  set kfssbFilter(kfssbFilter: KfssbFilterValue) {
    this._kfssbFilter = kfssbFilter;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, this.dateFilter],
      [FilterKey.COUNTRY, this.countryFilter],
      [FilterKey.KFSSB, kfssbFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  public ngOnInit(): void {
    const sub = this.filterService.filterObservable
      .pipe(
        tap((filters) => this.assignFilters(filters.get(FILTER_CONSUMER_KEY))),
        tap(() => (this.currentPage = this.filterService.getPagination(FILTER_CONSUMER_KEY))),
        switchMap(() => this.getSecurityThreatOverviewObservable())
      )
      .subscribe((securityEventsOverview) =>
        this.handleSecurityThreatOverview(securityEventsOverview)
      );
    this.subscriptions.add(sub);
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public getFirstRowOffset(page: number, rowsPerPage: number): number {
    return (page - 1) * rowsPerPage;
  }

  public filterCountries(countries: Country[]): void {
    this.resetPagination();
    this.countryFilter = countries;
  }

  public filterKfssb(): void {
    this.resetPagination();
  }

  public removeFilters(): void {
    this._startDateFilter = null;
    this._endDateFilter = null;
    this._kfssbFilter = null;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, null],
      [FilterKey.COUNTRY, []],
      [FilterKey.KFSSB, null]
    ]);
    this.resetPagination();
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  public async createSecurityThreat(): Promise<void> {
    await this.router.navigate(['/dashboard/security-threats', 'create']);
  }

  public async openSecurityThreat(id: string, index: number): Promise<void> {
    const lastDigit = index % 10;
    await this.router.navigate(['/dashboard/security-threats', id], {
      queryParams: { page: this.currentPage, index: lastDigit }
    });
  }

  public loadSecurityThreats(lazyLoadEvent: LazyLoadEvent): void {
    if (lazyLoadEvent?.rows) {
      this.currentPage = this.convertFirstRowOffsetToPageNumber(lazyLoadEvent.first, 10);
      this.filterService.setPagination(FILTER_CONSUMER_KEY, this.currentPage);
    }

    const subscription = this.getSecurityThreatOverviewObservable().subscribe(
      (securityEventsOverview) => this.handleSecurityThreatOverview(securityEventsOverview)
    );
    this.subscriptions.add(subscription);
  }

  public archiveThreat(removalItem: SecurityThreatRecord): void {
    const subscription = this.apiSecurityThreatService.archive(removalItem.id).subscribe(() => {
      const firstRowOffset = this.getFirstRowOffset(this.currentPage, 10);
      this.loadSecurityThreats({ first: firstRowOffset });
    });
    this.subscriptions.add(subscription);
  }

  private handleSecurityThreatOverview(securityEventsOverview: SecurityThreatOverview): void {
    this.assignResponse(securityEventsOverview);
    clearTimeout(this.isLoadingTimeoutId);
    this.isLoading = false;
  }

  private getSecurityThreatOverviewObservable(): Observable<SecurityThreatOverview> {
    return this.apiSecurityThreatService
      .getSecurityThreatOverview(
        this.currentPage,
        this.dateFilter?.startDate,
        this.dateFilter?.endDate,
        this.countryFilter,
        this.kfssbFilter,
        'open'
      )
      .pipe(
        tap(() => {
          // Delay the loading indicator to avoid flickering
          this.isLoadingTimeoutId = setTimeout(() => {
            this.isLoading = true;
          }, 400);
        })
      );
  }

  private filterDates(): void {
    this.resetPagination();
    const dateFilter = this.filterService.createDateFilter(
      this.startDateFilter,
      this.endDateFilter
    );
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, dateFilter],
      [FilterKey.COUNTRY, this.countryFilter],
      [FilterKey.KFSSB, this.kfssbFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  private resetPagination(): void {
    this.filterService.setPagination(FILTER_CONSUMER_KEY, 1);
    this.currentPage = this.filterService.getPagination(FILTER_CONSUMER_KEY);
  }

  private assignFilters(filters: Map<FilterKey, FilterValue>): void {
    this.dateFilter = filters?.get(FilterKey.DATE) as DateFilterValue;
    this._countryFilter = (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [];
    this._kfssbFilter = filters?.get(FilterKey.KFSSB) as KfssbFilterValue;
  }

  private convertFirstRowOffsetToPageNumber(firstRowOffset: number, rowsPerPage: number): number {
    return Math.floor(firstRowOffset / rowsPerPage) + 1;
  }

  private assignResponse(securityThreatOverview: SecurityThreatOverview): void {
    this.tableData = securityThreatOverview.items;
    this.numberOfPages = securityThreatOverview.totalPages;
    this.totalRecords = securityThreatOverview.totalElements;
  }
}
