import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreatOverviewComponent } from './threat-overview.component';
import { ApiSecurityThreatService } from '../../services/api-security-threat.service';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  FilterValue,
  KfssbFilterValue
} from '../../services/filter.service';
import { SecurityThreatOverview } from '../../models/security-threat-overview';
import { of } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Country } from '../../models/common';

describe('ThreatOverviewComponent', () => {
  let component: ThreatOverviewComponent;
  let fixture: ComponentFixture<ThreatOverviewComponent>;
  let mockApiSecurityThreatService: jasmine.SpyObj<ApiSecurityThreatService>;
  const mockSecurityThreatOverview: SecurityThreatOverview = {
    items: [
      {
        id: '8cc87b96-ecae-470a-a94f-63754844ec68',
        referenceNumber: '131223-002',
        createdBy: 'i.i',
        title: 'Test threat 2',
        countryName: 'India',
        countryCode: 'IN',
        date: '2023-12-13',
        time: null,
        kfssb: true
      },
      {
        id: 'f14b2366-9e81-4b01-a3b7-206f921dce59',
        referenceNumber: '131223-001',
        createdBy: 'i.i',
        title: 'Test threat 1',
        countryName: 'Yemen',
        countryCode: 'YE',
        date: '2023-12-13',
        time: null,
        kfssb: false
      }
    ],
    totalPages: 1,
    totalElements: 2,
    size: 10
  };
  const FILTER_CONSUMER_KEY = FilterConsumerKey.THREATS;
  const mockFilters: Map<FilterConsumerKey, Map<FilterKey, FilterValue>> = new Map();
  mockFilters.set(FILTER_CONSUMER_KEY, new Map());
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.DATE, null);
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.COUNTRY, []);
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.KFSSB, null);
  let mockFilterService: jasmine.SpyObj<FilterService>;

  beforeEach(async () => {
    mockApiSecurityThreatService = jasmine.createSpyObj('ApiSecurityThreatService', [
      'getSecurityThreatOverview'
    ]);
    mockApiSecurityThreatService.getSecurityThreatOverview.and.returnValue(
      of(mockSecurityThreatOverview)
    );
    mockFilterService = jasmine.createSpyObj('FilterService', [
      'getPagination',
      'setPagination',
      'addFilters',
      'filterObservable',
      'createDateFilter'
    ]);
    mockFilterService.getPagination.and.returnValue(1);
    mockFilterService.filterObservable = of(mockFilters);

    await TestBed.configureTestingModule({
      providers: [
        {
          provide: ApiSecurityThreatService,
          useValue: mockApiSecurityThreatService
        },
        {
          provide: FilterService,
          useValue: mockFilterService
        }
      ],
      imports: [HttpClientTestingModule],
      declarations: [ThreatOverviewComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ThreatOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load pagination on init', () => {
    expect(mockFilterService.getPagination).toHaveBeenCalledOnceWith(FILTER_CONSUMER_KEY);
  });

  describe('filters', () => {
    it('should load on init', () => {
      expect(component.dateFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.DATE) as DateFilterValue
      );
      expect(component.countryFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.COUNTRY) as Country[]
      );
      expect(component.kfssbFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.KFSSB) as KfssbFilterValue
      );
    });

    it('change of date should reset pagination', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.startDateFilter = '2023-12-24T18;00;00';
      expect(component.currentPage).toBe(1);
    });

    it('change of countries should reset pagination', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.filterCountries([{ code: 'NL', name: 'Netherlands' }]);
      expect(component.currentPage).toBe(1);
    });

    it('change of kfssb should reset pagination', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.kfssbFilter = 'notRelevant';
      component.filterKfssb();
      expect(component.currentPage).toBe(1);
    });

    it('reset should reset pagination', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.removeFilters();
      expect(component.currentPage).toBe(1);
    });

    it('reset should reset pagination and filters', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.kfssbFilter = 'notRelevant';
      component.startDateFilter = '01-03-2024';

      component.removeFilters();
      expect(component.currentPage).toBe(1);
      expect(component.startDateFilter).toBeNull();
      expect(component.endDateFilter).toBeNull();
      expect(component.dateFilter).toBeNull();
      expect(component.countryFilter).toEqual([]);
      expect(component.kfssbFilter).toBeNull();
    });
  });

  it('should load threats on init', () => {
    expect(mockApiSecurityThreatService.getSecurityThreatOverview).toHaveBeenCalledOnceWith(
      1,
      undefined,
      undefined,
      [],
      null,
      'open'
    );
    expect(component.totalRecords).toEqual(mockSecurityThreatOverview.items.length);
    expect(component.numberOfPages).toEqual(mockSecurityThreatOverview.totalPages);
    expect(component.tableData.length).toEqual(mockSecurityThreatOverview.items.length);
  });

  describe('loadSecurityThreats', () => {
    it('should set pagination if lazyLoadEvent.rows is provided', () => {
      component.loadSecurityThreats({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);
    });
  });
});
