import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  FilterValue
} from '../../services/filter.service';
import {
  SecurityEventOverview,
  SecurityEventRecord,
  SourceFilter
} from '../../models/security-event-overview';
import { ApiSecurityEventService } from '../../services/api-security-event.service';
import { SelectionModel } from '@angular/cdk/collections';
import { Observable, Subscription, switchMap, tap } from 'rxjs';
import { LazyLoadEvent } from 'primeng/api';
import { Country } from '../../models/common';
import { DateUtilService, DISPLAY_DATE_FORMAT } from '../../../../core/services/date-util.service';

const FILTER_CONSUMER_KEY = FilterConsumerKey.EVENTS;

@Component({
  selector: 'strm-event-overview',
  templateUrl: './event-overview.component.html',
  styleUrls: ['./event-overview.component.scss']
})
export class EventOverviewComponent implements OnInit, OnDestroy {
  public tableData: SecurityEventRecord[] = [];
  public isLoading: boolean;
  public currentPage: number;
  public numberOfPages: number;
  public totalRecords: number;
  public selection = new SelectionModel<SecurityEventRecord>(true, []);
  public selectedItems: SecurityEventRecord[] = [];

  private subscriptions: Subscription = new Subscription();
  private isLoadingTimeoutId: number;

  constructor(
    private apiSecurityEventService: ApiSecurityEventService,
    private router: Router,
    private filterService: FilterService
  ) {}

  private _startDateFilter: string | null;

  get startDateFilter(): string | null {
    return this._startDateFilter;
  }

  set startDateFilter(value: string | null) {
    this._startDateFilter = value;
    this.filterDates();
  }

  private _endDateFilter: string | null;

  get endDateFilter(): string | null {
    return this._endDateFilter;
  }

  set endDateFilter(value: string | null) {
    this._endDateFilter = value;
    this.filterDates();
  }

  private _dateFilter: DateFilterValue | null;

  get dateFilter(): DateFilterValue | null {
    return this._dateFilter;
  }

  set dateFilter(dateFilter: DateFilterValue | null) {
    this._dateFilter = dateFilter;
    this._startDateFilter = this.dateFilter?.startDate
      ? DateUtilService.formatDate(this.dateFilter?.startDate, DISPLAY_DATE_FORMAT)
      : null;
    this._endDateFilter = this.dateFilter?.endDate
      ? DateUtilService.formatDate(this.dateFilter?.endDate, DISPLAY_DATE_FORMAT)
      : null;
  }

  private _countryFilter: Country[] = [];

  private _sourceFilter: SourceFilter[] = [];

  get countryFilter(): Country[] {
    return this._countryFilter;
  }

  set countryFilter(countryFilter: Country[]) {
    this._countryFilter = countryFilter;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, this.dateFilter],
      [FilterKey.COUNTRY, countryFilter],
      [FilterKey.SOURCE, this.sourceFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  get sourceFilter(): SourceFilter[] {
    return this._sourceFilter;
  }

  set sourceFilter(sourceFilter: SourceFilter[]) {
    this._sourceFilter = sourceFilter;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, this.dateFilter],
      [FilterKey.COUNTRY, this.countryFilter],
      [FilterKey.SOURCE, sourceFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  public ngOnInit(): void {
    const sub = this.filterService.filterObservable
      .pipe(
        tap((filters) => this.assignFilters(filters.get(FILTER_CONSUMER_KEY))),
        tap(() => (this.currentPage = this.filterService.getPagination(FILTER_CONSUMER_KEY))),
        switchMap(() => this.getSecurityEventOverviewObservable())
      )
      .subscribe((securityEventsOverview) =>
        this.handleSecurityEventOverview(securityEventsOverview)
      );
    this.subscriptions.add(sub);
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public filterCountries(countries: Country[]): void {
    this.resetPagination();
    this.countryFilter = countries;
  }

  public filterSource(source: SourceFilter[]): void {
    this.resetPagination();
    this.sourceFilter = source;
  }

  public removeFilters(): void {
    this._startDateFilter = null;
    this._endDateFilter = null;
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, null],
      [FilterKey.COUNTRY, []],
      [FilterKey.SOURCE, []]
    ]);
    this.resetPagination();
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }

  public archiveSelectedEvents(selectedEvent: SecurityEventRecord[]): void {
    if (selectedEvent && selectedEvent.length > 0) {
      const ids = selectedEvent.map((event) => event.id);
      const sub = this.apiSecurityEventService.archiveAll(ids).subscribe((event) => {
        if (event) {
          const firstRowOffset = this.getFirstRowOffset(this.currentPage, 10);
          this.loadSecurityEvents({ first: firstRowOffset });
          this.selectedItems = this.selectedItems.filter(
            (item: SecurityEventRecord) => !ids.includes(item.id)
          );
        }
      });
      this.subscriptions.add(sub);
    }
  }

  public loadSecurityEvents(lazyLoadEvent: LazyLoadEvent): void {
    if (lazyLoadEvent?.rows) {
      this.currentPage = this.convertFirstRowOffsetToPageNumber(lazyLoadEvent.first, 10);
      this.filterService.setPagination(FILTER_CONSUMER_KEY, this.currentPage);
    }

    const subscription = this.getSecurityEventOverviewObservable().subscribe(
      (securityEventsOverview) => this.handleSecurityEventOverview(securityEventsOverview)
    );
    this.subscriptions.add(subscription);
  }

  public archiveEvent(removalItem: SecurityEventRecord): void {
    const subscription = this.apiSecurityEventService
      .archive(removalItem.id)
      .subscribe((securityEvent) => {
        if (securityEvent.status === 'DELETED') {
          const firstRowOffset = this.getFirstRowOffset(this.currentPage, 10);
          this.loadSecurityEvents({ first: firstRowOffset });
          this.selectedItems = this.selectedItems.filter(
            (securityEvent: SecurityEventRecord) => securityEvent.id !== removalItem.id
          );
        }
      });
    this.subscriptions.add(subscription);
  }

  public async createSecurityEvent(): Promise<void> {
    await this.router.navigate(['/dashboard/security-events', 'create']);
  }

  public async openSecurityEvent(id: string, index: number): Promise<void> {
    const lastDigit = index % 10;
    await this.router.navigate(['/dashboard/security-events', id], {
      queryParams: { page: this.currentPage, index: lastDigit }
    });
  }

  public getFirstRowOffset(page: number, rowsPerPage: number): number {
    return (page - 1) * rowsPerPage;
  }

  private handleSecurityEventOverview(securityEventOverview: SecurityEventOverview): void {
    this.assignResponse(securityEventOverview);
    clearTimeout(this.isLoadingTimeoutId);
    this.isLoading = false;
  }

  private getSecurityEventOverviewObservable(): Observable<SecurityEventOverview> {
    return this.apiSecurityEventService
      .getSecurityEventOverview(
        this.currentPage,
        this.dateFilter?.startDate,
        this.dateFilter?.endDate,
        this.countryFilter,
        this.sourceFilter
      )
      .pipe(
        tap(() => {
          // Delay the loading indicator to avoid flickering
          this.isLoadingTimeoutId = setTimeout(() => {
            this.isLoading = true;
          }, 400);
        })
      );
  }

  private resetPagination(): void {
    this.filterService.setPagination(FILTER_CONSUMER_KEY, 1);
    this.currentPage = this.filterService.getPagination(FILTER_CONSUMER_KEY);
  }

  private assignFilters(filters: Map<FilterKey, FilterValue>): void {
    this.dateFilter = filters?.get(FilterKey.DATE) as DateFilterValue;
    this._countryFilter = (filters?.get(FilterKey.COUNTRY) as Country[]) ?? [];
    this._sourceFilter = (filters?.get(FilterKey.SOURCE) as SourceFilter[]) ?? [];
  }

  private assignResponse(securityEventOverview: SecurityEventOverview): void {
    this.tableData = this.transformData(securityEventOverview.items);
    this.numberOfPages = securityEventOverview.totalPages;
    this.totalRecords = securityEventOverview.totalElements;
  }

  private convertFirstRowOffsetToPageNumber(firstRowOffset: number, rowsPerPage: number): number {
    return Math.floor(firstRowOffset / rowsPerPage) + 1;
  }

  private transformData(items: SecurityEventRecord[]): SecurityEventRecord[] {
    return items.map((item) => {
      return {
        ...item,
        description: this.removeHtmlTags(item.description)
      };
    });
  }

  private removeHtmlTags(text: string): string {
    return text.replace(/<\/?[^>]+(>|$)/g, '');
  }

  private filterDates(): void {
    this.resetPagination();
    const dateFilter = this.filterService.createDateFilter(
      this.startDateFilter,
      this.endDateFilter
    );
    const filters = new Map<FilterKey, FilterValue>([
      [FilterKey.DATE, dateFilter],
      [FilterKey.COUNTRY, this.countryFilter],
      [FilterKey.SOURCE, this.sourceFilter]
    ]);
    this.filterService.addFilters(FILTER_CONSUMER_KEY, filters);
  }
}
