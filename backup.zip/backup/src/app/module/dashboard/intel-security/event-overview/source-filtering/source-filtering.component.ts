import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';
import { SourceFilter } from '../../../models/security-event-overview';
import { SecurityEventService } from '../../../services/security-event.service';

@Component({
  selector: 'strm-source-filtering',
  templateUrl: './source-filtering.component.html',
  styleUrls: ['./source-filtering.component.scss']
})
export class SourceFilteringComponent implements OnInit, OnChanges {
  @Input() sourceFilter: SourceFilter[] = [];
  @Output() sourceEmit = new EventEmitter<SourceFilter[]>();
  public sources: SourceFilter[];
  public selectedSource!: SourceFilter[];
  private sourceListObservable: Observable<SourceFilter[]>;

  constructor(securityEventService: SecurityEventService) {
    this.sourceListObservable = securityEventService.sourceListObservable;
  }

  public async ngOnInit(): Promise<void> {
    this.sources = await firstValueFrom(this.sourceListObservable);
  }

  public ngOnChanges(): void {
    this.selectedSource = this.sourceFilter;
  }

  public emitChanges(): void {
    this.sourceEmit.emit(this.selectedSource);
  }

  public clearAll(): void {
    this.sourceEmit.emit(null);
  }
}
