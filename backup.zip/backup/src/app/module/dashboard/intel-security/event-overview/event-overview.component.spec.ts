import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EventOverviewComponent } from './event-overview.component';
import { ApiSecurityEventService } from '../../services/api-security-event.service';
import { of } from 'rxjs';
import { SecurityEventOverview, SourceFilter } from '../../models/security-event-overview';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  FilterValue
} from '../../services/filter.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Country } from '../../models/common';

describe('EventOverviewComponent', () => {
  let component: EventOverviewComponent;
  let fixture: ComponentFixture<EventOverviewComponent>;
  let mockApiSecurityEventService: jasmine.SpyObj<ApiSecurityEventService>;
  const mockSecurityEventOverview: SecurityEventOverview = {
    items: [
      {
        id: '41721d4e-b671-4743-8b4b-4f96569d7fb6',
        eventSourceId: '41721d4e-b671-4743-8b4b-4f96569d7fb6',
        modifiedDate: '2023-12-29T00:00:00',
        description:
          'At Al-Nuseirat refugee camp, the Gaza Strip, an Israeli strike killed at least 20 people. ',
        countryName: 'Palestinian Territories',
        status: 'CREATED',
        source: 'CONTROL_RISK',
        modified: true
      },
      {
        id: 'f26d9505-290c-4be5-addb-e1b8139ca417',
        eventSourceId: 'f26d9505-290c-4be5-addb-e1b8139ca417',
        modifiedDate: '2023-12-29T00:00:00',
        description:
          'At Balata refugee camp, the West Bank, fighting between Palestinians and raiding Israeli forces was reported. ',
        countryName: 'Palestinian Territories',
        status: 'CREATED',
        source: 'CONTROL_RISK',
        modified: true
      }
    ],
    totalPages: 1,
    totalElements: 2,
    size: 10
  };
  const FILTER_CONSUMER_KEY = FilterConsumerKey.EVENTS;
  const mockFilters: Map<FilterConsumerKey, Map<FilterKey, FilterValue>> = new Map();
  mockFilters.set(FILTER_CONSUMER_KEY, new Map());
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.DATE, null);
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.COUNTRY, []);
  mockFilters.get(FILTER_CONSUMER_KEY).set(FilterKey.SOURCE, []);
  let mockFilterService: jasmine.SpyObj<FilterService>;

  beforeEach(async () => {
    mockApiSecurityEventService = jasmine.createSpyObj('ApiSecurityEventService', [
      'getSecurityEventOverview'
    ]);
    mockApiSecurityEventService.getSecurityEventOverview.and.returnValue(
      of(mockSecurityEventOverview)
    );
    mockFilterService = jasmine.createSpyObj('FilterService', [
      'setPagination',
      'getPagination',
      'addFilters',
      'filterObservable',
      'createDateFilter'
    ]);
    mockFilterService.getPagination.and.returnValue(1);
    mockFilterService.filterObservable = of(mockFilters);

    await TestBed.configureTestingModule({
      providers: [
        {
          provide: ApiSecurityEventService,
          useValue: mockApiSecurityEventService
        },
        {
          provide: FilterService,
          useValue: mockFilterService
        }
      ],
      imports: [HttpClientTestingModule],
      declarations: [EventOverviewComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(EventOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load pagination on init', () => {
    expect(mockFilterService.getPagination).toHaveBeenCalledOnceWith(FILTER_CONSUMER_KEY);
  });

  describe('filters', () => {
    it('should load on init', () => {
      expect(component.dateFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.DATE) as DateFilterValue
      );
      expect(component.countryFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.COUNTRY) as Country[]
      );
      expect(component.sourceFilter).toEqual(
        mockFilters.get(FILTER_CONSUMER_KEY).get(FilterKey.SOURCE) as SourceFilter[]
      );
    });

    it('change of date should reset pagination', () => {
      component.loadSecurityEvents({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.startDateFilter = '2023-12-24T18;00;00';
      expect(component.currentPage).toBe(1);
    });

    it('change of countries should reset pagination', () => {
      component.loadSecurityEvents({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.filterCountries([{ code: 'NL', name: 'Netherlands' }]);
      expect(component.currentPage).toBe(1);
    });

    it('reset should reset pagination and filters', () => {
      component.loadSecurityEvents({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);

      component.startDateFilter = '01-03-2024';
      component.endDateFilter = '04-03-2024';

      component.removeFilters();
      expect(component.currentPage).toBe(1);
      expect(component.startDateFilter).toBeNull();
      expect(component.endDateFilter).toBeNull();
      expect(component.dateFilter).toBeNull();
      expect(component.countryFilter).toEqual([]);
    });
  });

  it('should load events on init', () => {
    expect(mockApiSecurityEventService.getSecurityEventOverview).toHaveBeenCalledOnceWith(
      1,
      undefined,
      undefined,
      [],
      []
    );
    expect(component.totalRecords).toEqual(mockSecurityEventOverview.items.length);
    expect(component.numberOfPages).toEqual(mockSecurityEventOverview.totalPages);
    expect(component.tableData.length).toEqual(mockSecurityEventOverview.items.length);
  });

  describe('loadSecurityEvents', () => {
    it('should set pagination if lazyLoadEvent.rows is provided', () => {
      component.loadSecurityEvents({ first: 20, rows: 10 });
      expect(component.currentPage).toBe(3);
    });
  });
});
