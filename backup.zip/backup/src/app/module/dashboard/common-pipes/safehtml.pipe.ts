import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'safeHtml'
})
export class SafehtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string): SafeHtml {
    const newValue = this.inlineStyleRemover(value);
    return this.sanitizer.bypassSecurityTrustHtml(newValue);
  }

  inlineStyleRemover(value: string): string {
    return value.replace(/ style="[^"]*"/g, '');
  }
}
