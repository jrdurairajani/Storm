import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'charremoval'
})
export class CharRemoval implements PipeTransform {
  transform(value: string) {
    const pipeRegex = /\|/g;
    const underscoreRegex1 = /_/g;
    if (value == null) {
      return '';
    } else if (value.includes('_')) {
      return value.replace(underscoreRegex1, ' ');
    } else {
      return value.replace(pipeRegex, ', ');
    }
  }
}
