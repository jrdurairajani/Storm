import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'DateSeparated'
})
export class DateSeparatedPipe implements PipeTransform {
  transform(date: string, time: string = null): string {
    if (!date) return '';

    const datetime = time ? `${date}T${time}` : date;

    const format = time ? 'DD-MM-yyyy HH:mm' : 'DD-MM-yyyy';

    return moment.utc(datetime).format(format);
  }
}
