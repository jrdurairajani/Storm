import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipe2comma'
})
export class Pipe2Comma implements PipeTransform {
  transform(value: string) {
    const regex = /\|/g;
    if (value == null) {
      return '';
    } else {
      return value.replace(regex, ', ');
    }
  }
}
