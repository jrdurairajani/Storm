import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'splitword'
})
export class SplitWord implements PipeTransform {
  transform(value: string) {
    if (value == 'Assettypes') {
      value = 'Asset types';
    } else if (value == 'Attacktype') {
      value = 'Attack type';
    } else if (value == 'Secondarycountries') {
      value = 'Secondary countries';
    }
    return value;
  }
}
