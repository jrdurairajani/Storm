import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'hyphen'
})
export class HyphenPipe implements PipeTransform {
  transform(value: string) {
    return value.replace(/-/g, ' ');
  }
}
