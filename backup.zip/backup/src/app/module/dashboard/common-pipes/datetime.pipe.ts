import { Pipe, PipeTransform } from '@angular/core';
import { DateUtilService } from '../../../core/services/date-util.service';

@Pipe({
  name: 'DateFormat'
})
export class DatePipe implements PipeTransform {
  transform(value: string): string {
    if (!value) return '';

    const hasTime = value.includes('T');

    const format = hasTime ? 'dd-MM-yyyy HH:mm' : 'DD-MM-yyyy';

    return DateUtilService.formatDate(value, format);
  }
}
