import { TestBed } from '@angular/core/testing';
import {
  DateFilterValue,
  FilterConsumerKey,
  FilterKey,
  FilterService,
  KfssbFilterValue
} from './filter.service';
import { firstValueFrom } from 'rxjs';
import { Country } from '../models/common';

function isDateFilterValue(obj: unknown): obj is DateFilterValue {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'startDate' in obj &&
    'endDate' in obj &&
    typeof obj['startDate'] === 'string' &&
    typeof obj['endDate'] === 'string'
  );
}

describe('FilterService', () => {
  let filterService: FilterService;
  const MOCK_FILTER_CONSUMER_KEY = FilterConsumerKey.THREATS;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [FilterService]
    });
    filterService = TestBed.inject(FilterService);
  });

  it('should be created', () => {
    expect(filterService).toBeTruthy();
  });

  describe('createDateFilter', () => {
    it('should return a DateFilterValue', () => {
      const mockStartDate = '01-01-2024';
      const mockEndDate = '02-01-2024';
      const dateFilter = filterService.createDateFilter(mockStartDate, mockEndDate);
      expect(isDateFilterValue(dateFilter)).toBe(true);
    });
  });

  it('should add date filter', async () => {
    const mockStartDate = '01-01-2024';
    const mockEndDate = '02-02-2024';
    const dateFilter = filterService.createDateFilter(mockStartDate, mockEndDate);
    filterService.addFilters(MOCK_FILTER_CONSUMER_KEY, new Map([[FilterKey.DATE, dateFilter]]));
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.DATE)
    ).toEqual(dateFilter);
  });

  it('should clear date filter', async () => {
    filterService.addFilters(MOCK_FILTER_CONSUMER_KEY, new Map([[FilterKey.DATE, null]]));
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.DATE)
    ).toBeNull();
  });

  it('should add country filter', async () => {
    const countryFilter: Country[] = [{ code: 'HU', name: 'Hungary' }];
    filterService.addFilters(
      MOCK_FILTER_CONSUMER_KEY,
      new Map([[FilterKey.COUNTRY, countryFilter]])
    );
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.COUNTRY)
    ).toEqual(countryFilter);
  });

  it('should clear country filter', async () => {
    filterService.addFilters(MOCK_FILTER_CONSUMER_KEY, new Map([[FilterKey.COUNTRY, []]]));
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.COUNTRY)
    ).toEqual([]);
  });

  it('should add kfssb filter', async () => {
    const kfssbFilter: KfssbFilterValue = 'relevant';
    filterService.addFilters(MOCK_FILTER_CONSUMER_KEY, new Map([[FilterKey.KFSSB, kfssbFilter]]));
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.KFSSB)
    ).toEqual(kfssbFilter);
  });

  it('should clear kfssb filter', async () => {
    filterService.addFilters(MOCK_FILTER_CONSUMER_KEY, new Map([[FilterKey.KFSSB, null]]));
    expect(
      (await firstValueFrom(filterService.filterObservable))
        .get(MOCK_FILTER_CONSUMER_KEY)
        .get(FilterKey.KFSSB)
    ).toBeNull();
  });

  it('should set pagination', () => {
    const mockPageNumber = 2;
    filterService.setPagination(MOCK_FILTER_CONSUMER_KEY, mockPageNumber);
    expect(filterService.getPagination(MOCK_FILTER_CONSUMER_KEY)).toBe(mockPageNumber);
  });
});
