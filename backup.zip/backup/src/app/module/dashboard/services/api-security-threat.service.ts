import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom, lastValueFrom, Observable } from 'rxjs';
import {
  Continent,
  ElementWithCodeAndName,
  MediaFile,
  NextSecurityThreat,
  SecurityRegion,
  SecurityThreat
} from '../models/security-threat';
import { SecurityThreatOverview } from '../models/security-threat-overview';
import { map } from 'rxjs/operators';
import { AirportDetails } from '../models/airport-details';
import { Country } from '../models/common';
import { CityCountries } from '../models/involved-countries';

@Injectable({
  providedIn: 'root'
})
export class ApiSecurityThreatService {
  constructor(private http: HttpClient) {}

  public saveSecurityThreat(threat: SecurityThreat, files: File[]): Observable<SecurityThreat> {
    const url = 'api/securitythreats';
    const formData: FormData = new FormData();
    formData.append(
      'threat',
      new Blob([JSON.stringify(threat)], {
        type: 'application/json'
      })
    );
    files.forEach((file) => {
      formData.append('attachments', file, file.name);
    });

    return this.http.post<SecurityThreat>(url, formData);
  }

  public editSecurityThreat(
    id: string,
    threat: SecurityThreat,
    files: File[]
  ): Observable<SecurityThreat> {
    const url = `api/securitythreats/${id}`;

    const formData: FormData = new FormData();
    formData.append(
      'threat',
      new Blob([JSON.stringify(threat)], {
        type: 'application/json'
      })
    );
    files.forEach((file) => {
      formData.append('attachments', file, file.name);
    });

    return this.http.put<SecurityThreat>(url, formData);
  }

  public getSecurityThreatOverview(
    page: number,
    startDate?: string,
    endDate?: string,
    countries?: Country[],
    kfssb?: string,
    statusFilter?: string
  ): Observable<SecurityThreatOverview> {
    const url = `api/securitythreats?page=${page}&size=10&sort=desc`;
    const params = this.setHttpParams(startDate, endDate, countries, kfssb, statusFilter);
    return this.http.get<SecurityThreatOverview>(url, { params: params });
  }

  public getNextThreatNavigation(
    page: number,
    cIndex: number,
    startDate?: string,
    endDate?: string,
    countries?: Country[],
    kfssb?: string,
    statusFilter?: string
  ): Observable<NextSecurityThreat> {
    const url = `api/securitythreats/nextThreatId?pageNum=${page}&recIndex=${cIndex}`;
    const params = this.setHttpParams(startDate, endDate, countries, kfssb, statusFilter);
    return this.http.get<NextSecurityThreat>(url, { params: params });
  }

  public archive(id: string): Observable<SecurityThreat> {
    const url = `api/securitythreats/${id}`;
    return this.http.delete<SecurityThreat>(url);
  }

  public getCountryList(): Observable<Country[]> {
    const url = 'api/gat-countries/filter-list';
    return this.http.get<Country[]>(url);
  }

  public getSecurityThreat(id: string): Observable<SecurityThreat> {
    const url = `api/securitythreats/${id}`;
    return this.http.get<SecurityThreat>(url).pipe(
      map((threat) => ({
        ...threat,
        mediaFiles: threat.mediaFiles.map(
          (media) => new MediaFile(media.id, media.name, media.size)
        )
      }))
    );
  }

  public getSecurityThreatContinent(): Promise<Continent[]> {
    const url = '/api/continents';
    const observable = this.http.get<Continent[]>(url);
    return firstValueFrom(observable);
  }

  public getSecurityRegion(): Promise<SecurityRegion[]> {
    const url = '/api/securityRegions';
    const observable = this.http.get<SecurityRegion[]>(url);
    return firstValueFrom(observable);
  }

  public getCategoryListing(): Observable<string[]> {
    const url = `/api/securityevents/eventcategories`;
    return this.http.get<string[]>(url);
  }

  public getSecurityThreatLocations(
    continent: string,
    country: string,
    state: string,
    city: string
  ): Promise<ElementWithCodeAndName[]> {
    let url;
    if (continent && country && state && city) {
      url = `api/locations?continent=${continent}&country=${country}&state=${state}&city=${city}`;
    } else if (continent && country && state) {
      url = `api/locations?continent=${continent}&country=${country}&state=${state}`;
    } else if (continent && country) {
      url = `api/locations?continent=${continent}&country=${country}`;
    } else if (continent) {
      url = `api/locations?continent=${continent}`;
    }
    const observable = this.http.get<ElementWithCodeAndName[]>(url);
    return firstValueFrom(observable);
  }

  public getAirports(): Observable<AirportDetails[]> {
    const url = `/api/locations/airports`;
    return this.http.get<AirportDetails[]>(url);
  }

  public getInvolvedCountries(): Observable<CityCountries[]> {
    const url = `/api/overpass-countries/list`;
    return this.http.get<CityCountries[]>(url);
  }

  // TODO: refactor this into an http service layer
  private setHttpParams(
    startDate,
    endDate,
    countries: Country[],
    kfssb: string,
    statusFilter: string
  ) {
    let params = new HttpParams();
    if (startDate) {
      params = params.set('startDate', encodeURIComponent(startDate));
    }
    if (endDate) {
      params = params.set('endDate', encodeURIComponent(endDate));
    }
    if (countries.length > 0) {
      const codes = countries.map((el) => el.code);
      params = params.append('country', codes.join(','));
    }
    if (kfssb) {
      params = params.append('kfssb', kfssb);
    }
    if (statusFilter) {
      params = params.append('statusFilter', statusFilter);
    }
    return params;
  }
}
