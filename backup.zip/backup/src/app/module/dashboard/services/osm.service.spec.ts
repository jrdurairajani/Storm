import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Bound, POI } from '../models/map';
import { SecurityThreatLocation } from '../models/security-threat';
import { OpenStreetMapService } from './osm.service';

describe('OpenStreetMapService', () => {
  let service: OpenStreetMapService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [OpenStreetMapService]
    });
    service = TestBed.inject(OpenStreetMapService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  describe('handleLocationUpdate', () => {
    const currentPoi: POI = {
      markers: [
        {
          coordinates: { lat: 10, lng: 20 },
          type: 'primary'
        }
      ],
      polygons: [],
      bounds: []
    };

    it('should call clearPrimaryObjects when no marker or bounds are present', () => {
      const location: SecurityThreatLocation = {
        osmId: 123456,
        osmType: 'node',
        primaryLocation: 'Test Location',
        airportCode: 'TST',
        involvedCountries: ['Testland'],
        country: 'Testland',
        bounds: null,
        marker: null
      };
      const clearSpy = spyOn<any>(service, 'clearPrimaryObjects').and.callThrough();

      service.handleLocationUpdate(location, currentPoi);

      expect(clearSpy).toHaveBeenCalledWith(currentPoi);
    });

    it('should call updateBounds when bounds are present', () => {
      const exampleBound: Bound = {
        coordinates: [
          [
            { lat: 40.73061, lng: -73.935242 },
            { lat: 40.73161, lng: -73.935242 },
            { lat: 40.73161, lng: -73.934242 },
            { lat: 40.73061, lng: -73.934242 }
          ]
        ],
        type: 'primary'
      };

      const location: SecurityThreatLocation = {
        osmId: 123456,
        osmType: 'node',
        primaryLocation: 'Test Location',
        airportCode: 'TST',
        involvedCountries: ['Testland'],
        country: 'Testland',
        bounds: exampleBound,
        marker: null
      };

      const boundsSpy = spyOn<any>(service, 'updateBounds').and.callThrough();

      service.handleLocationUpdate(location, currentPoi);

      expect(boundsSpy).toHaveBeenCalledWith(location, currentPoi);
    });

    it('should call updateMarker when marker is present', () => {
      const location: SecurityThreatLocation = {
        osmId: 123456,
        osmType: 'node',
        primaryLocation: 'Test Location',
        airportCode: 'TST',
        involvedCountries: ['Testland'],
        country: 'Testland',
        bounds: null,
        marker: {
          coordinates: { lat: 10, lng: 20 },
          type: 'primary'
        }
      };

      const markerSpy = spyOn<any>(service, 'updateMarker').and.callThrough();

      service.handleLocationUpdate(location, currentPoi);

      expect(markerSpy).toHaveBeenCalledWith(location, currentPoi);
    });
  });

  describe('OpenStreetMapService getMarker', () => {
    it('should return the primary marker when present', () => {
      const poi: POI = {
        markers: [
          { coordinates: { lat: 10, lng: 20 }, type: 'regular' },
          { coordinates: { lat: 30, lng: 40 }, type: 'primary' }
        ],
        polygons: [],
        bounds: []
      };

      const marker = service.getMarker(poi);
      expect(marker).not.toBeNull();
      expect(marker.type).toBe('primary');
      expect(marker.coordinates.lat).toBe(30);
      expect(marker.coordinates.lng).toBe(40);
    });

    it('should return null when no primary marker is present', () => {
      const poi: POI = {
        markers: [
          { coordinates: { lat: 10, lng: 20 }, type: 'regular' },
          { coordinates: { lat: 30, lng: 40 }, type: 'regular' }
        ],
        polygons: [],
        bounds: []
      };

      const marker = service.getMarker(poi);
      expect(marker).toBeNull();
    });
  });

  describe('getBounds', () => {
    it('should return the primary bound when present', () => {
      const poi: POI = {
        markers: [],
        polygons: [],
        bounds: [
          {
            coordinates: [
              [
                { lat: 10, lng: 20 },
                { lat: 30, lng: 40 }
              ]
            ],
            type: 'primary'
          }
        ]
      };

      const bound = service.getBounds(poi);
      expect(bound).not.toBeNull();
      expect(bound.type).toBe('primary');
      expect(bound.coordinates.length).toBeGreaterThan(0);
    });

    it('should return null when no primary bound is present', () => {
      const poi: POI = {
        markers: [],
        polygons: [],
        bounds: [
          {
            coordinates: [
              [
                { lat: 50, lng: 60 },
                { lat: 70, lng: 80 }
              ]
            ],
            type: 'regular'
          }
        ]
      };

      const bound = service.getBounds(poi);
      expect(bound).toBeNull();
    });
  });

  it('should retrieve data for "New York"', () => {
    const expectedPlaceId = 370931646;
    const expectedLat = '40.7127281';
    const expectedLon = '-74.0060152';
    const expectedName = 'New York';

    service.search('New York').subscribe((data) => {
      expect(data.length).toBe(1);
      expect(data[0].place_id).toBe(expectedPlaceId);
      expect(data[0].lat).toBe(expectedLat);
      expect(data[0].lon).toBe(expectedLon);
      expect(data[0].name).toBe(expectedName);
    });

    const req = httpTestingController.expectOne(
      'https://nominatim.openstreetmap.org/search?q=New+York&format=json&addressdetails=1&accept-language=en&polygon_geojson=1'
    );
    expect(req.request.method).toBe('GET');
    req.flush([
      {
        place_id: expectedPlaceId,
        lat: expectedLat,
        lon: expectedLon,
        name: expectedName
      }
    ]);
  });
});
