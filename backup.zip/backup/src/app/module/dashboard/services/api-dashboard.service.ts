import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PagedResponse, SecurityDashboard } from '../models/common';
import { DocumentFile } from '../models/documents';

@Injectable({
  providedIn: 'root'
})
export class ApiDashboardService {
  constructor(private http: HttpClient) {}

  public sendFile(reqBody: FormData): Observable<DocumentFile> {
    const url = '/api/dashboard/usermanual/attachment';
    return this.http.post<DocumentFile>(url, reqBody);
  }

  public removeFile(id: string): Observable<void> {
    const url = `api/dashboard/usermanual/${id}`;
    return this.http.delete<void>(url);
  }

  public getFiles(): Observable<PagedResponse<DocumentFile>> {
    const url = '/api/dashboard/usermanual/documents';
    return this.http.get<PagedResponse<DocumentFile>>(url);
  }

  public controlRiskNotification(): Observable<SecurityDashboard> {
    const url = '/api/dashboard/count';
    return this.http.get<SecurityDashboard>(url);
  }

  public downloadFile(id: string): Observable<any> {
    const url = `/api/dashboard/downloads/usermanual/${id}`;
    return this.http.get(url, { responseType: 'blob', observe: 'response' });
  }

  public downloadManual(): Observable<any> {
    const url = '/api/dashboard/downloads/usermanual/download';
    return this.http.get(url, { responseType: 'blob', observe: 'response' }).pipe(
      map((res) => {
        const text = res.headers.get('content-disposition').split(';');
        const fileName = text[1].split('"')[1];
        let dateUpload = text[2].split('=')[1];
        dateUpload = dateUpload.slice(0, -1);
        return { body: res.body, fileName, dateUpload, type: res.headers.get('content-type') };
      })
    );
  }
}
