import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Country } from '../models/common';
import { DateUtilService } from '../../../core/services/date-util.service';
import { SourceFilter } from '../models/security-event-overview';

export enum FilterConsumerKey {
  EVENTS = 'events',
  THREATS = 'threats',
  ADMIN_FLIGHT_REPORT = 'admin_flight_report',
  SECURITY_EMPLOYEE_FLIGHT_REPORT = 'security_employee_flight_report'
}

export type FilterValue = KfssbFilterValue | DateFilterValue | Country[] | SourceFilter[];

export enum FilterKey {
  DATE = 'date',
  COUNTRY = 'country',
  KFSSB = 'kfssb',
  SOURCE = 'source'
}

export interface DateFilterValue {
  startDate: string;
  endDate: string;
}

export type KfssbFilterValue = 'relevant' | 'notRelevant' | null;

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  private filterSubject: BehaviorSubject<Map<FilterConsumerKey, Map<FilterKey, FilterValue>>> =
    new BehaviorSubject<Map<FilterConsumerKey, Map<FilterKey, FilterValue>>>(new Map());
  public filterObservable = this.filterSubject.asObservable();

  private paginationCache: Map<string, number> = new Map();

  public addFilters(key: FilterConsumerKey, filters: Map<FilterKey, FilterValue>): void {
    const currentMap = this.filterSubject.getValue();
    currentMap.set(key, filters);
    this.filterSubject.next(currentMap);
  }

  public setPagination(key: FilterConsumerKey, value: number): void {
    this.paginationCache.set(key, value);
  }

  public getPagination(key: FilterConsumerKey): number {
    const result = this.paginationCache.get(key);
    if (result) return result;
    else return 1;
  }

  public createDateFilter(
    startDateFilter: string | null,
    endDateFilter: string | null
  ): DateFilterValue {
    return {
      startDate: DateUtilService.formatDate(startDateFilter),
      endDate: DateUtilService.formatDate(endDateFilter)
    };
  }
}
