import { TestBed } from '@angular/core/testing';

import { SecurityThreatService } from './security-threat.service';
import { ApiSecurityThreatService } from './api-security-threat.service';
import { firstValueFrom, of } from 'rxjs';
import { Country } from '../models/security-threat';

describe('SecurityThreatService', () => {
  let securityThreatService: SecurityThreatService;
  let mockApiSecurityThreat: jasmine.SpyObj<ApiSecurityThreatService>;
  let mockCountries: Country[];

  beforeEach(() => {
    mockApiSecurityThreat = jasmine.createSpyObj('ApiSecurityThreat', ['getCountryList']);
    mockCountries = [
      { name: 'Hungary', code: 'HU' },
      { name: 'Netherlands', code: 'NL' }
    ];
    const countriesObservable = of(mockCountries);
    mockApiSecurityThreat.getCountryList.and.returnValue(countriesObservable);

    TestBed.configureTestingModule({
      providers: [
        SecurityThreatService,
        { provide: ApiSecurityThreatService, useValue: mockApiSecurityThreat }
      ]
    });

    securityThreatService = TestBed.inject(SecurityThreatService);
  });

  it('should be created', () => {
    expect(securityThreatService).toBeTruthy();
  });

  // TODO: check if 'fakeAsync' from @angular/core/testing or 'done' is a better option
  it('should load countries', async () => {
    expect(await firstValueFrom(securityThreatService.countryListObservable)).toBe(mockCountries);
  });

  // TODO: Test for HttpClient if results are cached
});
