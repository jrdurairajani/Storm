import { Injectable } from '@angular/core';
import { ApiSecurityThreatService } from './api-security-threat.service';
import { shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Country } from '../models/security-threat';

@Injectable({
  providedIn: 'root'
})
export class SecurityThreatService {
  public countryListObservable: Observable<Country[]> = this.apiSecurityThreat
    .getCountryList()
    .pipe(shareReplay(1));

  constructor(private apiSecurityThreat: ApiSecurityThreatService) {}
}
