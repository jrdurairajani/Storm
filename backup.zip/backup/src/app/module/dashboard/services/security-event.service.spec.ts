import { TestBed } from '@angular/core/testing';
import { SecurityEventService } from './security-event.service';
import { ApiSecurityThreatService } from './api-security-threat.service';
import { firstValueFrom, of } from 'rxjs';
import { Country } from '../models/security-threat';
import { ApiSecurityEventService } from './api-security-event.service';
import { SourceFilter } from '../models/security-event-overview';

describe('SecurityEventService', () => {
  let securityEventService: SecurityEventService;
  let mockApiSecurityThreat: jasmine.SpyObj<ApiSecurityThreatService>;
  let mockApiSecurityEvent: jasmine.SpyObj<ApiSecurityEventService>;
  let mockCountries: Country[];
  let mockSources: SourceFilter[];

  beforeEach(() => {
    mockApiSecurityThreat = jasmine.createSpyObj('ApiSecurityThreat', ['getCountryList']);
    mockApiSecurityEvent = jasmine.createSpyObj('ApiSecurityEvent', ['getSourceFilter']);
    mockCountries = [
      { name: 'Hungary', code: 'HU' },
      { name: 'Netherlands', code: 'NL' }
    ];
    mockSources = [
      {
        id: '72cc38bb-8839-43be-9a46-d976456e0832',
        code: 'SEERIST',
        name: 'Seerist'
      },
      {
        id: '1d593406-eeff-4e98-8eb8-581c140a0e01',
        code: 'CONTROL_RISK',
        name: 'ControlRisk'
      },
      {
        id: '39a3719f-63bb-48c4-a7f6-886ad5a0e2b5',
        code: 'MEDAIRE',
        name: 'Medaire'
      },
      {
        id: 'df487d52-c8ec-4be8-85d8-f8b3c26f4c6c',
        code: 'OSINT',
        name: 'Osint'
      }
    ];
    const countriesObservable = of(mockCountries);
    const sourceObservable = of(mockSources);
    mockApiSecurityThreat.getCountryList.and.returnValue(countriesObservable);
    mockApiSecurityEvent.getSourceFilter.and.returnValue(sourceObservable);

    TestBed.configureTestingModule({
      providers: [
        SecurityEventService,
        { provide: ApiSecurityThreatService, useValue: mockApiSecurityThreat },
        { provide: ApiSecurityEventService, useValue: mockApiSecurityEvent }
      ]
    });

    securityEventService = TestBed.inject(SecurityEventService);
  });

  it('should be created', () => {
    expect(securityEventService).toBeTruthy();
  });

  it('should load countries', async () => {
    expect(await firstValueFrom(securityEventService.countryListObservable)).toBe(mockCountries);
  });

  it('should load sources', async () => {
    expect(await firstValueFrom(securityEventService.sourceListObservable)).toBe(mockSources);
  });

  // TODO: Test for HttpClient if results are cached
});
