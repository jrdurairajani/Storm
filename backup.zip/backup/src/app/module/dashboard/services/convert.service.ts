import { Injectable } from '@angular/core';
import {
  AddSource,
  ApiData,
  Details,
  SecurityThreat,
  SecurityThreatHeader,
  SecurityThreatLocation,
  SecurityThreatSummary
} from '../models/security-threat';
import { SecurityEvent } from '../models/security-event';
import { POI } from '../models/map';

@Injectable({
  providedIn: 'root'
})
export class ConvertService {
  public convert(securityEvent: SecurityEvent, eventID: string): SecurityThreat {
    return this.mapEventDataToThreat(securityEvent, eventID);
  }

  private mapHeader(data: SecurityEvent): SecurityThreatHeader {
    return {
      continent: this.cleanData(data.region.continent.code),
      countryCode: this.cleanData(data.region.country.code),
      countryName: this.cleanData(data.region.country.name),
      city: this.cleanData(data.region.city),
      state: this.cleanData(data.region.state),
      station: this.cleanData(data.region.station),
      location: this.cleanData(data.region.location),
      provider: this.cleanData(data.region.regionNameProvider),
      region: this.cleanData(data.region.securityRegion)
    };
  }

  private mapLocation(data: SecurityEvent): SecurityThreatLocation {
    // TODO: Need to replace this location hardcode with implementing security event
    return {
      osmType: 'w',
      osmId: 2365455,
      primaryLocation: 'Middle East and North Africa Union',
      airportCode: 'AMS',
      involvedCountries: ['PL', 'IT'],
      country: 'Netherlands',
      marker: {
        coordinates: {
          lat: 22,
          lng: 23
        },
        type: 'regular'
      },
      bounds: null
    };
  }

  private mapSummary(data: SecurityEvent): SecurityThreatSummary {
    const eventDate = data.summary.eventDate.split('T')[0];
    return {
      eventReceivedDate: eventDate,
      eventReceivedTime: null,
      description: data.summary.description,
      title: data.summary.description,
      relevantForKfssb: false,
      threatStartDate: null,
      threatStartTime: null,
      threatEndDate: null,
      threatEndTime: null
    };
  }

  private mapPoi(data: SecurityEvent): POI {
    return {
      markers: [
        {
          coordinates: {
            lat: data.region.latitude,
            lng: data.region.longitude
          },
          type: 'regular'
        }
      ]
    };
  }

  private mapDetails(data: SecurityEvent): Details {
    const apiData: ApiData = {
      category: data.report.category,
      attackType: data.report.attackType,
      assetTypes: data.report.assetTypes,
      perpetrators: data.report.perpetrators,
      sector: data.report.sector,
      station: data.report.station,
      primaryAsset: data.report.primaryAsset,
      secondaryCountries: data.report.secondaryCountries,
      perpetratorFreeText: data.report.perpetratorFreeText
    };
    return {
      category: null,
      apiData
    };
  }

  private mapSource(url: string): AddSource[] {
    return [
      {
        name: 'Control Risk',
        link: url,
        disabled: true
      }
    ];
  }

  private mapEventDataToThreat(data: SecurityEvent, eventID): SecurityThreat {
    const threatLocation: SecurityThreatLocation = this.mapLocation(data);
    const summary: SecurityThreatSummary = this.mapSummary(data);
    const poi: POI = this.mapPoi(data);
    const details: Details = this.mapDetails(data);
    const source: AddSource[] = this.mapSource(window.location.href);

    return {
      summary,
      location: threatLocation,
      source,
      details,
      poi,
      threatImpact: null,
      incidentThreatLevel: null,
      mediaFiles: [],
      eventToThreatConversionID: eventID
    };
  }

  private cleanData(value): string {
    if (value === '' || value === '-' || !value) {
      return null;
    } else {
      return value;
    }
  }
}
