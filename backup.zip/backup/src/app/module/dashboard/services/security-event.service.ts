import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Country } from '../models/security-threat';
import { shareReplay } from 'rxjs/operators';
import { ApiSecurityThreatService } from './api-security-threat.service';
import { SourceFilter } from '../models/security-event-overview';
import { ApiSecurityEventService } from './api-security-event.service';

@Injectable({
  providedIn: 'root'
})
export class SecurityEventService {
  public countryListObservable: Observable<Country[]> = this.apiSecurityThreat
    .getCountryList()
    .pipe(shareReplay(1));

  public sourceListObservable: Observable<SourceFilter[]> = this.apiSecurityEvent
    .getSourceFilter()
    .pipe(shareReplay(1));

  constructor(
    private apiSecurityThreat: ApiSecurityThreatService,
    private apiSecurityEvent: ApiSecurityEventService
  ) {}
}
