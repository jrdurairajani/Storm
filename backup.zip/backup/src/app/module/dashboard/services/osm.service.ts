import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Bound, Marker, POI } from '../models/map';
import { IMapService, OpenStreetMapSearchResult } from '../models/open-street-map';
import { SecurityThreatLocation } from '../models/security-threat';

@Injectable({
  providedIn: 'root'
})
export class OpenStreetMapService implements IMapService {
  private baseUrl = 'https://nominatim.openstreetmap.org/search';

  constructor(private http: HttpClient) {}

  public handleLocationUpdate(location: SecurityThreatLocation, currentPoi: POI): POI {
    if (!location?.marker && !location?.bounds) {
      return this.clearPrimaryObjects(currentPoi);
    }

    if (location?.bounds) {
      return this.updateBounds(location, currentPoi);
    }

    if (location?.marker) {
      return this.updateMarker(location, currentPoi);
    }

    return currentPoi;
  }

  public getMarker(poi: POI): Marker {
    const marker: Marker = poi.markers.find((el) => el.type === 'primary');
    if (marker) {
      return marker;
    } else return null;
  }

  public getBounds(poi: POI): Bound {
    const bound: Bound = poi.bounds.find((el) => el.type === 'primary');
    if (bound) {
      return bound;
    } else return null;
  }

  private updateBounds(location: SecurityThreatLocation, poiInput: POI): POI {
    if (!this.areBoundsInAList(poiInput, location)) {
      poiInput = this.clearPrimaryObjects(poiInput);
      const newBound: Bound = { coordinates: location.bounds.coordinates, type: 'primary' };
      poiInput.bounds.push(newBound);
    }
    return poiInput;
  }

  private updateMarker(location: SecurityThreatLocation, poiInput: POI): POI {
    if (!this.isMarkerInAList(poiInput, location)) {
      poiInput = this.clearPrimaryObjects(poiInput);
      poiInput.markers.push(location.marker);
    }
    return poiInput;
  }

  private clearPrimaryObjects(poiInput: POI): POI {
    return {
      ...poiInput,
      markers: poiInput.markers.filter((marker) => marker.type !== 'primary'),
      bounds: poiInput.bounds.filter((bounds) => bounds.type !== 'primary')
    };
  }

  private areBoundsInAList(poiInput: POI, location: SecurityThreatLocation): boolean {
    const boundsExists: boolean = poiInput.bounds.some((existingBounds) =>
      existingBounds.coordinates.every((coordinateSet, index) =>
        coordinateSet.every(
          (coord, coordIndex) =>
            coord.lat === location.bounds.coordinates[index][coordIndex].lat &&
            coord.lng === location.bounds.coordinates[index][coordIndex].lng
        )
      )
    );

    return boundsExists;
  }

  private isMarkerInAList(poiInput: POI, location: SecurityThreatLocation): boolean {
    const markerExists: boolean = poiInput.markers.some(
      (existingMarker) =>
        existingMarker.coordinates.lat === location.marker.coordinates.lat &&
        existingMarker.coordinates.lng === location.marker.coordinates.lng
    );
    return markerExists;
  }

  public search(query: string): Observable<OpenStreetMapSearchResult[]> {
    const params = new URLSearchParams({
      q: query,
      format: 'json',
      addressdetails: '1',
      'accept-language': 'en',
      polygon_geojson: '1'
    });

    return this.http.get<OpenStreetMapSearchResult[]>(`${this.baseUrl}?${params.toString()}`).pipe(
      map((results: OpenStreetMapSearchResult[]) =>
        results.map((osmResult: OpenStreetMapSearchResult) => ({
          ...osmResult,
          marker: {
            coordinates: {
              lat: typeof osmResult.lat === 'string' ? parseFloat(osmResult.lat) : osmResult.lat,
              lng: typeof osmResult.lon === 'string' ? parseFloat(osmResult.lon) : osmResult.lon
            },
            type: 'primary'
          },
          bounds: this.createBounds(osmResult)
        }))
      )
    );
  }

  private createBounds(
    osmResult: OpenStreetMapSearchResult
  ): { coordinates: { lat: number; lng: number }[][]; type: 'primary' } | undefined {
    if (
      !osmResult.geojson ||
      !['MultiPolygon', 'Polygon'].includes(osmResult.geojson.type) ||
      osmResult.geojson.coordinates.length === 0
    ) {
      return undefined;
    }

    const coordinates =
      osmResult.geojson.type === 'Polygon'
        ? [
            osmResult.geojson.coordinates[0].map((coordinate) => ({
              lat: coordinate[1],
              lng: coordinate[0]
            }))
          ]
        : [
            osmResult.geojson.coordinates[0][0].map((coordinate) => ({
              lat: coordinate[1],
              lng: coordinate[0]
            }))
          ];

    return {
      coordinates,
      type: 'primary'
    };
  }
}
