import { TestBed } from '@angular/core/testing';
import { ApiSecurityThreatService } from './api-security-threat.service';
import { HttpClient } from '@angular/common/http';

describe('SecurityThreatService', () => {
  let apiSecurityThreatService: ApiSecurityThreatService;
  let mockHttpClient: jasmine.SpyObj<HttpClient>;

  beforeEach(() => {
    mockHttpClient = jasmine.createSpyObj('HttpClient', ['get']);

    TestBed.configureTestingModule({
      providers: [ApiSecurityThreatService, { provide: HttpClient, useValue: mockHttpClient }]
    });

    apiSecurityThreatService = TestBed.inject(ApiSecurityThreatService);
  });

  it('should be created', () => {
    expect(apiSecurityThreatService).toBeTruthy();
  });

  it('should get airport list', () => {
    const url = `/api/locations/airports`;
    apiSecurityThreatService.getAirports();
    expect(mockHttpClient.get).toHaveBeenCalledOnceWith(url);
  });

  it('should get involved countries list', () => {
    const url = `/api/overpass-countries/list`;
    apiSecurityThreatService.getInvolvedCountries();
    expect(mockHttpClient.get).toHaveBeenCalledOnceWith(url);
  });
});
