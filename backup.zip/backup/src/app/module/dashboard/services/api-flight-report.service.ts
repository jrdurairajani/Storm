import { HttpClient } from '@angular/common/http';
import { Injectable, Optional } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { User } from 'src/app/core/model/user.model';
import { RootState } from 'src/app/model/root-state.model';
import { StationGeneralInfo } from '../../station-details/models/station-general-info';
import { FlightReportSophi, FlightsResponse } from '../models/flight-report';
import * as RootSelectors from '../../../state/root.selectors';

@Injectable({
  providedIn: 'root'
})
export class ApiFlightReportService {
  constructor(
    private http: HttpClient,
    @Optional() private readonly store: Store<RootState>
  ) {}

  markAsDonePost(id, takeNotice, remarks): Observable<any> {
    const body = { takeNotice, remarks };
    const url = `/api/flight-reports/${id}/mark-as-done`;
    return this.http.post(url, body);
  }

  updateStatus(id, reqBody?: FormData): Observable<FlightReportSophi> {
    const url = `/api/flight-reports/workflow/${id}/submit`;
    return this.http.post<FlightReportSophi>(url, reqBody);
  }

  submitComment(id, reqBody: any): Observable<FlightReportSophi> {
    const url = `/api/flight-reports/${id}/submit-comment`;
    return this.http.post<FlightReportSophi>(url, reqBody);
  }

  assignToMe(flightLegId): Observable<any> {
    const url = `/api/flight-reports/${flightLegId}/assigntome`;
    return this.http.get(url);
  }

  reAssignToMe(flightLegId): Observable<any> {
    const url = `/api/flight-reports/${flightLegId}/change-assignment`;
    return this.http.get(url);
  }

  getLastComment(id): Promise<any> {
    const url = `api/flight-reports/${id}/last-comments`;
    return this.http.get<any>(url).toPromise();
  }

  getReports(page: number, stationCode: string): Observable<FlightsResponse> {
    const url = `/api/flight-reports/departed-flights/${stationCode}/?size=10&page=${page}`;
    return this.http.get(url);
  }

  getReportsAsAdmin(page: number): Observable<FlightsResponse> {
    const url = `/api/flight-reports/departed-flights/?size=10&page=${page}`;
    return this.http.get(url);
  }

  getStations(): Observable<StationGeneralInfo[]> {
    const url = '/api/stations';
    return this.http.get<StationGeneralInfo[]>(url);
  }

  getCurrentUserID(): Promise<any> {
    const currentUser: Observable<User | undefined> = this.store.select(
      RootSelectors.selectCurrentUser
    );
    return currentUser
      .pipe(
        map((el) => el.username),
        take(1)
      )
      .toPromise();
  }
}
