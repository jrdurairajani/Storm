import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiKfssb {
  constructor(private http: HttpClient) {}

  getKfssbRecods(airlineCode: string): Observable<any> {
    const url = `/api/kfssb-airlines/${airlineCode}/periods`;
    return this.http.get(url).pipe(map((el: any) => el.periods));
  }

  sendRecordKfssb(airlineCode, endDate, startDate, periodNumber): Observable<any> {
    const body = { airlineCode, endDate, startDate, periodNumber };
    const url = '/api/kfssb-airlines/periods';
    return this.http.post(url, body);
  }
}
