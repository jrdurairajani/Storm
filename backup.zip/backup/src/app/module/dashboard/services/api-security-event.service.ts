import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  SourceFilter,
  SecurityEventOverview,
  SecurityEventRecord
} from '../models/security-event-overview';
import { NextSecurityEvent, SecurityEvent, SecurityEventDTO } from '../models/security-event';

import { Country } from '../models/common';

// TODO: Refactor urls to endpoint constants (based on environment?)
@Injectable({
  providedIn: 'root'
})
export class ApiSecurityEventService {
  constructor(private http: HttpClient) {}

  public archive(id: string): Observable<SecurityEventRecord> {
    const url = `api/securityevents/${id}`;
    return this.http.delete(url) as Observable<SecurityEventRecord>;
  }

  public archiveAll(ids: string[]): Observable<SecurityEventRecord[]> {
    const url = `api/securityevents/archive`;
    return this.http.post(url, ids) as Observable<SecurityEventRecord[]>;
  }

  public getSecurityEventOverview(
    page: number,
    startDate?: string,
    endDate?: string,
    countries?: Country[],
    sources?: SourceFilter[]
  ): Observable<SecurityEventOverview> {
    const url = `api/securityevents?page=${page}&size=10&sort=desc`;
    let params = new HttpParams();
    if (startDate) {
      params = params.set('startDate', encodeURIComponent(startDate));
    }
    if (endDate) {
      params = params.set('endDate', encodeURIComponent(endDate));
    }
    if (countries.length > 0) {
      const codes = countries.map((el) => el.code);
      params = params.append('country', codes.join(','));
    }
    if (sources.length > 0) {
      const codes = sources.map((el) => el.code);
      params = params.append('eventSource', codes.join(','));
    }
    return this.http.get(url, { params: params });
  }

  public getIncidentDetails(id: string): Observable<SecurityEvent> {
    const url = `/api/securityevents/${id}`;
    return this.http.get<SecurityEvent>(url).pipe(
      map((securityEvent) => {
        return this.charTransform(securityEvent);
      })
    );
  }

  public getNextEventNavigation(
    page: number,
    cIndex: number,
    startDate?: string,
    endDate?: string,
    countries?: Country[],
    sources?: SourceFilter[]
  ): Observable<NextSecurityEvent> {
    const url = `api/securityevents/nextEventId?pageNum=${page}&recIndex=${cIndex}`;
    let params = new HttpParams();
    if (startDate) {
      params = params.set('startDate', encodeURIComponent(startDate));
    }
    if (endDate) {
      params = params.set('endDate', encodeURIComponent(endDate));
    }
    if (countries.length > 0) {
      const codes = countries.map((el) => el.code);
      params = params.append('country', codes.join(','));
    }
    if (sources.length > 0) {
      const codes = sources.map((el) => el.code);
      params = params.append('eventSource', codes.join(','));
    }
    return this.http.get<NextSecurityEvent>(url, { params: params });
  }

  public getSourceFilter(): Observable<SourceFilter[]> {
    const url = 'api/securityevents/eventsources';
    return this.http.get<SourceFilter[]>(url).pipe(
      map((source) => {
        return this.sourceFormat(source);
      })
    );
  }

  private sourceFormat(source: SourceFilter[]): SourceFilter[] {
    return source.map((item: SourceFilter) => {
      if (item.code === 'CONTROL_RISK') {
        item.name = 'Control Risk';
      }
      return item;
    });
  }

  public saveSecurityEvent(event: SecurityEventDTO, files: File[]): Observable<SecurityEventDTO> {
    const url = 'api/securityevents';
    const formData: FormData = new FormData();
    formData.append(
      'event',
      new Blob([JSON.stringify(event)], {
        type: 'application/json'
      })
    );
    files?.forEach((file) => {
      formData.append('attachments', file, file.name);
    });

    return this.http.post<SecurityEventDTO>(url, formData);
  }

  private charTransform(resps: SecurityEvent): SecurityEvent {
    const newRes = { ...resps };
    newRes.report = {
      ...newRes.report,
      attackType: this.replace(resps.report.attackType),
      category: this.replace(resps.report.category),
      perpetrators: this.replace(resps.report.perpetrators),
      sector: this.replace(resps.report.sector),
      assetTypes: this.replace(resps.report.assetTypes),
      secondaryCountries: this.replace(resps.report.secondaryCountries)
    };
    return newRes;
  }

  private replace(value): string {
    const regex = /\|/g;
    if (value == null) {
      return '';
    } else {
      return value.replace(regex, ', ');
    }
  }
}
