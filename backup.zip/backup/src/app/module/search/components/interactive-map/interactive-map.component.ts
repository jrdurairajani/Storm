import { Component } from '@angular/core';
// import * as L from 'leaflet';
// import 'leaflet.markercluster';
// import {ActivatedRoute, Router} from '@angular/router';
// import {RiskColor, RiskCountryLevel} from '../../models/maps/riskCountryLevel';
// import {MapsService} from '../../services/maps/maps.service';
import { SpinnerService } from '../../../shared/service/spinner.service';
// import {forkJoin, Observable, Subject, throwError} from 'rxjs';
// import {catchError, delay, first, shareReplay, takeUntil, tap} from 'rxjs/operators';
// import {MapsPoi} from '../../models/maps/mapsPoi';
// import {isViewTypeTabNavigationDisabled, prevViewType} from '../../state/search.actions';
// import {Store} from '@ngrx/store';
// import {RootState} from '../../../../model/root-state.model';
// import {ViewTypeModel} from '../../../../model/view-type.model';
// import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
// import { User } from 'src/app/core/model/user.model';
// import { selectCurrentUser } from 'src/app/state/root.selectors';
// import { RiskLevelService } from '../../services/risk-level/risk-level.service';
// import { GoogleMap } from '@angular/google-maps';
// import { ColorDialogComponent } from '../dialog-windows/color-dialog/color-dialog.component';
// import { FlightInfo } from 'src/app/module/station-details/models/flightInfo';
// import { StationDetailService } from 'src/app/module/station-details/services/station-detail-service';

// const iconRetinaUrl = 'assets/marker-icon-2x.png';
// const iconUrl = 'assets/marker-icon.png';
// const shadowUrl = 'assets/marker-shadow.png';
// const iconDefault = L.icon({
//   iconRetinaUrl,
//   iconUrl,
//   shadowUrl,
//   iconSize: [25, 41],
//   iconAnchor: [12, 41],
//   popupAnchor: [1, -34],
//   tooltipAnchor: [16, -28],
//   shadowSize: [41, 41]
// });
// L.Marker.prototype.options.icon = iconDefault;

@Component({
  selector: 'strm-interactive-map',
  templateUrl: './interactive-map.component.html',
  styleUrls: ['./interactive-map.component.scss'],
  providers: [SpinnerService]
})
export class InteractiveMapComponent {
  // mapsPoi: MapsPoi[] = [];
  // geoJsonWithRiskLevel: RiskCountryLevel;
  // mapsData$: Observable<[MapsPoi[], RiskCountryLevel]>;
  // mapDataRes$: Observable<[MapsPoi[], RiskCountryLevel]>;
  // #destroy = new Subject<boolean>();
  // errorOccured = false;
  // currentUser: Observable<User | undefined>  = this.store.select(selectCurrentUser);
  // markerClustererImagePath =
  // 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m';
  // markerOptions: google.maps.MarkerOptions = {draggable: false, clickable: true, icon: iconUrl};
  // markers = [];
  // zoom = 3;
  // options: google.maps.MapOptions = {
  //   center: {lat: 52.379189, lng: 4.899431},
  //   maxZoom: 20,
  //   minZoom: 3,
  // };
  // lat: 135;
  // lng: 22;
  // landColor = 'gray';
  // landBorderColor = '#505155';
  // yellow = '#ffcc00';
  // green = '#16b716';
  // blue = '#00a1de';
  // red = '#cc0000';
  // @ViewChild(GoogleMap, { static: false }) googleMap: GoogleMap;
  // constructor(private router: Router,
  //             private mapsService: MapsService,
  //             private spinnerService: SpinnerService,
  //             private store: Store < RootState > ,
  //             public dialog: MatDialog,
  //             private riskService: RiskLevelService,
  //             private zone: NgZone,
  //             private stationDetailService: StationDetailService) { }
  // ngOnInit(): void {
  // this.mapsData$ = forkJoin([
  //   this.mapsService.getAllStations().pipe(first()),
  //   this.mapsService.getGeoJson().pipe(first())
  // ]).pipe(
  //     tap(() => this.errorOccured = false),
  //     takeUntil(this.#destroy),
  //     shareReplay(),
  //     catchError(() => {
  //       this.errorOccured = true;
  //       return throwError('Error Occured while retrieving maps Details');
  //     }));
  // this.mapDataRes$ = this.spinnerService.showLoaderUntilCompleted(this.mapsData$);
  // this.mapDataRes$.pipe(delay(0), takeUntil(this.#destroy)).subscribe(res => {
  //   this.mapsPoi = [];
  //   this.mapsPoi.push(...res[0]);
  //   this.geoJsonWithRiskLevel = res[1];
  //   if (this.googleMap){  // this is to for test to pass, since in test google map viewchild is undefined
  //     this.initGoogleMap();
  //   }
  //   }, (error) => {
  //     console.log('oCCUred', error);
  //   }
  // );
  // this.store.dispatch(prevViewType({viewType: ViewTypeModel.MAP}));
  // this.store.dispatch(isViewTypeTabNavigationDisabled({enableNavigation: true}));
  // }
  // initGoogleMap(): void{
  //   this.drawGeojson();
  //   this.setRighClickListenerGeoJson();
  //   this.addMarkers();
  // }
  // private addMarkers(): void {
  //   this.markers = [];
  //   this.mapsPoi.map(station => {
  //     const marker = new google.maps.Marker({
  //       position: {lat: station.coordinates.latitude, lng: station.coordinates.longitude},
  //       label: station.details.name,
  //       title: station.details.code,
  //       clickable: true,
  //   });
  //     this.markers.push(marker);
  //   });
  // }
  // drawGeojson(): void{
  //   this.geoJsonWithRiskLevel.countryGeoWithRisk.map((country, index) => {
  //     country.geoJson.features[0].properties.color = country.riskLevel;
  //     this.googleMap.data.addGeoJson(country.geoJson, {
  //       idPropertyName: index.toString()
  //     });
  //   });
  //   this.setColorGeoJson();
  // }
  // setRighClickListenerGeoJson(): void{
  //   this.googleMap.data.addListener('contextmenu', (event) => {
  //     const color = event.feature.getProperty('color');
  //     const countryCode = event.feature.getProperty('ISO_A3');
  //     const countryName = event.feature.getProperty('ADMIN');
  //     this.riskService.getColors().subscribe((colorCodes: RiskColor[]) => {
  //       this.zone.run(() => {
  //         this.openDialog(color, countryCode, colorCodes, countryName);
  //       });
  //      }, err => console.log('no access', err));
  //   });
  // }
  // setColorGeoJson(): void{
  //   this.googleMap.data.setStyle((feature) => {
  //     let color = '';
  //     const countryColor = feature.getProperty('color');
  //     switch (countryColor) {
  //       case 'RED':
  //         color = this.red;
  //         break;
  //       case 'YELLOW':
  //         color = this.yellow;
  //         break;
  //       case 'GREEN':
  //         color = this.green;
  //         break;
  //       default:
  //         color = this.landColor;
  //         break;
  //     }
  // eslint-disable-next-line
  //     return /** @type {google.maps.Data.StyleOptions} */({
  //         fillColor: color,
  //         strokeColor: this.landBorderColor,
  //         strokeWeight: 1,
  //         fillOpacity:  0.2
  //     });
  //   });
  // }
  // ngOnDestroy(): void {
  // this.#destroy.next(true);
  // this.#destroy.unsubscribe();
  // }
  // onMarkerClick(marker): void {
  //   this.stationDetailService.getFlightsForStation(marker.title)
  //   .pipe(takeUntil(this.#destroy)).subscribe((flightInfo: FlightInfo) => {
  //     this.store.dispatch(isViewTypeTabNavigationDisabled({enableNavigation: false}));
  //     this.router.navigate(['station', 'details', marker.title], {state: flightInfo});
  //   });
  // }
  //  rightClickHandle(event): void{
  //    const data = event.sourceTarget.options;
  //    this.riskService.getColors().subscribe((colorCodes: RiskColor[]) => {
  //    this.openDialog(data.fillColor, data.countryCode, colorCodes, data.countryName);
  //   }, err => console.log('no access', err)
  //   );
  // }
  //  openDialog(currentColor: string, countryCode: string, colorCodes: RiskColor[], countryName: string): void {
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.autoFocus = true;
  //   dialogConfig.width = '326px';
  //   dialogConfig.height = '250px';
  //   dialogConfig.panelClass = 'app-full-bleed-dialog',
  //   dialogConfig.data = {
  //     currentColor,
  //     countryCode,
  //     colorCodeList: colorCodes,
  //     countryName
  //   };
  //   const dialogRef = this.dialog.open(ColorDialogComponent, dialogConfig);
  //   dialogRef.afterClosed().subscribe((dialogItem: {isUpdated: boolean, countryCode: string, color: string}) => {
  //     if (dialogItem.isUpdated){
  //       this.manualChangeColor(dialogItem.countryCode, dialogItem.color);
  //     }
  //   });
  // }
  // manualChangeColor(countryCodeArg: string, color: string): void{
  //   const index = this.geoJsonWithRiskLevel.countryGeoWithRisk.findIndex((element: any) => element.countryCode === countryCodeArg);
  //   this.geoJsonWithRiskLevel.countryGeoWithRisk[index].geoJson.features[0].properties.color = color;
  //   this.geoJsonWithRiskLevel.countryGeoWithRisk[index].riskLevel = color;
  //   this.setColorGeoJson();
  //   this.mapsService.updateGeoJson(this.geoJsonWithRiskLevel);
  //   }
}
