import { TestBed } from '@angular/core/testing';

import { InteractiveMapComponent } from './interactive-map.component';
import { Router } from '@angular/router';
import { MapsService } from '../../services/maps/maps.service';
import { SpinnerService } from '../../../shared/service/spinner.service';
import { SharedModule } from '../../../shared/shared.module';
import { provideMockStore } from '@ngrx/store/testing';
import { UntypedFormBuilder } from '@angular/forms';
import { CountriesDataService } from '../../services/country/countries-data.service';
import { RiskLevelService } from '../../services/risk-level/risk-level.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('InteractiveMapComponent', () => {
  const initialState = { loggedIn: false };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, SharedModule, BrowserAnimationsModule],
      declarations: [InteractiveMapComponent],
      providers: [
        MapsService,
        SpinnerService,
        UntypedFormBuilder,
        CountriesDataService,
        RiskLevelService,
        provideMockStore({ initialState }),
        {
          provide: Router,
          useValue: {
            navigate: () => {
              /* Do nothing */
            }
          }
        },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  // it('should fetch all the details required to load the maps', () => {
  //   const mapsService = TestBed.inject(MapsService);
  //   spyOn(mapsService, 'getAllStations').and.returnValue(of(maps.stations));
  //   spyOn(mapsService, 'getGeoJson').and.returnValue(of(maps.geoJson));
  //   fixture.detectChanges();
  //   component.mapsData$.pipe(delay(1)).subscribe((res) => {
  //     expect(component.mapsPoi.length).toBeGreaterThan(0);
  //     expect(component.geoJsonWithRiskLevel).toBe(maps.geoJson);
  //   });
  // });

  // it('When map clicked and role allows to edit country color, should download colorCodes',  () => {
  //   spyOn(riskLevelService, 'getColors').and.returnValue(of(colors));
  //   component.rightClickHandle(event);
  //   fixture.detectChanges();
  //   riskLevelService.getColors().subscribe((colorData: RiskColor[]) => {
  //     expect(colorData.length).toBeGreaterThan(0);
  //     component.dialog.closeAll();
  //   });
  // });

  // it('When map clicked and role not allows to edit country color, should not download colorCodes',  () => {
  //     const errorText = 'User not authorised to get COLOR Codes Details!!!';
  //     spyOn(riskLevelService, 'getColors').and.returnValue(throwError({status: 401, statusText: errorText}));
  //     component.rightClickHandle(event);
  //     fixture.detectChanges();

  //     riskLevelService.getColors().subscribe(() => {
  //       fail('this download should fail');
  //     },
  //     (error: HttpErrorResponse) => {
  //       expect(error.status).toBe(401);
  //     }
  //     );

  // });

  /* To see how to validate this test */
  /*it('should show error to user when one of the service fails', () => {
    const mapsService = TestBed.inject(MapsService);
    spyOn(mapsService, 'getAllStations').and.returnValue(throwError('Error Occured'));
    spyOn(mapsService, 'getGeoJson').and.returnValue(of(maps.geoJson));
    fixture.detectChanges();
    component.mapsData$.pipe(delay(1)).subscribe((res) => {
    });
  });*/
});
