import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UntypedFormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrModule } from 'ngx-toastr';
import { RiskLevelService } from '../../../services/risk-level/risk-level.service';

import { ColorDialogComponent } from './color-dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ColorDialogComponent', () => {
  let component: ColorDialogComponent;
  let fixture: ComponentFixture<ColorDialogComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ToastrModule.forRoot()],
      declarations: [ColorDialogComponent],
      providers: [
        UntypedFormBuilder,
        RiskLevelService,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColorDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getFormData should return data in DataForm', () => {
    const result = component.getFormData('PL', '10');
    expect(result).toBeInstanceOf(FormData);
  });

  it('getCurrentColor should return TRANSPARENT if currentColor is light-grey', () => {
    const result = component.getCurrentColor('gray');
    expect(result).toEqual('TRANSPARENT');
  });

  it('getCurrentColor should return TRANSPARENT if currentColor is null', () => {
    const result = component.getCurrentColor(null);
    expect(result).toEqual('TRANSPARENT');
  });

  it('getCurrentColor should return argument that received in parameter if it was !== gray or null', () => {
    const result = component.getCurrentColor('GREEN');
    expect(result).toEqual('GREEN');
  });
});
