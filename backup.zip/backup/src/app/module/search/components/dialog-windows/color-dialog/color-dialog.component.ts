import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { RiskColor } from '../../../models/maps/riskCountryLevel';
import { RiskLevelService } from '../../../services/risk-level/risk-level.service';

@Component({
  selector: 'strm-color-dialog',
  templateUrl: './color-dialog.component.html',
  styleUrls: ['./color-dialog.component.scss']
})
export class ColorDialogComponent implements OnInit {
  form: UntypedFormGroup;
  riskColorList: RiskColor[];
  currentColor: string;
  countryCode: string;
  countryName: string;

  constructor(
    private fb: UntypedFormBuilder,
    private riskService: RiskLevelService,
    private toast: ToastrService,
    public dialogRef: MatDialogRef<ColorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.riskColorList = data.colorCodeList;
    this.currentColor = this.getCurrentColor(data.currentColor);
    this.countryCode = data.countryCode;
    this.countryName = data.countryName;
  }

  getCurrentColor(currentColor: string): string {
    let color = '';

    if (currentColor === 'gray' || currentColor === null) {
      color = 'TRANSPARENT';
    } else {
      color = currentColor;
    }
    return color;
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      color: [[this.currentColor], []]
    });
    this.form.get('color').setValue(this.currentColor);
  }

  prepareData(): void {
    const color = this.form.get('color').value;
    const colorCode = this.riskColorList.find(
      (colorElement: RiskColor) => color === colorElement.color
    ).code;
    const formData = this.getFormData(this.countryCode, colorCode);
    this.save(formData);
  }

  save(formData: FormData): void {
    this.riskService.updateColor(formData).subscribe(() => {
      this.toast.success('Success');
      this.dialogRef.close({
        isUpdated: true,
        countryCode: this.countryCode,
        color: this.form.get('color').value
      });
    });
  }

  getFormData(countryCode, colorCode): FormData {
    const formData = new FormData();
    formData.append('countryCode', countryCode);
    formData.append('securityLevelCode', colorCode);
    return formData;
  }

  close(): void {
    this.dialogRef.close({ isUpdated: false, countryCode: null, color: null });
  }
}
