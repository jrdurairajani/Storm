import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, mergeMap, takeUntil } from 'rxjs/operators';
import { CountriesEntityService } from '../../services/country/countries-entity.service';
import { CityEntityService } from '../../services/city/city-entity.service';
import { Store } from '@ngrx/store';
import { SearchState } from '../../state/reducers';
import { FilterBy } from '../../models/FilterBy';
import { SearchActions } from '../../state/actionTypes';
import { StationEntityService } from '../../services/station/stations-entity.service';
import { KeyValuePair } from '../../../shared/models/key-value-pair';
import { RegionEntityService } from '../../services/regions/region-entity.service';

const AIRLINE_TYPE: string[] = ['KL', 'MP', 'HV'];
@Component({
  selector: 'strm-filter-by',
  templateUrl: './filter-by.component.html',
  styleUrls: ['./filter-by.component.scss']
})
export class FilterByComponent implements OnInit, AfterViewInit, OnDestroy {
  inputAttributes: { name: string; placeholder: string } = { name: '', placeholder: '' };
  filteredOptions: Observable<KeyValuePair[]> | undefined;
  radioButtonValues: KeyValuePair[] = [
    { key: 'Region', value: 'region' },
    { key: 'Country', value: 'country' },
    { key: 'City', value: 'city' },
    { key: 'Station', value: 'station' }
  ];
  noResults = false;
  isSearching = false;
  airlineTypeList: string[] = AIRLINE_TYPE;
  #destroy = new Subject<boolean>();

  filterForm = this.formsBuilder.group({
    itemType: ['station', [Validators.required]],
    itemValue: ['', [Validators.required, Validators.minLength(3)]],
    airlineType: [['KL']]
  });

  constructor(
    private formsBuilder: UntypedFormBuilder,
    private translate: TranslateService,
    private regionsEntityService: RegionEntityService,
    private countriesEntityService: CountriesEntityService,
    private cityService: CityEntityService,
    private stationService: StationEntityService,
    private store: Store<SearchState>
  ) {
    translate.setDefaultLang('en');
  }

  ngOnInit(): void {
    this.subscribeToFormInputChanges();
    this.subscribeToRadioInputChanges();
  }

  ngAfterViewInit(): void {
    /* As default selection is stations */
    this.translate.get('search.filterBy.station').subscribe((res) => (this.inputAttributes = res));
  }

  ngOnDestroy(): void {
    this.#destroy.next(true);
    this.#destroy.unsubscribe();
  }

  subscribeToRadioInputChanges(): void {
    this.filterForm
      .get('itemType')
      ?.valueChanges.pipe(takeUntil(this.#destroy))
      .subscribe((value) => {
        this.filteredOptions = of([]);
        this.filterForm.controls.itemValue.setValue('');
        this.translate
          .get(`search.filterBy.${value}`)
          .subscribe((res) => (this.inputAttributes = res));
        this.noResults = false;
      });
  }

  private subscribeToFormInputChanges(): void {
    this.filterForm
      .get('itemValue')
      ?.valueChanges.pipe(
        debounceTime(500),
        distinctUntilChanged(),
        takeUntil(this.#destroy),
        mergeMap((value: string) => {
          if (value !== '' && value.length > 1) {
            const result = this.callSelectedCriteriaService(value);
            this.updateResults(result, false, false);
            return result;
          } else {
            this.store.dispatch(SearchActions.userClearedFilterValue());
            this.updateResults(of([]), false, false);
            return of([]);
          }
        })
      )
      .subscribe((response) => this.handleInputChangeResponse(response));
  }

  private updateResults(
    result: Observable<KeyValuePair[]>,
    isSearching: boolean,
    noresults: boolean
  ): void {
    this.filteredOptions = result;
    this.updateIsSearchAndNoResults(isSearching, noresults);
  }

  private handleInputChangeResponse(res: KeyValuePair[]): void {
    const inputTextVal = this.filterForm.get('itemValue')?.value;
    if (res.length > 0 && inputTextVal !== '') {
      this.updateIsSearchAndNoResults(false, false);
    } else if (res.length === 0 && inputTextVal.length <= 1) {
      this.updateIsSearchAndNoResults(false, false);
    } else {
      this.updateIsSearchAndNoResults(false, true);
    }
  }

  private updateIsSearchAndNoResults(isSearching: boolean, noResults: boolean): void {
    this.isSearching = isSearching;
    this.noResults = noResults;
  }

  private callSelectedCriteriaService(value: string): Observable<KeyValuePair[]> {
    const selectedService = this.filterForm.get('itemType')?.value;
    this.isSearching = true;
    switch (selectedService) {
      case 'region':
        return this.getRegionDetails(value);
      case 'country':
        return this.getCountryDetails(value);
      case 'city':
        return this.getCitiesDetails(value);
      case 'station':
        return this.getStationDetails(value);
      default:
        return of([]);
    }
  }

  private getRegionDetails(name: string): Observable<KeyValuePair[]> {
    return this.regionsEntityService.getWithQuery({ name }).pipe(
      takeUntil(this.#destroy),
      map((regions) => regions.map((region) => this.getKeyValuePair(region.name, region.name)))
    );
  }

  getCountryDetails(name: string): Observable<KeyValuePair[]> {
    return this.countriesEntityService.getWithQuery({ name }).pipe(
      takeUntil(this.#destroy),
      map((countries) =>
        countries.map((country) => this.getKeyValuePair(country.name, country.alpha3code))
      )
    );
  }

  getCitiesDetails(name: string): Observable<KeyValuePair[]> {
    return this.cityService.getWithQuery({ name }).pipe(
      takeUntil(this.#destroy),
      map((cities) =>
        cities.map((city) =>
          this.getKeyValuePair(`${city.name}, ${city.countryAlphaThreeCode}`, city.iataCode)
        )
      )
    );
  }

  getStationDetails(name: string): Observable<KeyValuePair[]> {
    return this.stationService.getWithQuery({ name }).pipe(
      takeUntil(this.#destroy),
      map((stations) =>
        stations.map((station) => this.getKeyValuePair(station.iataCode, station.iataCode))
      )
    );
  }

  getKeyValuePair(key: string, value: string): KeyValuePair {
    return { key, value };
  }

  displayFn(value: string): string {
    let displayValue = '';
    switch (this.filterForm.get('itemType')?.value) {
      case 'region':
        this.filteredOptions
          ?.pipe(
            takeUntil(this.#destroy),
            map((regionOptions) => regionOptions.find((region) => region.value === value))
          )
          .subscribe((result) => (displayValue = result ? result.key : ''));
        break;
      case 'country':
        this.filteredOptions
          ?.pipe(
            takeUntil(this.#destroy),
            map((countryOptions) => countryOptions.find((country) => country.value === value))
          )
          .subscribe((result) => (displayValue = result ? result.key : ''));
        break;
      case 'city':
        this.filteredOptions
          ?.pipe(
            takeUntil(this.#destroy),
            map((cityOptions) => cityOptions.find((city) => city.value === value))
          )
          .subscribe((result) => (displayValue = result ? result.key : ''));
        break;
      case 'station':
        this.filteredOptions
          ?.pipe(
            takeUntil(this.#destroy),
            map((stationOptions) => stationOptions.find((station) => station.value === value))
          )
          .subscribe((result) => (displayValue = result ? result.key : ''));
        break;
    }
    return displayValue;
  }

  handleSelectedOption(): void {
    const filterBy: FilterBy = {
      type: this.filterForm.get('itemType')?.value,
      code: this.filterForm.get('itemValue')?.value,
      airlineType: this.filterForm.get('airlineType')?.value,
      size: 10,
      page: 0,
      sort: 'name,asc'
    };
    this.store.dispatch(SearchActions.userSelectedFilterType({ filterBy }));
    this.store.dispatch(SearchActions.callingSearchApi({ filterBy }));
  }
}
