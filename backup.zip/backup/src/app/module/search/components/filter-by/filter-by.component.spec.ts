import { ComponentFixture, fakeAsync, flush, TestBed, tick } from '@angular/core/testing';

import { FilterByComponent } from './filter-by.component';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { FstMaterialModule } from '../../../../fst-material/fst-material.module';
import { SharedModule } from '../../../shared/shared.module';
import { TranslateService } from '@ngx-translate/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Observable, of } from 'rxjs';
import { Country } from '../../models/country';
import { CountriesEntityService } from '../../services/country/countries-entity.service';
import { CityEntityService } from '../../services/city/city-entity.service';
import { City } from '../../models/city';
import { provideMockStore } from '@ngrx/store/testing';
import { StationEntityService } from '../../services/station/stations-entity.service';
import { Station } from '../../models/station';
import { RegionEntityService } from '../../services/regions/region-entity.service';
import { Region } from '../../models/regions';
import { countries } from '../../testUtils/mocks/country-quick-search';
import { CityQuickSearchresults } from '../../testUtils/mocks/city-quick-searchresults';
import { regionsQuickSearch } from '../../testUtils/mocks/regions-quick-search';
import { NO_ERRORS_SCHEMA } from '@angular/core';

export class CountriesEntityServiceStub {
  loading$: Observable<boolean> = of(false);
  entities$: Observable<Country[]> = of(countries);

  getAll(): Observable<Country[]> {
    return this.entities$;
  }

  getWithQuery(): Observable<Country[]> {
    return of([countries[0]]);
  }
}

export class CitiesEntityServiceStub {
  loading$: Observable<boolean> = of(false);
  entities$: Observable<City[]> = of(CityQuickSearchresults);

  getAll(): Observable<City[]> {
    return this.entities$;
  }

  getWithQuery(): Observable<City[]> {
    return of([CityQuickSearchresults[0]]);
  }
}

export class StationEntityServiceStub {
  loading$: Observable<boolean> = of(false);
  entities$: Observable<Station[]> = of([
    {
      id: '82cd5ecf-47e7-4c74-8c36-8abddb0b8eeb',
      country: {
        name: 'UNITED STATES',
        alpha2code: 'US',
        alpha3code: 'USA'
      },
      city: {
        name: 'DALLAS',
        iataCode: 'dfw'
      },
      name: 'ADDISON AIRPORT',
      coordinates: {
        latitude: 32.78333333,
        longitude: -97.3
      },
      iataCode: 'ads',
      icaoCode: 'kads',
      type: 'Station'
    }
  ]);

  getAll(): Observable<Station[]> {
    return this.entities$;
  }
}

export class RegionsEntityStubService {
  loading$: Observable<boolean> = of(false);
  entities$: Observable<Region[]> = of(regionsQuickSearch);

  getAll(): Observable<Region[]> {
    return this.entities$;
  }

  getWithQuery(): Observable<Region[]> {
    return of([regionsQuickSearch[0]]);
  }
}

describe('FilterByComponent', () => {
  let component: FilterByComponent;
  let fixture: ComponentFixture<FilterByComponent>;

  const initialState = { loggedIn: false };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        FstMaterialModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [FilterByComponent],
      providers: [
        UntypedFormBuilder,
        TranslateService,
        provideMockStore({ initialState }),
        { provide: RegionEntityService, useClass: RegionsEntityStubService },
        { provide: CountriesEntityService, useClass: CountriesEntityServiceStub },
        { provide: CityEntityService, useClass: CitiesEntityServiceStub },
        { provide: StationEntityService, useClass: StationEntityServiceStub }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterByComponent);
    component = fixture.componentInstance;
    component.filterForm.controls.itemType.setValue('station');
    fixture.detectChanges();
  });

  it('should create filterBy component', async () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.filterForm.get('itemType')?.value).toEqual('station');
    expect(component.filteredOptions).toEqual(undefined);
  });
});

describe('FilterByComponent when selection changed', () => {
  let component: FilterByComponent;
  let fixture: ComponentFixture<FilterByComponent>;

  const initialState = { loggedIn: false };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        FstMaterialModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [FilterByComponent],
      providers: [
        UntypedFormBuilder,
        TranslateService,
        provideMockStore({ initialState }),
        { provide: RegionEntityService, useClass: RegionsEntityStubService },
        { provide: CountriesEntityService, useClass: CountriesEntityServiceStub },
        { provide: CityEntityService, useClass: CitiesEntityServiceStub },
        { provide: StationEntityService, useClass: StationEntityServiceStub }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterByComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should select the country radio button if form itemType is set to country ', async () => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('country');
    fixture.detectChanges();
    await fixture.whenStable().then(() => {
      expect(component).toBeTruthy();
      expect(component.filterForm.get('itemType')?.value).toEqual('country');
      component.filteredOptions.subscribe((options) => {
        expect(options.length).toEqual(0);
      });
    });
  });

  it('should call the service once you have started entering in filter input field for country when input length is > 2', fakeAsync(() => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('country');
    component.filterForm.get('itemValue').setValue('india');
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.filterForm.get('itemValue')?.value).toEqual('india');
    fixture.detectChanges();
    tick(600);
    component.filteredOptions.subscribe((options) => {
      fixture.detectChanges();
      expect(options.length).toEqual(1);
    });
    flush();
  }));

  it('should call the service once you have started entering in filter input field for Regions when input length is > 2', fakeAsync(() => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('region');
    component.filterForm.get('itemValue').setValue('africa');
    fixture.detectChanges();
    expect(component.filterForm.get('itemValue')?.value).toEqual('africa');
    fixture.detectChanges();
    tick(600);
    component.filteredOptions.subscribe((options) => {
      fixture.detectChanges();
      expect(options.length).toEqual(1);
    });
    flush();
  }));

  it('should call the service once you have started entering in filter input field for city', fakeAsync(() => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('city');
    component.filterForm.get('itemValue').setValue('cityvalue');
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.filterForm.get('itemValue')?.value).toEqual('cityvalue');
    fixture.detectChanges();
    tick(600);
    component.filteredOptions.subscribe((options) => {
      fixture.detectChanges();
      expect(options.length).toEqual(1);
    });
    flush();
  }));

  it('should have the filteroptions to be cleared on user entering and deleting the input', fakeAsync(() => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('city');
    component.filterForm.get('itemValue').setValue('cityvalue');
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.filterForm.get('itemValue')?.value).toEqual('cityvalue');
    component.filterForm.get('itemValue').setValue('');
    tick(600);
    fixture.detectChanges();
    component.filteredOptions.subscribe((options) => {
      fixture.detectChanges();
      expect(options.length).toEqual(0);
    });
    flush();
  }));
});

export class CitiesEntityServiceEmptyStub {
  loading$: Observable<boolean> = of(false);
  entities$: Observable<City[]> = of([]);

  getAll(): Observable<City[]> {
    return this.entities$;
  }

  getWithQuery(): Observable<City[]> {
    return of([]);
  }
}

describe('FilterByComponent when selection changed', () => {
  let component: FilterByComponent;
  let fixture: ComponentFixture<FilterByComponent>;

  const initialState = { loggedIn: false };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        FstMaterialModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [FilterByComponent],
      providers: [
        UntypedFormBuilder,
        TranslateService,
        provideMockStore({ initialState }),
        { provide: RegionEntityService, useClass: RegionsEntityStubService },
        { provide: CountriesEntityService, useClass: CountriesEntityServiceStub },
        { provide: CityEntityService, useClass: CitiesEntityServiceEmptyStub },
        { provide: StationEntityService, useClass: StationEntityServiceStub }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterByComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should have noresults set to true and isSearching to false if no results were found', fakeAsync(() => {
    fixture.detectChanges();
    component.filterForm.get('itemType').setValue('city');
    component.filterForm.get('itemValue').setValue('cityvalue123');
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.filterForm.get('itemValue')?.value).toEqual('cityvalue123');
    tick(600);
    fixture.detectChanges();
    component.filteredOptions.subscribe((options) => {
      fixture.detectChanges();
      expect(options.length).toEqual(0);
      expect(component.noResults).toBeTruthy();
      expect(component.isSearching).toBeFalsy();
    });
    flush();
  }));
});
