import { Component } from '@angular/core';

@Component({
  selector: 'strm-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {}
