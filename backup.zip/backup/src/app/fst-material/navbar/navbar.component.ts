import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import * as RootSelectors from '../../state/root.selectors';
import { NavigationItem } from '../../model/navigation-item.model';
import { RootState } from '../../model/root-state.model';
import { Router } from '@angular/router';
import { isViewTypeDisabled, viewType } from '../../module/search/state/search.selectors';
import { ViewTypeModel } from '../../model/view-type.model';
import { takeUntil } from 'rxjs/operators';
import { prevViewType } from '../../module/search/state/search.actions';
import { Location } from '@angular/common';
import { InitService } from 'src/app/core/services/init.service';

@Component({
  selector: 'strm-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit, OnDestroy {
  isChecked = true;
  navItems: Observable<NavigationItem[]> = this.store.select(
    RootSelectors.selectTopNavigationItems
  );
  enableViewType: Observable<boolean>;
  #destroy = new Subject<boolean>();

  constructor(
    private store: Store<RootState>,
    private router: Router,
    private location: Location,
    public initService: InitService
  ) {}

  backClicked(): void {
    this.location.back();
  }

  viewType(): void {
    this.isChecked = !this.isChecked;
    if (this.isChecked) {
      this.store.dispatch(prevViewType({ viewType: ViewTypeModel.MAP }));
      this.router.navigate(['search', 'maps']).then();
    } else {
      this.store.dispatch(prevViewType({ viewType: ViewTypeModel.SEARCH }));
      this.router.navigate(['search', 'list']).then();
    }
    this.isChecked = !this.isChecked;
  }

  subscribeToPageChangeEvent(): void {
    this.enableViewType = this.store.select(isViewTypeDisabled);
  }

  ngOnInit(): void {
    this.subscribeToPageChangeEvent();
    this.subscribeToViewType();
  }

  subscribeToViewType(): void {
    this.store
      .select(viewType)
      .pipe(takeUntil(this.#destroy))
      .subscribe((value) => {
        this.isChecked = value === ViewTypeModel.MAP;
      });
  }

  ngOnDestroy(): void {
    this.#destroy.next(true);
  }
}
