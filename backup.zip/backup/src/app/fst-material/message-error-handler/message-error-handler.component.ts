import { Component, OnInit } from '@angular/core';
import { MessageErrorService } from './message-error.service';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'strm-message-error-handler',
  templateUrl: './message-error-handler.component.html',
  styleUrls: ['./message-error-handler.component.scss']
})
export class MessageErrorHandlerComponent implements OnInit {
  showMessages = false;
  errors1$: Observable<string[]>;
  constructor(public messageErrorService: MessageErrorService) {}

  ngOnInit(): void {
    this.errors1$ = this.messageErrorService.errors$.pipe(tap(() => (this.showMessages = true)));
  }

  onClose(): void {
    this.showMessages = false;
  }
}
