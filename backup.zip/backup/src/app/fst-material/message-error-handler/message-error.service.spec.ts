import { TestBed } from '@angular/core/testing';

import { MessageErrorService } from './message-error.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('MessageErrorService', () => {
  let service: MessageErrorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MessageErrorService]
    });
    service = TestBed.inject(MessageErrorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
