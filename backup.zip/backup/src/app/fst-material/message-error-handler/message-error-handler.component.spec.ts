import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageErrorHandlerComponent } from './message-error-handler.component';
import { MessageErrorService } from './message-error.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('MessageErrorHandlerComponent', () => {
  let component: MessageErrorHandlerComponent;
  let fixture: ComponentFixture<MessageErrorHandlerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MessageErrorHandlerComponent],
      providers: [MessageErrorService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MessageErrorHandlerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
