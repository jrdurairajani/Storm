import { Component } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Store } from '@ngrx/store';
import { RootState } from '../../model/root-state.model';
import { selectSideNavigationItems } from '../../state/root.selectors';
import { Observable } from 'rxjs';
import { SideNavItem } from '../model/side-nav-item';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'strm-nav',
  templateUrl: './nav.component.html',
  animations: [
    trigger('bodyExpansion', [
      state('collapsed', style({ height: '0px', display: 'none' })),
      state('expanded', style({ height: '*', display: 'block' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4,0.0,0.2,1)'))
    ])
  ]
})
export class NavComponent {
  navItems: Observable<SideNavItem[]>;
  constructor(
    private store: Store<RootState>,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.navItems = this.store.select(selectSideNavigationItems);
  }
}
