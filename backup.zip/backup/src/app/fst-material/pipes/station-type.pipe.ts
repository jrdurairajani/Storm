import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stationType'
})
export class StationTypePipe implements PipeTransform {
  transform(value: string): string {
    switch (value) {
      case 'A':
      case 'a':
        return 'Airport';
      case 'm':
      case 'M':
        return 'Military';
      default:
        return '';
    }
  }
}
