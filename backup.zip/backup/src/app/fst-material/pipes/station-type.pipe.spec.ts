import { StationTypePipe } from './station-type.pipe';

describe('StationTypePipe', () => {
  it('create an instance', () => {
    const pipe = new StationTypePipe();
    expect(pipe).toBeTruthy();
  });

  it('should show user value when an abbreviation is provided', () => {
    const pipe = new StationTypePipe();
    expect(pipe.transform('A')).toEqual('Airport');
    expect(pipe.transform('a')).toEqual('Airport');
    expect(pipe.transform('M')).toEqual('Military');
    expect(pipe.transform('m')).toEqual('Military');
  });

  it('should show user a value of Empty when value other than A and M are provided', () => {
    const pipe = new StationTypePipe();
    expect(pipe.transform('Z')).toEqual('');
  });
});
