import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StationInfoComponent } from './station-info.component';
import { provideMockStore } from '@ngrx/store/testing';
import { storeMockInitialState } from '../../module/station-details/mocks/storeMockInitialState';
import { getStationInfo } from '../../module/station-details/state/station-details.selectors';
import { SharedModule } from '../../module/shared/shared.module';
import { Coordinates } from '../../module/station-details/models/station-general-info';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('StationInfoComponent', () => {
  let component: StationInfoComponent;
  let fixture: ComponentFixture<StationInfoComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StationInfoComponent],
      imports: [SharedModule],
      providers: [
        provideMockStore({
          initialState: storeMockInitialState,
          selectors: [
            { selector: getStationInfo, value: storeMockInitialState.stationDetails.info }
          ]
        })
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StationInfoComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should load the station details on the page load', () => {
    fixture.detectChanges();
    expect(component.stationInfo).toEqual(storeMockInitialState.stationDetails.info);
  });

  it('getLocalTimeByCoordinates should receive coordinates and return their local time in hh:mm format', () => {
    fixture.detectChanges();
    const coordinates: Coordinates = {
      latitude: -12.02666667,
      longitude: -77.12277778
    };
    const regex = /(?:[01]\d|2[0-3]):(?:[0-5]\d)/;
    const result = component.getLocalTimeByCoordinates(coordinates);
    expect(regex.test(result)).toBeTrue();
  });
});
