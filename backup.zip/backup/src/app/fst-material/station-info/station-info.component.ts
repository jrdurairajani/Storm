import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import {
  Coordinates,
  StationGeneralInfo
} from '../../module/station-details/models/station-general-info';
import { getStationInfo } from '../../module/station-details/state/station-details.selectors';
import { RootState } from '../../model/root-state.model';
import { filter, map, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import ts from '@mapbox/timespace';

@Component({
  selector: 'strm-station-info',
  templateUrl: './station-info.component.html',
  styleUrls: ['./station-info.component.scss']
})
export class StationInfoComponent implements OnInit, OnDestroy {
  stationInfo: StationGeneralInfo;
  #destroy = new Subject<boolean>();
  constructor(private store: Store<RootState>) {}

  ngOnInit(): void {
    this.store
      .select(getStationInfo)
      .pipe(
        takeUntil(this.#destroy),
        filter((station) => !!station),
        map((station) => {
          const time = this.getLocalTimeByCoordinates(station.coordinates);
          return { time, ...station };
        })
      )
      .subscribe((info) => {
        this.stationInfo = info;
      });
  }

  getLocalTimeByCoordinates(coordinates: Coordinates): string {
    const lat = coordinates.latitude;
    const lng = coordinates.longitude;
    const timestamp = Date.now();
    const point = [lng, lat];
    const timeObject = ts.getFuzzyLocalTimeFromPoint(timestamp, point);
    const dateTime = new Date(timeObject._d);
    const utcTime = new Date(dateTime.getTime() + dateTime.getTimezoneOffset() * 60000);
    const utcTimeString = utcTime.toTimeString();
    const finalTime = utcTimeString.split(' ');
    return finalTime[0].slice(0, -3);
  }

  ngOnDestroy(): void {
    this.#destroy.next(true);
    this.#destroy.unsubscribe();
  }
}
