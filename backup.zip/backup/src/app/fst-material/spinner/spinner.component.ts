import { Component } from '@angular/core';
import { SpinnerService } from '../../module/shared/service/spinner.service';

@Component({
  selector: 'strm-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent {
  constructor(public spinnerService: SpinnerService) {}
}
