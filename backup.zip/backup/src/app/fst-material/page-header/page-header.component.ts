import { Component, EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { RootState } from '../../model/root-state.model';
import { selectPageTitle } from '../../state/root.selectors';

@Component({
  selector: 'strm-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss']
})
export class PageHeaderComponent {
  pageTitle: Observable<string>;
  constructor(private store: Store<RootState>) {
    this.pageTitle = this.store.select(selectPageTitle);
  }
  @Output() toggleSidenav = new EventEmitter<void>();
}
