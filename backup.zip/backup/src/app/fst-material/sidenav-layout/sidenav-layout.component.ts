import { Component, NgZone, OnDestroy, ViewChild, ViewEncapsulation } from '@angular/core';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { MatDrawerToggleResult, MatSidenav } from '@angular/material/sidenav';

const EXTRA_SMALL_WIDTH_BREAKPOINT = 720;
const SMALL_WIDTH_BREAKPOINT = 939;

@Component({
  selector: 'strm-sidenav-layout',
  templateUrl: './sidenav-layout.component.html',
  styleUrls: ['./sidenav-layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SidenavLayoutComponent implements OnDestroy {
  @ViewChild(MatSidenav) sidenav: MatSidenav | undefined;
  isExtraScreenSmall: Observable<boolean>;
  isScreenSmall: Observable<boolean>;
  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    zone: NgZone,
    breakpoints: BreakpointObserver
  ) {
    this.isExtraScreenSmall = breakpoints
      .observe(`(max-width: ${EXTRA_SMALL_WIDTH_BREAKPOINT}px)`)
      .pipe(map((breakpoint) => breakpoint.matches));
    this.isScreenSmall = breakpoints
      .observe(`(max-width: ${SMALL_WIDTH_BREAKPOINT}px)`)
      .pipe(map((breakpoint) => breakpoint.matches));
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  toggleSidenav(sidenav: MatSidenav | undefined): Promise<MatDrawerToggleResult> | undefined {
    return sidenav === undefined ? undefined : sidenav.toggle();
  }
}
