export interface SideNavItem {
  name: string;
  link: string;
}
