import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { User } from '../../core/model/user.model';
import * as RootSelectors from '../../state/root.selectors';
import { Observable } from 'rxjs';
import { RootState } from '../../model/root-state.model';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'strm-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss']
})
export class UserMenuComponent implements OnInit {
  public currentUser: Observable<User | undefined> = this.store.select(
    RootSelectors.selectCurrentUser
  );
  public menuItems: MenuItem[];

  constructor(
    private readonly store: Store<RootState>,
    private http: HttpClient
  ) {}

  public ngOnInit(): void {
    this.menuItems = [
      {
        label: 'Sign out',
        icon: 'pi pi-sign-out',
        command: () => {
          this.logout();
        }
      }
    ];
  }

  private logout(): void {
    const url = '/api/logout';
    this.http.post(url, null, { observe: 'response' }).subscribe((response: HttpResponse<JSON>) => {
      if (response.headers.has('SM_LOGOUT')) {
        window.location.href = decodeURIComponent(response.headers.get('SM_LOGOUT'));
      }
    });
  }
}
