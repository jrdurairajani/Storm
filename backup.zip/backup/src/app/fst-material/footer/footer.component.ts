import { Component, Inject } from '@angular/core';
import { APP_VERSION } from '../../config/version.config';

@Component({
  selector: 'strm-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  version: string;

  constructor(@Inject(APP_VERSION) appVersion: string) {
    this.version = appVersion;
  }
}
