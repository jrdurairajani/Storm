var process = require('process');
process.env.CHROME_BIN = require('puppeteer').executablePath();

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-summary-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    autoWatch: false,
    singleRun: true,
    port: 9876,
    colors: true,
    logLevel: config.LOG_ERROR,
    customLaunchers: {
      ChromeHeadlessCI: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox'],
        exitOnResourceError: true
      }
    },
    browsers: ['ChromeHeadlessCI'],
    browserDisconnectTolerance: 2,
    browserNoActivityTimeout: 50000,
    client: {
      clearContext: false
    },
    preprocessors: {
      'src/**/*.ts': 'coverage'
    },
    reporters: ['summary'],
    coverageReporter: {
      dir: './coverage/',
      subdir: '.',
      reporters: [{ type: 'html' }, { type: 'text-summary' }],
      check: {
        global: {
          statements: 40,
          branches: 30,
          functions: 40,
          lines: 40
        }
      }
    },
    summaryReporter: {
      show: 'all',
      specLength: 150,
      overviewColumn: true,
      browserList: 'always',
      symbols: { success: '✓', failure: 'x' }
    }
  });
};
