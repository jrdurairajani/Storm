#!/usr/bin/env bash
while getopts e: option
do
case "${option}"
in
e) ENV=${OPTARG};;
esac
done

#!/usr/bin/env bash
cf push -f manifest-$ENV.yml -p storm-ui
